"""
DocMind FastAPI Backend
=======================
Streams LangGraph agent events in Vercel AI SDK data stream protocol format.
Supports: chat sessions, document upload/management, PageIndex operations.
"""

import asyncio
import json
import os
import uuid
from contextlib import asynccontextmanager
from pathlib import Path
from typing import AsyncGenerator, Dict, List, Optional

import aiofiles
from dotenv import load_dotenv
from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage
from pydantic import BaseModel

load_dotenv()

from agents.graph import get_graph, AgentState
from storage.db import (
    SessionStore, MessageStore, DocumentStore, 
    PageIndexStore, AgentEventStore, DOCS_DIR
)
from storage.page_index import PageIndexBuilder, PageIndexStore as PIStore


# ── Lifespan ──────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Pre-compile graph on startup
    print("🚀 DocMind starting up...")
    _ = get_graph()
    print("✅ LangGraph compiled")
    yield
    print("👋 DocMind shutting down")


# ── App ────────────────────────────────────────────────────────────────────────

app = FastAPI(
    title="DocMind API",
    description="Multi-agent document intelligence with streaming",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["x-vercel-ai-ui-message-stream"],
)


# ── Vercel AI SDK Data Stream Protocol helpers ────────────────────────────────

def sse_event(data: dict) -> str:
    """Format a single SSE event in Vercel AI data stream protocol."""
    return f"data: {json.dumps(data)}\n\n"


def stream_text_start(text_id: str) -> str:
    return sse_event({"type": "text-start", "id": text_id})


def stream_text_delta(text_id: str, delta: str) -> str:
    return sse_event({"type": "text-delta", "id": text_id, "delta": delta})


def stream_text_end(text_id: str) -> str:
    return sse_event({"type": "text-end", "id": text_id})


def stream_tool_input_start(tool_call_id: str, tool_name: str) -> str:
    return sse_event({
        "type": "tool-input-start",
        "toolCallId": tool_call_id,
        "toolName": tool_name,
    })


def stream_tool_input_end(tool_call_id: str, input_data: dict) -> str:
    return sse_event({
        "type": "tool-input-delta",
        "toolCallId": tool_call_id,
        "inputTextDelta": json.dumps(input_data),
    })


def stream_tool_result(tool_call_id: str, tool_name: str, result: any) -> str:
    return sse_event({
        "type": "data-toolResult",
        "toolCallId": tool_call_id,
        "toolName": tool_name,
        "result": result if isinstance(result, (dict, list)) else str(result),
    })


def stream_agent_event(agent: str, event: str, data: any = None) -> str:
    return sse_event({
        "type": "data-agentEvent",
        "agent": agent,
        "event": event,
        "data": data,
    })


def stream_message_start(message_id: str) -> str:
    return sse_event({"type": "message-start", "messageId": message_id})


def stream_message_end(message_id: str, finish_reason: str = "stop") -> str:
    return sse_event({
        "type": "message-end",
        "messageId": message_id,
        "finishReason": finish_reason,
    })


def stream_step_start(step_type: str) -> str:
    return sse_event({"type": "step-start", "stepType": step_type})


def stream_step_end() -> str:
    return sse_event({"type": "step-finish"})


def stream_done() -> str:
    return "data: [DONE]\n\n"


# ── SSE streaming generator ────────────────────────────────────────────────────

async def run_agent_stream(
    session_id: str,
    user_message: str,
    history: List[Dict],
) -> AsyncGenerator[str, None]:
    """
    Run LangGraph agent and stream events in Vercel AI SDK data stream protocol.
    """
    graph = get_graph()
    message_id = str(uuid.uuid4())
    text_id = str(uuid.uuid4())

    # Convert history to LangChain messages
    lc_messages = []
    for msg in history[-20:]:  # Last 20 messages for context
        if msg["role"] == "user":
            lc_messages.append(HumanMessage(content=msg["content"]))
        elif msg["role"] == "assistant":
            lc_messages.append(AIMessage(content=msg["content"]))

    lc_messages.append(HumanMessage(content=user_message))

    initial_state: AgentState = {
        "messages": lc_messages,
        "session_id": session_id,
        "active_agent": "orchestrator",
        "tool_calls_made": [],
        "current_task": user_message,
        "iteration": 0,
    }

    # Track streaming state
    current_text = ""
    text_started = False
    active_tool_calls = {}  # tool_call_id -> name

    # Stream message start
    yield stream_message_start(message_id)
    yield stream_agent_event("orchestrator", "start", {"task": user_message})

    try:
        async for event in graph.astream_events(initial_state, version="v2"):
            event_type = event.get("event", "")
            event_name = event.get("name", "")
            data = event.get("data", {})
            metadata = event.get("metadata", {})
            tags = event.get("tags", [])
            
            # ── LLM token streaming ──────────────────────────────────────────
            if event_type == "on_chat_model_stream":
                chunk = data.get("chunk")
                if chunk and hasattr(chunk, "content"):
                    content = chunk.content
                    if isinstance(content, str) and content:
                        if not text_started:
                            yield stream_text_start(text_id)
                            text_started = True
                        yield stream_text_delta(text_id, content)
                        current_text += content
                    elif isinstance(content, list):
                        for block in content:
                            if isinstance(block, dict) and block.get("type") == "text":
                                text_block = block.get("text", "")
                                if text_block:
                                    if not text_started:
                                        yield stream_text_start(text_id)
                                        text_started = True
                                    yield stream_text_delta(text_id, text_block)
                                    current_text += text_block

            # ── LLM start (agent started thinking) ─────────────────────────
            elif event_type == "on_chat_model_start":
                node_name = metadata.get("langgraph_node", "unknown")
                yield stream_agent_event(node_name, "thinking", None)
                AgentEventStore.log(session_id, node_name, "thinking", None)

            # ── LLM end (agent done) ────────────────────────────────────────
            elif event_type == "on_chat_model_end":
                node_name = metadata.get("langgraph_node", "unknown")
                output = data.get("output")
                
                if text_started:
                    yield stream_text_end(text_id)
                    text_started = False
                    # Reset for next text block
                    text_id = str(uuid.uuid4())
                    current_text = ""

                # Check for tool calls
                if output and hasattr(output, "tool_calls") and output.tool_calls:
                    yield stream_step_start("tool-call")
                    for tc in output.tool_calls:
                        tc_id = tc.get("id", str(uuid.uuid4()))
                        tc_name = tc.get("name", "unknown_tool")
                        tc_args = tc.get("args", {})
                        active_tool_calls[tc_id] = tc_name
                        
                        yield stream_tool_input_start(tc_id, tc_name)
                        yield stream_tool_input_end(tc_id, tc_args)
                        yield stream_agent_event(node_name, "tool_call", {
                            "tool": tc_name,
                            "args": tc_args,
                            "id": tc_id,
                        })
                        AgentEventStore.log(session_id, node_name, "tool_call", {
                            "tool": tc_name,
                            "args": tc_args,
                        })

            # ── Tool execution ──────────────────────────────────────────────
            elif event_type == "on_tool_start":
                tool_name = event_name
                tool_input = data.get("input", {})
                yield stream_agent_event("tools", "executing", {
                    "tool": tool_name,
                    "input": tool_input,
                })

            elif event_type == "on_tool_end":
                tool_name = event_name
                output = data.get("output")
                
                # Find tool call ID
                tc_id = None
                for tid, tname in active_tool_calls.items():
                    if tname == tool_name:
                        tc_id = tid
                        break
                
                if tc_id:
                    result = output
                    if hasattr(output, "content"):
                        try:
                            result = json.loads(output.content)
                        except Exception:
                            result = output.content
                    
                    yield stream_tool_result(tc_id, tool_name, result)
                    yield stream_step_end()
                    yield stream_agent_event("tools", "result", {
                        "tool": tool_name,
                        "result": result if isinstance(result, (dict, list)) else str(result)[:500],
                    })
                    AgentEventStore.log(session_id, "tools", "tool_result", {
                        "tool": tool_name,
                        "result": str(result)[:500],
                    })
                    
                    # Remove from active
                    active_tool_calls = {k: v for k, v in active_tool_calls.items() if k != tc_id}

            # ── Graph node transitions ──────────────────────────────────────
            elif event_type == "on_chain_start":
                node_name = metadata.get("langgraph_node", "")
                if node_name and node_name not in ("__start__", "LangGraph"):
                    yield stream_agent_event(node_name, "start", None)

    except asyncio.CancelledError:
        yield stream_agent_event("orchestrator", "cancelled", None)
        raise
    except Exception as e:
        error_msg = f"Agent error: {str(e)}"
        yield stream_agent_event("orchestrator", "error", {"message": error_msg})
        if not text_started:
            yield stream_text_start(text_id)
        yield stream_text_delta(text_id, f"\n\n⚠️ {error_msg}")
        yield stream_text_end(text_id)

    finally:
        if text_started:
            yield stream_text_end(text_id)
        yield stream_message_end(message_id)
        yield stream_done()


# ── Request/Response models ────────────────────────────────────────────────────

class ChatRequest(BaseModel):
    messages: List[Dict]
    chatId: Optional[str] = None
    session_id: Optional[str] = None


class SessionCreateRequest(BaseModel):
    title: Optional[str] = "New Conversation"


# ── Routes ────────────────────────────────────────────────────────────────────

@app.get("/health")
async def health():
    return {"status": "ok", "service": "DocMind API"}


# ── Chat streaming endpoint ────────────────────────────────────────────────────

@app.post("/api/chat")
async def chat_stream(request: ChatRequest):
    """
    Main chat endpoint. Streams LangGraph agent responses in Vercel AI SDK format.
    """
    messages = request.messages
    if not messages:
        raise HTTPException(400, "No messages provided")

    # Get or create session
    session_id = request.session_id or request.chatId
    if not session_id:
        session = SessionStore.create()
        session_id = session["id"]
    else:
        if not SessionStore.get(session_id):
            SessionStore.create()

    # Get last user message
    user_messages = [m for m in messages if m.get("role") == "user"]
    if not user_messages:
        raise HTTPException(400, "No user message found")
    
    last_user_msg = user_messages[-1]
    user_content = last_user_msg.get("content", "")
    if isinstance(user_content, list):
        # Extract text from content array
        user_content = " ".join(
            part.get("text", "") for part in user_content 
            if isinstance(part, dict) and part.get("type") == "text"
        )

    # Save user message
    MessageStore.append(session_id, "user", user_content)

    # Build history (all but last user message)
    history = [m for m in messages[:-1]]

    return StreamingResponse(
        run_agent_stream(session_id, user_content, history),
        media_type="text/event-stream",
        headers={
            "x-vercel-ai-ui-message-stream": "v1",
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Session-Id": session_id,
        },
    )


# ── Session management ─────────────────────────────────────────────────────────

@app.get("/api/sessions")
async def list_sessions():
    return {"sessions": SessionStore.list_all()}


@app.post("/api/sessions")
async def create_session(req: SessionCreateRequest):
    session = SessionStore.create(req.title)
    return session


@app.get("/api/sessions/{session_id}")
async def get_session(session_id: str):
    session = SessionStore.get(session_id)
    if not session:
        raise HTTPException(404, "Session not found")
    messages = MessageStore.get_history(session_id)
    return {**session, "messages": messages}


@app.delete("/api/sessions/{session_id}")
async def delete_session(session_id: str):
    SessionStore.delete(session_id)
    return {"deleted": session_id}


@app.get("/api/sessions/{session_id}/messages")
async def get_messages(session_id: str):
    return {"messages": MessageStore.get_history(session_id)}


# ── Document management ────────────────────────────────────────────────────────

@app.post("/api/documents/upload")
async def upload_document(
    file: UploadFile = File(...),
    session_id: Optional[str] = Form(None),
):
    """Upload a document for analysis."""
    # Validate file type
    allowed_types = {
        "application/pdf": "pdf",
        "image/jpeg": "image",
        "image/png": "image",
        "image/webp": "image",
        "image/gif": "image",
        "text/plain": "text",
    }
    
    content_type = file.content_type or ""
    file_type = allowed_types.get(content_type)
    if not file_type:
        # Try to infer from extension
        ext = Path(file.filename or "").suffix.lower()
        ext_map = {".pdf": "pdf", ".jpg": "image", ".jpeg": "image", 
                   ".png": "image", ".webp": "image", ".txt": "text"}
        file_type = ext_map.get(ext, "unknown")

    # Save file
    doc_id = str(uuid.uuid4())
    filename = file.filename or f"document_{doc_id}"
    safe_filename = f"{doc_id}_{filename}"
    file_path = DOCS_DIR / safe_filename

    content = await file.read()
    async with aiofiles.open(file_path, "wb") as f:
        await f.write(content)

    # Save to DB
    doc = DocumentStore.save(
        filename=filename,
        file_path=str(file_path),
        file_type=file_type,
        size_bytes=len(content),
        session_id=session_id,
        metadata={"content_type": content_type},
    )

    return {
        "document": doc,
        "message": f"Document '{filename}' uploaded successfully",
    }


@app.get("/api/documents")
async def list_documents(session_id: Optional[str] = None):
    docs = DocumentStore.list_all(session_id)
    return {"documents": docs}


@app.get("/api/documents/{doc_id}")
async def get_document(doc_id: str):
    doc = DocumentStore.get(doc_id)
    if not doc:
        raise HTTPException(404, "Document not found")
    return doc


@app.delete("/api/documents/{doc_id}")
async def delete_document(doc_id: str):
    DocumentStore.delete(doc_id)
    return {"deleted": doc_id}


# ── PageIndex endpoints ────────────────────────────────────────────────────────

@app.post("/api/documents/{doc_id}/index")
async def index_document(doc_id: str):
    """Build PageIndex tree for a document (async stream progress)."""
    doc = DocumentStore.get(doc_id)
    if not doc:
        raise HTTPException(404, "Document not found")

    progress_messages = []

    async def progress_stream():
        builder = PageIndexBuilder()
        
        async def on_progress(msg: str):
            progress_messages.append(msg)
            yield f"data: {json.dumps({'type': 'progress', 'message': msg})}\n\n"

        async def collect_progress(msg: str):
            progress_messages.append(msg)

        try:
            yield f"data: {json.dumps({'type': 'start', 'doc_id': doc_id})}\n\n"
            
            tree, page_count = await builder.build_tree(
                file_path=doc["file_path"],
                doc_title=doc["filename"],
                progress_callback=collect_progress,
            )
            
            # Stream progress messages
            for msg in progress_messages:
                yield f"data: {json.dumps({'type': 'progress', 'message': msg})}\n\n"
            
            record = PIStore.save(
                doc_id=doc_id,
                doc_filename=doc["filename"],
                tree=tree,
                page_count=page_count,
            )
            
            yield f"data: {json.dumps({'type': 'complete', 'index': record})}\n\n"
            yield "data: [DONE]\n\n"
            
        except Exception as e:
            yield f"data: {json.dumps({'type': 'error', 'message': str(e)})}\n\n"
            yield "data: [DONE]\n\n"

    return StreamingResponse(
        progress_stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache"},
    )


@app.get("/api/documents/{doc_id}/index")
async def get_document_index(doc_id: str):
    """Get the PageIndex tree for a document."""
    doc = DocumentStore.get(doc_id)
    if not doc:
        raise HTTPException(404, "Document not found")
    
    if not doc.get("has_page_index"):
        raise HTTPException(404, "Document not yet indexed")
    
    record = PIStore.get(doc["page_index_id"])
    if not record:
        raise HTTPException(404, "Index not found")
    
    return record


@app.get("/api/page-indexes")
async def list_page_indexes():
    """List all PageIndex trees."""
    return {"indexes": PIStore.list_all()}


# ── Agent events ──────────────────────────────────────────────────────────────

@app.get("/api/sessions/{session_id}/events")
async def get_session_events(session_id: str):
    events = AgentEventStore.get_session_events(session_id)
    return {"events": events}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info",
    )
