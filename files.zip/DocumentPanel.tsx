'use client';

import { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  FileText, Image, Upload, Trash2, ChevronRight, 
  TreePine, Loader2, CheckCircle, File, X, Network,
  RefreshCw, Search
} from 'lucide-react';
import { useAppStore } from '@/lib/store';
import { Document, PageIndexNode } from '@/lib/types';
import { uploadDocument, documentsApi, BACKEND_URL } from '@/lib/api';

// PageIndex tree node renderer
function TreeNode({ node, depth = 0 }: { node: PageIndexNode; depth?: number }) {
  const [expanded, setExpanded] = useState(depth < 2);
  const hasChildren = node.nodes && node.nodes.length > 0;

  return (
    <div className={`${depth > 0 ? 'ml-3 border-l border-border/30 pl-2' : ''}`}>
      <div
        className={`flex items-start gap-1.5 py-1 px-1.5 rounded cursor-pointer group hover:bg-surface/50 transition-colors ${
          hasChildren ? 'cursor-pointer' : 'cursor-default'
        }`}
        onClick={() => hasChildren && setExpanded(!expanded)}
      >
        {hasChildren ? (
          <ChevronRight
            className={`w-3 h-3 mt-0.5 text-subtle flex-shrink-0 transition-transform ${
              expanded ? 'rotate-90' : ''
            }`}
          />
        ) : (
          <div className="w-3 h-3 flex-shrink-0" />
        )}
        <div className="flex-1 min-w-0">
          <p className="text-xs font-medium text-snow/80 truncate">{node.title}</p>
          <p className="text-xs text-muted">
            pp. {node.start_index}–{node.end_index}
          </p>
          {node.summary && expanded && (
            <p className="text-xs text-subtle mt-0.5 line-clamp-2">{node.summary}</p>
          )}
        </div>
      </div>
      <AnimatePresence>
        {expanded && hasChildren && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
          >
            {node.nodes.map((child) => (
              <TreeNode key={child.node_id} node={child} depth={depth + 1} />
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function DocumentCard({
  doc,
  onDelete,
  onIndex,
  onViewTree,
}: {
  doc: Document;
  onDelete: (id: string) => void;
  onIndex: (doc: Document) => void;
  onViewTree: (doc: Document) => void;
}) {
  const { pageIndexes } = useAppStore();
  const [indexing, setIndexing] = useState(false);

  const icons = {
    pdf: <FileText className="w-4 h-4 text-indigo-light" />,
    image: <Image className="w-4 h-4 text-violet-light" />,
    text: <File className="w-4 h-4 text-cyan-light" />,
    unknown: <File className="w-4 h-4 text-subtle" />,
  };

  const sizeStr =
    doc.size_bytes < 1024
      ? `${doc.size_bytes} B`
      : doc.size_bytes < 1048576
      ? `${(doc.size_bytes / 1024).toFixed(1)} KB`
      : `${(doc.size_bytes / 1048576).toFixed(1)} MB`;

  const hasIndex = doc.has_page_index || pageIndexes[doc.id];

  async function handleIndex() {
    setIndexing(true);
    try {
      await onIndex(doc);
    } finally {
      setIndexing(false);
    }
  }

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      className="group rounded-lg border border-border/60 bg-card/50 p-2.5 hover:border-indigo-DEFAULT/30 transition-all"
    >
      <div className="flex items-start gap-2">
        <div className="mt-0.5 p-1 rounded bg-surface/80">
          {icons[doc.file_type] || icons.unknown}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-xs font-medium text-snow truncate">{doc.filename}</p>
          <p className="text-xs text-muted mt-0.5">{sizeStr} · {doc.file_type.toUpperCase()}</p>
        </div>
        <button
          onClick={() => onDelete(doc.id)}
          className="opacity-0 group-hover:opacity-100 p-1 text-muted hover:text-rose transition-all"
        >
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Index status */}
      <div className="mt-2 pt-2 border-t border-border/30 flex items-center gap-2">
        {hasIndex ? (
          <>
            <div className="flex items-center gap-1 text-emerald text-xs">
              <CheckCircle className="w-3 h-3" />
              <span>Indexed</span>
            </div>
            <button
              onClick={() => onViewTree(doc)}
              className="ml-auto text-xs text-indigo-light hover:text-indigo flex items-center gap-1 transition-colors"
            >
              <Network className="w-3 h-3" />
              View Tree
            </button>
          </>
        ) : (
          <>
            <div className="text-xs text-muted">Not indexed</div>
            {doc.file_type === 'pdf' && (
              <button
                onClick={handleIndex}
                disabled={indexing}
                className="ml-auto text-xs text-indigo-light hover:text-indigo flex items-center gap-1 transition-colors disabled:opacity-50"
              >
                {indexing ? (
                  <Loader2 className="w-3 h-3 animate-spin" />
                ) : (
                  <TreePine className="w-3 h-3" />
                )}
                {indexing ? 'Indexing...' : 'Build Index'}
              </button>
            )}
          </>
        )}
      </div>
    </motion.div>
  );
}

export default function DocumentPanel() {
  const {
    documents,
    pageIndexes,
    docPanelOpen,
    currentSessionId,
    addDocument,
    removeDocument,
    updateDocument,
    addPageIndex,
  } = useAppStore();

  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [selectedTree, setSelectedTree] = useState<{
    doc: Document;
    tree: PageIndexNode;
  } | null>(null);
  const [indexProgress, setIndexProgress] = useState<Record<string, string>>({});

  const onDrop = useCallback(
    async (files: File[]) => {
      setUploading(true);
      setUploadError(null);
      for (const file of files) {
        try {
          const result = await uploadDocument(file, currentSessionId || undefined);
          addDocument(result.document);
        } catch (e: any) {
          setUploadError(e.message);
        }
      }
      setUploading(false);
    },
    [currentSessionId, addDocument]
  );

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png'],
      'image/webp': ['.webp'],
      'text/plain': ['.txt'],
    },
    maxSize: 50 * 1024 * 1024, // 50MB
  });

  async function handleIndex(doc: Document) {
    const url = documentsApi.buildIndex(doc.id);
    const eventSource = new EventSource(url);

    eventSource.onmessage = (e) => {
      const data = JSON.parse(e.data);
      if (data === '[DONE]' || e.data === '[DONE]') {
        eventSource.close();
        return;
      }

      if (data.type === 'progress') {
        setIndexProgress((prev) => ({ ...prev, [doc.id]: data.message }));
      } else if (data.type === 'complete') {
        updateDocument(doc.id, { has_page_index: true, page_index_id: data.index.id });
        addPageIndex(doc.id, data.index);
        setIndexProgress((prev) => {
          const next = { ...prev };
          delete next[doc.id];
          return next;
        });
        eventSource.close();
      } else if (data.type === 'error') {
        setUploadError(data.message);
        eventSource.close();
      }
    };

    // Keep connection for up to 2 minutes
    setTimeout(() => eventSource.close(), 120000);
  }

  async function handleViewTree(doc: Document) {
    let record = pageIndexes[doc.id];
    if (!record && doc.has_page_index) {
      try {
        record = await documentsApi.getIndex(doc.id);
        addPageIndex(doc.id, record);
      } catch (e) {
        return;
      }
    }
    if (record) {
      setSelectedTree({ doc, tree: record.tree });
    }
  }

  async function handleDelete(id: string) {
    try {
      await documentsApi.delete(id);
      removeDocument(id);
    } catch (e: any) {
      setUploadError(e.message);
    }
  }

  if (!docPanelOpen) return null;

  return (
    <div className="flex h-full">
      {/* Document list */}
      <div className="flex flex-col w-64 bg-ink border-r border-border/50 flex-shrink-0">
        {/* Header */}
        <div className="px-3 py-2.5 border-b border-border/50">
          <h3 className="text-xs font-semibold text-snow tracking-wider uppercase">
            Documents
          </h3>
          <p className="text-xs text-muted mt-0.5">{documents.length} files</p>
        </div>

        {/* Upload zone */}
        <div className="p-2">
          <div
            {...getRootProps()}
            className={`border-2 border-dashed rounded-lg p-3 text-center cursor-pointer transition-all ${
              isDragActive
                ? 'border-indigo-DEFAULT bg-indigo-glow'
                : 'border-border/60 hover:border-indigo-DEFAULT/50 hover:bg-surface/30'
            }`}
          >
            <input {...getInputProps()} />
            {uploading ? (
              <div className="flex items-center justify-center gap-2 text-xs text-indigo-light">
                <Loader2 className="w-4 h-4 animate-spin" />
                Uploading...
              </div>
            ) : (
              <>
                <Upload className="w-5 h-5 text-muted mx-auto mb-1" />
                <p className="text-xs text-ghost">
                  {isDragActive ? 'Drop files here' : 'Upload PDF, image, or text'}
                </p>
              </>
            )}
          </div>
          {uploadError && (
            <p className="text-xs text-rose mt-1 flex items-center gap-1">
              <X className="w-3 h-3" />
              {uploadError}
            </p>
          )}
        </div>

        {/* Documents list */}
        <div className="flex-1 overflow-y-auto px-2 pb-2 space-y-1.5">
          <AnimatePresence mode="popLayout">
            {documents.map((doc) => (
              <div key={doc.id}>
                <DocumentCard
                  doc={doc}
                  onDelete={handleDelete}
                  onIndex={handleIndex}
                  onViewTree={handleViewTree}
                />
                {indexProgress[doc.id] && (
                  <p className="text-xs text-amber mt-1 px-1 flex items-center gap-1">
                    <Loader2 className="w-3 h-3 animate-spin" />
                    {indexProgress[doc.id]}
                  </p>
                )}
              </div>
            ))}
          </AnimatePresence>
          {documents.length === 0 && (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <FileText className="w-8 h-8 text-muted mb-2" />
              <p className="text-xs text-muted">No documents yet</p>
              <p className="text-xs text-muted/60 mt-1">Upload a PDF to get started</p>
            </div>
          )}
        </div>
      </div>

      {/* PageIndex tree viewer */}
      {selectedTree && (
        <div className="flex flex-col flex-1 bg-deep border-r border-border/50 min-w-0">
          <div className="px-3 py-2.5 border-b border-border/50 flex items-center gap-2">
            <Network className="w-4 h-4 text-indigo-light" />
            <h3 className="text-xs font-semibold text-snow truncate flex-1">
              {selectedTree.doc.filename}
            </h3>
            <button
              onClick={() => setSelectedTree(null)}
              className="p-1 text-muted hover:text-snow"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto p-2">
            <div className="text-xs text-muted mb-2 px-1">
              PageIndex Tree — hover nodes to see summaries
            </div>
            <TreeNode node={selectedTree.tree} depth={0} />
          </div>
        </div>
      )}
    </div>
  );
}
