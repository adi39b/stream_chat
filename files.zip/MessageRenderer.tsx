'use client';

import { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark } from 'react-syntax-highlighter/dist/cjs/styles/prism';
import { 
  User, Sparkles, ChevronDown, ChevronUp, 
  CheckCircle, AlertCircle, Wrench, Copy, Check
} from 'lucide-react';
import { motion } from 'framer-motion';

interface MessageRendererProps {
  role: 'user' | 'assistant';
  content: string;
  isStreaming?: boolean;
  toolCalls?: Array<{
    id: string;
    name: string;
    input?: any;
    result?: any;
    status: 'pending' | 'executing' | 'complete' | 'error';
  }>;
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      onClick={() => {
        navigator.clipboard.writeText(text);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      }}
      className="absolute top-2 right-2 p-1.5 rounded bg-surface/80 text-muted hover:text-snow transition-colors opacity-0 group-hover:opacity-100"
    >
      {copied ? <Check className="w-3.5 h-3.5 text-emerald" /> : <Copy className="w-3.5 h-3.5" />}
    </button>
  );
}

function InlineToolCall({
  name,
  input,
  result,
  status,
}: {
  name: string;
  input?: any;
  result?: any;
  status: string;
}) {
  const [expanded, setExpanded] = useState(false);

  const statusConfig = {
    pending: { icon: <Wrench className="w-3 h-3" />, color: 'text-muted border-border/50', bg: 'bg-surface/30' },
    executing: { icon: <Wrench className="w-3 h-3 animate-bounce" />, color: 'text-amber border-amber/30', bg: 'bg-amber-glow' },
    complete: { icon: <CheckCircle className="w-3 h-3" />, color: 'text-emerald border-emerald/30', bg: 'bg-emerald-glow' },
    error: { icon: <AlertCircle className="w-3 h-3" />, color: 'text-rose border-rose/30', bg: 'bg-rose-glow' },
  };

  const cfg = statusConfig[status as keyof typeof statusConfig] || statusConfig.pending;

  return (
    <div className={`my-2 rounded-lg border ${cfg.color} ${cfg.bg} overflow-hidden`}>
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center gap-2 px-3 py-2 text-left"
      >
        {cfg.icon}
        <code className="text-xs font-mono font-medium flex-1">{name}</code>
        {expanded ? (
          <ChevronUp className="w-3 h-3 text-muted" />
        ) : (
          <ChevronDown className="w-3 h-3 text-muted" />
        )}
      </button>
      {expanded && (
        <div className="px-3 pb-3 border-t border-border/20 space-y-2">
          {input && (
            <div>
              <p className="text-xs text-muted font-medium mt-2 mb-1">INPUT</p>
              <pre className="text-xs font-mono text-ghost bg-ink/50 p-2 rounded overflow-x-auto max-h-32 whitespace-pre-wrap">
                {JSON.stringify(input, null, 2)}
              </pre>
            </div>
          )}
          {result && (
            <div>
              <p className="text-xs text-muted font-medium mb-1">RESULT</p>
              <pre className="text-xs font-mono text-ghost bg-ink/50 p-2 rounded overflow-x-auto max-h-48 whitespace-pre-wrap">
                {typeof result === 'string' 
                  ? result.slice(0, 600)
                  : JSON.stringify(result, null, 2).slice(0, 600)}
              </pre>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default function MessageRenderer({
  role,
  content,
  isStreaming,
  toolCalls = [],
}: MessageRendererProps) {
  const isUser = role === 'user';

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
      className={`flex gap-3 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
    >
      {/* Avatar */}
      <div className={`flex-shrink-0 w-7 h-7 rounded-lg flex items-center justify-center ${
        isUser 
          ? 'bg-indigo-DEFAULT/20 border border-indigo-DEFAULT/30' 
          : 'bg-gradient-to-br from-violet-DEFAULT to-indigo-DEFAULT'
      }`}>
        {isUser ? (
          <User className="w-3.5 h-3.5 text-indigo-light" />
        ) : (
          <Sparkles className="w-3.5 h-3.5 text-white" />
        )}
      </div>

      {/* Content */}
      <div className={`flex-1 min-w-0 max-w-[85%] ${isUser ? 'items-end flex flex-col' : ''}`}>
        <div className={`rounded-2xl px-4 py-3 ${
          isUser
            ? 'bg-indigo-DEFAULT/15 border border-indigo-DEFAULT/20 text-snow rounded-tr-sm'
            : 'bg-card/80 border border-border/50 rounded-tl-sm'
        }`}>
          {isUser ? (
            <p className="text-sm text-snow whitespace-pre-wrap">{content}</p>
          ) : (
            <div className={`markdown-body text-sm ${isStreaming && !content ? 'streaming-cursor' : ''}`}>
              {content && (
                <ReactMarkdown
                  remarkPlugins={[remarkGfm]}
                  components={{
                    code({ node, className, children, ...props }: any) {
                      const match = /language-(\w+)/.exec(className || '');
                      const isBlock = !!(props as any).style || className;
                      if (isBlock && match) {
                        return (
                          <div className="relative group my-2">
                            <SyntaxHighlighter
                              style={oneDark as any}
                              language={match[1]}
                              PreTag="div"
                              customStyle={{
                                background: 'rgba(11,11,16,0.8)',
                                border: '1px solid #2a2a38',
                                borderRadius: '8px',
                                fontSize: '0.8rem',
                                margin: 0,
                              }}
                            >
                              {String(children).replace(/\n$/, '')}
                            </SyntaxHighlighter>
                            <CopyButton text={String(children)} />
                          </div>
                        );
                      }
                      return (
                        <code className={className} {...props}>
                          {children}
                        </code>
                      );
                    },
                  }}
                >
                  {content}
                </ReactMarkdown>
              )}
              {isStreaming && <span className="streaming-cursor inline-block" />}
            </div>
          )}
        </div>

        {/* Tool calls below message */}
        {!isUser && toolCalls.length > 0 && (
          <div className="mt-2 space-y-1 w-full">
            {toolCalls.map((tc) => (
              <InlineToolCall
                key={tc.id}
                name={tc.name}
                input={tc.input}
                result={tc.result}
                status={tc.status}
              />
            ))}
          </div>
        )}
      </div>
    </motion.div>
  );
}
