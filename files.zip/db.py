"""
TinyDB storage layer for DocMind.
Handles: chat sessions, documents, PageIndex trees, agent events.
"""

import json
import os
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from tinydb import TinyDB, Query
from tinydb.storages import JSONStorage
from tinydb.middlewares import CachingMiddleware

# ── Storage directory ────────────────────────────────────────────────────────

STORAGE_DIR = Path(os.getenv("STORAGE_DIR", "./data"))
STORAGE_DIR.mkdir(parents=True, exist_ok=True)

DOCS_DIR = STORAGE_DIR / "documents"
DOCS_DIR.mkdir(parents=True, exist_ok=True)

# ── TinyDB instance ──────────────────────────────────────────────────────────

_db: Optional[TinyDB] = None


def get_db() -> TinyDB:
    global _db
    if _db is None:
        db_path = STORAGE_DIR / "docmind.json"
        _db = TinyDB(db_path, storage=CachingMiddleware(JSONStorage))
        _db._storage.flush()  # ensure file is created
    return _db


# ── Table accessors ──────────────────────────────────────────────────────────

def sessions_table():
    return get_db().table("sessions")

def messages_table():
    return get_db().table("messages")

def documents_table():
    return get_db().table("documents")

def page_index_table():
    return get_db().table("page_index_trees")

def agent_events_table():
    return get_db().table("agent_events")


# ── Chat Session CRUD ────────────────────────────────────────────────────────

class SessionStore:
    @staticmethod
    def create(title: str = "New Conversation") -> Dict:
        session_id = str(uuid.uuid4())
        session = {
            "id": session_id,
            "title": title,
            "created_at": datetime.utcnow().isoformat(),
            "updated_at": datetime.utcnow().isoformat(),
            "message_count": 0,
        }
        sessions_table().insert(session)
        return session

    @staticmethod
    def get(session_id: str) -> Optional[Dict]:
        Q = Query()
        results = sessions_table().search(Q.id == session_id)
        return results[0] if results else None

    @staticmethod
    def list_all() -> List[Dict]:
        all_sessions = sessions_table().all()
        return sorted(all_sessions, key=lambda x: x.get("updated_at", ""), reverse=True)

    @staticmethod
    def update_title(session_id: str, title: str):
        Q = Query()
        sessions_table().update(
            {"title": title, "updated_at": datetime.utcnow().isoformat()},
            Q.id == session_id,
        )

    @staticmethod
    def touch(session_id: str):
        Q = Query()
        sessions_table().update(
            {"updated_at": datetime.utcnow().isoformat()},
            Q.id == session_id,
        )

    @staticmethod
    def increment_messages(session_id: str):
        Q = Query()
        results = sessions_table().search(Q.id == session_id)
        if results:
            count = results[0].get("message_count", 0) + 1
            sessions_table().update(
                {"message_count": count, "updated_at": datetime.utcnow().isoformat()},
                Q.id == session_id,
            )

    @staticmethod
    def delete(session_id: str):
        Q = Query()
        sessions_table().remove(Q.id == session_id)
        messages_table().remove(Q.session_id == session_id)


# ── Message CRUD ─────────────────────────────────────────────────────────────

class MessageStore:
    @staticmethod
    def append(session_id: str, role: str, content: str, metadata: Dict = None) -> Dict:
        msg = {
            "id": str(uuid.uuid4()),
            "session_id": session_id,
            "role": role,
            "content": content,
            "metadata": metadata or {},
            "created_at": datetime.utcnow().isoformat(),
        }
        messages_table().insert(msg)
        SessionStore.increment_messages(session_id)
        return msg

    @staticmethod
    def get_history(session_id: str) -> List[Dict]:
        Q = Query()
        msgs = messages_table().search(Q.session_id == session_id)
        return sorted(msgs, key=lambda x: x.get("created_at", ""))

    @staticmethod
    def clear_session(session_id: str):
        Q = Query()
        messages_table().remove(Q.session_id == session_id)


# ── Document CRUD ─────────────────────────────────────────────────────────────

class DocumentStore:
    @staticmethod
    def save(
        filename: str,
        file_path: str,
        file_type: str,
        size_bytes: int,
        session_id: Optional[str] = None,
        metadata: Dict = None,
    ) -> Dict:
        doc_id = str(uuid.uuid4())
        doc = {
            "id": doc_id,
            "filename": filename,
            "file_path": file_path,
            "file_type": file_type,
            "size_bytes": size_bytes,
            "session_id": session_id,
            "metadata": metadata or {},
            "has_page_index": False,
            "page_index_id": None,
            "created_at": datetime.utcnow().isoformat(),
        }
        documents_table().insert(doc)
        return doc

    @staticmethod
    def get(doc_id: str) -> Optional[Dict]:
        Q = Query()
        results = documents_table().search(Q.id == doc_id)
        return results[0] if results else None

    @staticmethod
    def list_all(session_id: Optional[str] = None) -> List[Dict]:
        Q = Query()
        if session_id:
            docs = documents_table().search(Q.session_id == session_id)
        else:
            docs = documents_table().all()
        return sorted(docs, key=lambda x: x.get("created_at", ""), reverse=True)

    @staticmethod
    def mark_indexed(doc_id: str, page_index_id: str):
        Q = Query()
        documents_table().update(
            {"has_page_index": True, "page_index_id": page_index_id},
            Q.id == doc_id,
        )

    @staticmethod
    def delete(doc_id: str):
        Q = Query()
        doc = DocumentStore.get(doc_id)
        if doc and os.path.exists(doc["file_path"]):
            os.remove(doc["file_path"])
        documents_table().remove(Q.id == doc_id)
        page_index_table().remove(Q.doc_id == doc_id)


# ── PageIndex Tree Storage ────────────────────────────────────────────────────

class PageIndexStore:
    @staticmethod
    def save(doc_id: str, doc_filename: str, tree: Dict, page_count: int) -> Dict:
        index_id = str(uuid.uuid4())
        record = {
            "id": index_id,
            "doc_id": doc_id,
            "doc_filename": doc_filename,
            "tree": tree,
            "page_count": page_count,
            "node_count": PageIndexStore._count_nodes(tree),
            "created_at": datetime.utcnow().isoformat(),
        }
        page_index_table().insert(record)
        DocumentStore.mark_indexed(doc_id, index_id)
        return record

    @staticmethod
    def get(index_id: str) -> Optional[Dict]:
        Q = Query()
        results = page_index_table().search(Q.id == index_id)
        return results[0] if results else None

    @staticmethod
    def get_by_doc(doc_id: str) -> Optional[Dict]:
        Q = Query()
        results = page_index_table().search(Q.doc_id == doc_id)
        return results[0] if results else None

    @staticmethod
    def list_all() -> List[Dict]:
        records = page_index_table().all()
        return sorted(records, key=lambda x: x.get("created_at", ""), reverse=True)

    @staticmethod
    def _count_nodes(tree: Any, count: int = 0) -> int:
        if isinstance(tree, dict):
            count += 1
            for child in tree.get("nodes", []):
                count = PageIndexStore._count_nodes(child, count)
        return count

    @staticmethod
    def find_node(tree: Dict, node_id: str) -> Optional[Dict]:
        """Recursive search for a node by node_id."""
        if tree.get("node_id") == node_id:
            return tree
        for child in tree.get("nodes", []):
            result = PageIndexStore.find_node(child, node_id)
            if result:
                return result
        return None

    @staticmethod
    def get_relevant_nodes(tree: Dict, node_ids: List[str]) -> List[Dict]:
        """Return list of nodes matching the given IDs."""
        found = []
        for nid in node_ids:
            node = PageIndexStore.find_node(tree, nid)
            if node:
                found.append(node)
        return found


# ── Agent Events (ephemeral log) ──────────────────────────────────────────────

class AgentEventStore:
    @staticmethod
    def log(session_id: str, agent: str, event_type: str, data: Any):
        agent_events_table().insert({
            "session_id": session_id,
            "agent": agent,
            "event_type": event_type,
            "data": data if isinstance(data, (str, int, float, bool, list, dict)) else str(data),
            "timestamp": datetime.utcnow().isoformat(),
        })

    @staticmethod
    def get_session_events(session_id: str) -> List[Dict]:
        Q = Query()
        events = agent_events_table().search(Q.session_id == session_id)
        return sorted(events, key=lambda x: x.get("timestamp", ""))
