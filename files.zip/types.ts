// DocMind TypeScript Types

export interface Session {
  id: string;
  title: string;
  created_at: string;
  updated_at: string;
  message_count: number;
}

export interface Message {
  id: string;
  session_id: string;
  role: 'user' | 'assistant';
  content: string;
  metadata?: Record<string, any>;
  created_at: string;
}

export interface Document {
  id: string;
  filename: string;
  file_path: string;
  file_type: 'pdf' | 'image' | 'text' | 'unknown';
  size_bytes: number;
  session_id?: string;
  has_page_index: boolean;
  page_index_id?: string;
  created_at: string;
  metadata?: Record<string, any>;
}

export interface PageIndexNode {
  title: string;
  node_id: string;
  start_index: number;
  end_index: number;
  summary: string;
  nodes: PageIndexNode[];
}

export interface PageIndexRecord {
  id: string;
  doc_id: string;
  doc_filename: string;
  tree: PageIndexNode;
  page_count: number;
  node_count: number;
  created_at: string;
}

// Agent event types from SSE stream
export type AgentEventType =
  | 'start'
  | 'thinking'
  | 'tool_call'
  | 'result'
  | 'executing'
  | 'complete'
  | 'error'
  | 'cancelled';

export interface AgentEvent {
  agent: string;
  event: AgentEventType;
  data?: any;
  timestamp?: number;
}

export interface ToolCallEvent {
  toolCallId: string;
  toolName: string;
  input?: any;
  result?: any;
  status: 'pending' | 'executing' | 'complete' | 'error';
  timestamp: number;
}

// Stream part types matching Vercel AI SDK
export type StreamPart =
  | { type: 'text-start'; id: string }
  | { type: 'text-delta'; id: string; delta: string }
  | { type: 'text-end'; id: string }
  | { type: 'tool-input-start'; toolCallId: string; toolName: string }
  | { type: 'tool-input-delta'; toolCallId: string; inputTextDelta: string }
  | { type: 'data-toolResult'; toolCallId: string; toolName: string; result: any }
  | { type: 'data-agentEvent'; agent: string; event: string; data?: any }
  | { type: 'message-start'; messageId: string }
  | { type: 'message-end'; messageId: string; finishReason: string }
  | { type: 'step-start'; stepType: string }
  | { type: 'step-finish' };

// UI state for agent panel
export interface AgentPanelState {
  activeAgents: string[];
  events: AgentEvent[];
  toolCalls: ToolCallEvent[];
  isStreaming: boolean;
}

// Document analysis report types
export type ReportType = 
  | 'executive_summary'
  | 'key_findings'
  | 'risk_analysis'
  | 'data_extraction'
  | 'comparison_ready';

export interface AnalysisRequest {
  doc_id: string;
  report_type: ReportType;
}

// Chat message with parts (Vercel AI SDK v5 style)
export interface UIMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  parts?: MessagePart[];
  createdAt?: Date;
}

export type MessagePart =
  | { type: 'text'; text: string }
  | { type: 'tool-agentEvent'; agent: string; event: string; data?: any }
  | { type: 'tool-toolResult'; toolCallId: string; toolName: string; result: any };
