'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { useChat } from '@ai-sdk/react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Send, Square, Paperclip, ChevronDown, Sparkles,
  FileText, Image, Brain, Eye, FileSearch, Cpu,
  ArrowDown, Loader2
} from 'lucide-react';
import { useAppStore } from '@/lib/store';
import MessageRenderer from './MessageRenderer';
import { BACKEND_URL } from '@/lib/api';

// Suggested prompts for empty state
const SUGGESTED_PROMPTS = [
  {
    icon: <FileSearch className="w-4 h-4 text-indigo-light" />,
    title: 'Analyze a document',
    prompt: 'Upload a PDF and ask me to build its PageIndex and extract key findings',
    tag: 'Document Analysis',
  },
  {
    icon: <Eye className="w-4 h-4 text-violet-light" />,
    title: 'OCR extraction',
    prompt: 'Extract text from an uploaded image with bounding box information',
    tag: 'OCR Agent',
  },
  {
    icon: <Cpu className="w-4 h-4 text-cyan-light" />,
    title: 'Image understanding',
    prompt: 'Describe what\'s in this image and extract any chart data or graphs',
    tag: 'Image Agent',
  },
  {
    icon: <Brain className="w-4 h-4 text-emerald-light" />,
    title: 'Multi-document comparison',
    prompt: 'Compare two documents and highlight key differences and similarities',
    tag: 'Doc Analyst',
  },
];

// Agent status indicator
function AgentStatusBar({ status, activeAgents }: { status: string; activeAgents: Set<string> }) {
  if (status === 'ready') return null;
  
  const agentLabel = activeAgents.size > 0 
    ? Array.from(activeAgents).map(a => a.replace('_agent', '').replace('_', ' ')).join(', ')
    : 'orchestrator';

  return (
    <motion.div
      initial={{ opacity: 0, y: 4 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 4 }}
      className="flex items-center gap-2 px-4 py-2 text-xs text-muted"
    >
      <div className="flex gap-0.5">
        {[0, 1, 2].map((i) => (
          <motion.div
            key={i}
            className="w-1 h-1 rounded-full bg-indigo-DEFAULT"
            animate={{ scale: [1, 1.5, 1] }}
            transition={{ duration: 0.6, delay: i * 0.2, repeat: Infinity }}
          />
        ))}
      </div>
      <span className="capitalize">{agentLabel} {status === 'streaming' ? 'responding' : 'thinking'}...</span>
    </motion.div>
  );
}

export default function ChatInterface() {
  const {
    currentSessionId,
    isStreaming,
    setStreaming,
    addAgentEvent,
    addToolCall,
    updateToolCall,
    clearAgentState,
    activeAgents,
    setActiveAgent,
    toolCalls,
  } = useAppStore();

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const [showScrollBtn, setShowScrollBtn] = useState(false);
  const [localToolCalls, setLocalToolCalls] = useState<Map<string, any>>(new Map());

  // Track tool calls per message
  const messageToolCallsRef = useRef<Map<string, any[]>>(new Map());

  const {
    messages,
    input,
    setInput,
    status,
    stop,
    sendMessage,
    setMessages,
  } = useChat({
    api: `${BACKEND_URL}/api/chat`,
    streamProtocol: 'data',
    headers: {
      'Content-Type': 'application/json',
    },
    body: {
      session_id: currentSessionId,
    },
    onFinish: () => {
      setStreaming(false);
      // Mark all active agents as inactive
      Array.from(activeAgents).forEach((a) => setActiveAgent(a, false));
    },
    onError: (err) => {
      console.error('Chat error:', err);
      setStreaming(false);
    },
    onData: (dataParts) => {
      for (const part of dataParts) {
        const p = part as any;
        
        // Agent events
        if (p.type === 'data-agentEvent') {
          addAgentEvent({
            agent: p.agent,
            event: p.event,
            data: p.data,
          });
          
          if (p.event === 'start' || p.event === 'thinking') {
            setActiveAgent(p.agent, true);
          } else if (p.event === 'complete' || p.event === 'error') {
            setActiveAgent(p.agent, false);
          }
        }
        
        // Tool results
        if (p.type === 'data-toolResult') {
          updateToolCall(p.toolCallId, {
            result: p.result,
            status: 'complete',
          });
          setLocalToolCalls(prev => {
            const next = new Map(prev);
            const existing = next.get(p.toolCallId) || {};
            next.set(p.toolCallId, { ...existing, result: p.result, status: 'complete' });
            return next;
          });
        }
        
        // Tool input start
        if (p.type === 'tool-input-start') {
          const tc = {
            toolCallId: p.toolCallId,
            toolName: p.toolName,
            status: 'executing' as const,
            timestamp: Date.now(),
          };
          addToolCall(tc);
          setLocalToolCalls(prev => {
            const next = new Map(prev);
            next.set(p.toolCallId, { ...tc, name: p.toolName, input: null });
            return next;
          });
        }
        
        // Tool input delta (accumulate)
        if (p.type === 'tool-input-delta') {
          setLocalToolCalls(prev => {
            const next = new Map(prev);
            const existing = next.get(p.toolCallId) || {};
            try {
              existing.input = JSON.parse(p.inputTextDelta);
            } catch {
              existing.input = p.inputTextDelta;
            }
            next.set(p.toolCallId, existing);
            return next;
          });
        }
      }
    },
  });

  const isLoading = status === 'submitted' || status === 'streaming';

  useEffect(() => {
    if (isLoading) setStreaming(true);
  }, [isLoading]);

  // Scroll to bottom
  useEffect(() => {
    if (messages.length > 0) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  // Clear messages on session change
  useEffect(() => {
    setMessages([]);
    clearAgentState();
    setLocalToolCalls(new Map());
  }, [currentSessionId]);

  // Auto-resize textarea
  function handleInputChange(e: React.ChangeEvent<HTMLTextAreaElement>) {
    setInput(e.target.value);
    e.target.style.height = 'auto';
    e.target.style.height = Math.min(e.target.scrollHeight, 180) + 'px';
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  }

  function handleSubmit() {
    if (!input.trim() || isLoading) return;
    if (!currentSessionId) {
      // Auto-create session handled by backend
    }
    sendMessage({ text: input });
    setInput('');
    if (inputRef.current) {
      inputRef.current.style.height = 'auto';
    }
  }

  // Get tool calls for a message (from our local tracking)
  function getMessageToolCalls(msgIndex: number) {
    // For the last assistant message if streaming
    if (msgIndex === messages.length - 1) {
      return Array.from(localToolCalls.values());
    }
    return [];
  }

  return (
    <div className="flex flex-col h-full relative">
      {/* Messages area */}
      <div
        className="flex-1 overflow-y-auto px-4 py-6 space-y-5"
        onScroll={(e) => {
          const el = e.currentTarget;
          const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 100;
          setShowScrollBtn(!atBottom);
        }}
      >
        {/* Empty state */}
        {messages.length === 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center justify-center min-h-[60vh] text-center"
          >
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-DEFAULT to-violet-DEFAULT flex items-center justify-center mb-6 glow-indigo animate-float">
              <Sparkles className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-snow mb-2 text-gradient-indigo">
              DocMind
            </h2>
            <p className="text-ghost text-sm mb-8 max-w-md">
              Multi-agent AI for intelligent document analysis. Ask me anything about your documents,
              or let me extract, analyze, and reason over complex files.
            </p>

            {/* Suggested prompts */}
            <div className="grid grid-cols-2 gap-3 max-w-xl w-full">
              {SUGGESTED_PROMPTS.map((p, i) => (
                <motion.button
                  key={i}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.08 }}
                  onClick={() => setInput(p.prompt)}
                  className="group text-left p-3.5 rounded-xl border border-border/60 bg-card/40 hover:bg-card/80 hover:border-indigo-DEFAULT/30 transition-all"
                >
                  <div className="flex items-center gap-2 mb-1.5">
                    {p.icon}
                    <span className="text-xs font-medium text-indigo-light">{p.tag}</span>
                  </div>
                  <p className="text-xs font-medium text-snow group-hover:text-white">{p.title}</p>
                  <p className="text-xs text-ghost mt-0.5 line-clamp-2">{p.prompt}</p>
                </motion.button>
              ))}
            </div>
          </motion.div>
        )}

        {/* Messages */}
        <AnimatePresence mode="popLayout">
          {messages.map((message, index) => (
            <MessageRenderer
              key={message.id}
              role={message.role as 'user' | 'assistant'}
              content={typeof message.content === 'string' 
                ? message.content 
                : JSON.stringify(message.content)}
              isStreaming={
                status === 'streaming' &&
                index === messages.length - 1 &&
                message.role === 'assistant'
              }
              toolCalls={getMessageToolCalls(index)}
            />
          ))}
        </AnimatePresence>

        {/* Agent status bar */}
        <AnimatePresence>
          {isLoading && (
            <AgentStatusBar status={status} activeAgents={activeAgents} />
          )}
        </AnimatePresence>

        <div ref={messagesEndRef} />
      </div>

      {/* Scroll to bottom button */}
      <AnimatePresence>
        {showScrollBtn && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            onClick={() => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })}
            className="absolute bottom-24 right-6 p-2 rounded-full bg-card border border-border/60 text-ghost hover:text-snow shadow-lg transition-colors"
          >
            <ArrowDown className="w-4 h-4" />
          </motion.button>
        )}
      </AnimatePresence>

      {/* Input area */}
      <div className="px-4 pb-4 pt-2">
        {/* Session indicator */}
        {!currentSessionId && (
          <p className="text-xs text-amber text-center mb-2">
            Start a conversation — a session will be created automatically
          </p>
        )}

        <div className="relative rounded-2xl border border-border/70 bg-card/80 focus-within:border-indigo-DEFAULT/50 transition-all backdrop-blur-sm">
          <textarea
            ref={inputRef}
            value={input}
            onChange={handleInputChange}
            onKeyDown={handleKeyDown}
            placeholder="Ask DocMind anything... (Shift+Enter for new line)"
            className="w-full bg-transparent text-snow text-sm placeholder-muted px-4 pt-3.5 pb-12 resize-none focus:outline-none max-h-[180px] leading-relaxed"
            rows={1}
            disabled={isLoading}
          />

          {/* Bottom toolbar */}
          <div className="absolute bottom-0 left-0 right-0 flex items-center justify-between px-3 pb-3">
            <div className="flex items-center gap-1">
              <span className="text-xs text-muted">
                {currentSessionId ? `Session: ${currentSessionId.slice(0, 8)}...` : 'No session'}
              </span>
            </div>

            <div className="flex items-center gap-2">
              {/* Character count */}
              {input.length > 0 && (
                <span className="text-xs text-muted">{input.length}</span>
              )}

              {/* Stop/Send button */}
              {isLoading ? (
                <button
                  onClick={stop}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose/15 border border-rose/30 text-rose text-xs font-medium hover:bg-rose/25 transition-all"
                >
                  <Square className="w-3 h-3 fill-current" />
                  Stop
                </button>
              ) : (
                <button
                  onClick={handleSubmit}
                  disabled={!input.trim()}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-DEFAULT/20 border border-indigo-DEFAULT/30 text-indigo-light text-xs font-medium hover:bg-indigo-DEFAULT/30 disabled:opacity-40 disabled:cursor-not-allowed transition-all"
                >
                  <Send className="w-3 h-3" />
                  Send
                </button>
              )}
            </div>
          </div>
        </div>

        <p className="text-center text-xs text-muted/50 mt-2">
          DocMind uses Claude AI · PageIndex reasoning · Multi-agent orchestration
        </p>
      </div>
    </div>
  );
}
