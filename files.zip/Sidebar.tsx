'use client';

import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  MessageSquare, Plus, Trash2, ChevronRight, 
  Sparkles, Menu, Settings, BookOpen
} from 'lucide-react';
import { useAppStore } from '@/lib/store';
import { sessionsApi } from '@/lib/api';
import { Session } from '@/lib/types';
import { formatDistanceToNow } from 'date-fns';

function SessionItem({
  session,
  active,
  onClick,
  onDelete,
}: {
  session: Session;
  active: boolean;
  onClick: () => void;
  onDelete: () => void;
}) {
  const [hovered, setHovered] = useState(false);
  const timeAgo = formatDistanceToNow(new Date(session.updated_at), { addSuffix: true });

  return (
    <motion.div
      layout
      initial={{ opacity: 0, x: -8 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -8 }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onClick={onClick}
      className={`group relative px-3 py-2.5 rounded-lg cursor-pointer transition-all ${
        active
          ? 'bg-indigo-glow border border-indigo-DEFAULT/30 text-snow'
          : 'hover:bg-surface/60 text-ghost hover:text-snow'
      }`}
    >
      <div className="flex items-center gap-2.5">
        <MessageSquare
          className={`w-3.5 h-3.5 flex-shrink-0 ${active ? 'text-indigo-light' : 'text-subtle'}`}
        />
        <div className="flex-1 min-w-0">
          <p className="text-xs font-medium truncate">{session.title}</p>
          <div className="flex items-center gap-2 mt-0.5">
            <span className="text-xs text-muted">{timeAgo}</span>
            {session.message_count > 0 && (
              <span className="text-xs text-muted">
                · {session.message_count} msgs
              </span>
            )}
          </div>
        </div>
        <AnimatePresence>
          {hovered && (
            <motion.button
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              onClick={(e) => {
                e.stopPropagation();
                onDelete();
              }}
              className="p-1 text-muted hover:text-rose transition-colors"
            >
              <Trash2 className="w-3 h-3" />
            </motion.button>
          )}
        </AnimatePresence>
      </div>
      {active && (
        <motion.div
          layoutId="activeSession"
          className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 bg-indigo-DEFAULT rounded-r"
        />
      )}
    </motion.div>
  );
}

export default function Sidebar() {
  const {
    sessions,
    currentSessionId,
    sidebarOpen,
    setSessions,
    addSession,
    setCurrentSession,
    removeSession,
    clearAgentState,
  } = useAppStore();

  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadSessions();
  }, []);

  async function loadSessions() {
    try {
      const data = await sessionsApi.list();
      setSessions(data.sessions);
    } catch (e) {
      console.error('Failed to load sessions', e);
    }
  }

  async function createSession() {
    setLoading(true);
    try {
      const session = await sessionsApi.create('New Conversation');
      addSession(session);
      setCurrentSession(session.id);
      clearAgentState();
    } catch (e) {
      console.error('Failed to create session', e);
    } finally {
      setLoading(false);
    }
  }

  async function deleteSession(id: string) {
    try {
      await sessionsApi.delete(id);
      removeSession(id);
    } catch (e) {
      console.error('Failed to delete session', e);
    }
  }

  if (!sidebarOpen) return null;

  return (
    <div className="flex flex-col w-56 h-full bg-ink border-r border-border/50 flex-shrink-0">
      {/* Brand */}
      <div className="px-4 py-4 border-b border-border/40">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-indigo-DEFAULT to-violet-DEFAULT flex items-center justify-center">
            <Sparkles className="w-3.5 h-3.5 text-white" />
          </div>
          <div>
            <h1 className="text-sm font-bold text-snow tracking-tight">DocMind</h1>
            <p className="text-xs text-muted">AI Document Intelligence</p>
          </div>
        </div>
      </div>

      {/* New chat button */}
      <div className="px-3 pt-3 pb-2">
        <button
          onClick={createSession}
          disabled={loading}
          className="w-full flex items-center gap-2 px-3 py-2 rounded-lg bg-indigo-DEFAULT/10 hover:bg-indigo-DEFAULT/20 border border-indigo-DEFAULT/20 hover:border-indigo-DEFAULT/40 text-indigo-light text-xs font-medium transition-all"
        >
          <Plus className="w-3.5 h-3.5" />
          New Conversation
        </button>
      </div>

      {/* Sessions list */}
      <div className="flex-1 overflow-y-auto px-2 py-1 space-y-0.5">
        {sessions.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <BookOpen className="w-7 h-7 text-muted mb-2" />
            <p className="text-xs text-muted">No conversations yet</p>
          </div>
        ) : (
          <AnimatePresence mode="popLayout">
            {sessions.map((session) => (
              <SessionItem
                key={session.id}
                session={session}
                active={session.id === currentSessionId}
                onClick={() => {
                  setCurrentSession(session.id);
                  clearAgentState();
                }}
                onDelete={() => deleteSession(session.id)}
              />
            ))}
          </AnimatePresence>
        )}
      </div>

      {/* Footer */}
      <div className="px-3 py-3 border-t border-border/40">
        <div className="flex items-center gap-2 text-xs text-muted">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald animate-pulse" />
          <span>Multi-agent system ready</span>
        </div>
        <div className="mt-1 text-xs text-muted/60">
          Orchestrator · OCR · Doc Analyst · Vision
        </div>
      </div>
    </div>
  );
}
