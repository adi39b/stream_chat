import { create } from 'zustand';
import { Session, Document, AgentEvent, ToolCallEvent, PageIndexRecord } from './types';

interface AppStore {
  // Sessions
  sessions: Session[];
  currentSessionId: string | null;
  setSessions: (sessions: Session[]) => void;
  addSession: (session: Session) => void;
  setCurrentSession: (id: string | null) => void;
  removeSession: (id: string) => void;

  // Documents
  documents: Document[];
  selectedDocId: string | null;
  setDocuments: (docs: Document[]) => void;
  addDocument: (doc: Document) => void;
  setSelectedDoc: (id: string | null) => void;
  updateDocument: (id: string, updates: Partial<Document>) => void;
  removeDocument: (id: string) => void;

  // PageIndex
  pageIndexes: Record<string, PageIndexRecord>; // doc_id -> record
  addPageIndex: (docId: string, record: PageIndexRecord) => void;

  // Agent panel state
  agentEvents: AgentEvent[];
  toolCalls: ToolCallEvent[];
  activeAgents: Set<string>;
  isStreaming: boolean;
  
  addAgentEvent: (event: AgentEvent) => void;
  addToolCall: (call: ToolCallEvent) => void;
  updateToolCall: (id: string, updates: Partial<ToolCallEvent>) => void;
  setStreaming: (streaming: boolean) => void;
  clearAgentState: () => void;
  setActiveAgent: (agent: string, active: boolean) => void;

  // UI
  sidebarOpen: boolean;
  agentPanelOpen: boolean;
  docPanelOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
  setAgentPanelOpen: (open: boolean) => void;
  setDocPanelOpen: (open: boolean) => void;
}

export const useAppStore = create<AppStore>((set) => ({
  // Sessions
  sessions: [],
  currentSessionId: null,
  setSessions: (sessions) => set({ sessions }),
  addSession: (session) => set((s) => ({ sessions: [session, ...s.sessions] })),
  setCurrentSession: (id) => set({ currentSessionId: id }),
  removeSession: (id) => set((s) => ({
    sessions: s.sessions.filter((sess) => sess.id !== id),
    currentSessionId: s.currentSessionId === id ? null : s.currentSessionId,
  })),

  // Documents
  documents: [],
  selectedDocId: null,
  setDocuments: (docs) => set({ documents: docs }),
  addDocument: (doc) => set((s) => ({ documents: [doc, ...s.documents] })),
  setSelectedDoc: (id) => set({ selectedDocId: id }),
  updateDocument: (id, updates) =>
    set((s) => ({
      documents: s.documents.map((d) => (d.id === id ? { ...d, ...updates } : d)),
    })),
  removeDocument: (id) =>
    set((s) => ({
      documents: s.documents.filter((d) => d.id !== id),
      selectedDocId: s.selectedDocId === id ? null : s.selectedDocId,
    })),

  // PageIndex
  pageIndexes: {},
  addPageIndex: (docId, record) =>
    set((s) => ({ pageIndexes: { ...s.pageIndexes, [docId]: record } })),

  // Agent state
  agentEvents: [],
  toolCalls: [],
  activeAgents: new Set(),
  isStreaming: false,

  addAgentEvent: (event) =>
    set((s) => ({
      agentEvents: [
        ...s.agentEvents.slice(-50), // Keep last 50 events
        { ...event, timestamp: Date.now() },
      ],
    })),

  addToolCall: (call) =>
    set((s) => ({
      toolCalls: [
        ...s.toolCalls.filter((c) => c.toolCallId !== call.toolCallId),
        call,
      ],
    })),

  updateToolCall: (id, updates) =>
    set((s) => ({
      toolCalls: s.toolCalls.map((c) =>
        c.toolCallId === id ? { ...c, ...updates } : c
      ),
    })),

  setStreaming: (streaming) => set({ isStreaming: streaming }),

  clearAgentState: () =>
    set({
      agentEvents: [],
      toolCalls: [],
      activeAgents: new Set(),
      isStreaming: false,
    }),

  setActiveAgent: (agent, active) =>
    set((s) => {
      const next = new Set(s.activeAgents);
      if (active) next.add(agent);
      else next.delete(agent);
      return { activeAgents: next };
    }),

  // UI
  sidebarOpen: true,
  agentPanelOpen: true,
  docPanelOpen: false,
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  setAgentPanelOpen: (open) => set({ agentPanelOpen: open }),
  setDocPanelOpen: (open) => set({ docPanelOpen: open }),
}));
