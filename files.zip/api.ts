const BASE_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:8000';

export async function apiGet<T>(path: string): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`);
  if (!res.ok) throw new Error(`API error ${res.status}: ${await res.text()}`);
  return res.json();
}

export async function apiPost<T>(path: string, body?: any): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) throw new Error(`API error ${res.status}: ${await res.text()}`);
  return res.json();
}

export async function apiDelete(path: string): Promise<void> {
  const res = await fetch(`${BASE_URL}${path}`, { method: 'DELETE' });
  if (!res.ok) throw new Error(`API error ${res.status}`);
}

// Document upload
export async function uploadDocument(file: File, sessionId?: string) {
  const form = new FormData();
  form.append('file', file);
  if (sessionId) form.append('session_id', sessionId);

  const res = await fetch(`${BASE_URL}/api/documents/upload`, {
    method: 'POST',
    body: form,
  });
  if (!res.ok) throw new Error(`Upload failed: ${await res.text()}`);
  return res.json();
}

// Sessions
export const sessionsApi = {
  list: () => apiGet<{ sessions: any[] }>('/api/sessions'),
  create: (title?: string) => apiPost<any>('/api/sessions', { title }),
  get: (id: string) => apiGet<any>(`/api/sessions/${id}`),
  delete: (id: string) => apiDelete(`/api/sessions/${id}`),
  messages: (id: string) => apiGet<{ messages: any[] }>(`/api/sessions/${id}/messages`),
};

// Documents
export const documentsApi = {
  list: (sessionId?: string) =>
    apiGet<{ documents: any[] }>(`/api/documents${sessionId ? `?session_id=${sessionId}` : ''}`),
  get: (id: string) => apiGet<any>(`/api/documents/${id}`),
  delete: (id: string) => apiDelete(`/api/documents/${id}`),
  buildIndex: (id: string) => `${BASE_URL}/api/documents/${id}/index`,
  getIndex: (id: string) => apiGet<any>(`/api/documents/${id}/index`),
};

export const BACKEND_URL = BASE_URL;
