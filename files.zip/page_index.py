"""
PageIndex Implementation
========================
Builds hierarchical tree-structured indexes from PDF documents.
Inspired by VectifyAI/PageIndex — vectorless, reasoning-based RAG.

The tree looks like:
{
  "title": "Document Root",
  "node_id": "0001",
  "start_index": 1,
  "end_index": 5,
  "summary": "...",
  "nodes": [
    {
      "title": "Chapter 1",
      "node_id": "0002",
      "start_index": 1,
      "end_index": 2,
      "summary": "...",
      "nodes": [...]
    }
  ]
}
"""

import json
import re
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pypdf
from langchain_anthropic import ChatAnthropic
from langchain_core.messages import HumanMessage, SystemMessage


# ── Page extraction ───────────────────────────────────────────────────────────

def extract_pdf_pages(file_path: str, max_chars_per_page: int = 3000) -> List[Dict]:
    """Extract text from each PDF page with page numbers."""
    pages = []
    try:
        reader = pypdf.PdfReader(file_path)
        for i, page in enumerate(reader.pages):
            text = page.extract_text() or ""
            # Truncate very long pages
            if len(text) > max_chars_per_page:
                text = text[:max_chars_per_page] + "...[truncated]"
            pages.append({
                "page_num": i + 1,
                "text": text.strip(),
            })
    except Exception as e:
        raise RuntimeError(f"Failed to extract PDF pages: {e}")
    return pages


def extract_text_chunks(pages: List[Dict], chunk_size: int = 10) -> List[Dict]:
    """Group pages into chunks for TOC analysis."""
    chunks = []
    for i in range(0, len(pages), chunk_size):
        group = pages[i : i + chunk_size]
        combined = "\n\n---\n\n".join(
            f"[Page {p['page_num']}]\n{p['text']}" for p in group
        )
        chunks.append({
            "start_page": group[0]["page_num"],
            "end_page": group[-1]["page_num"],
            "text": combined,
        })
    return chunks


# ── LLM-based tree builder ────────────────────────────────────────────────────

TREE_BUILDER_SYSTEM = """You are a document indexing expert. Your task is to analyze document pages 
and build a hierarchical tree-structured index (like a table of contents) optimized for LLM retrieval.

The tree should:
1. Reflect the natural logical structure of the document
2. Have clear hierarchical sections and subsections
3. Include accurate page ranges (start_index, end_index) for each node
4. Include a brief, informative summary for each node
5. Use human-readable titles that describe the content

Output ONLY valid JSON with no explanation."""

TREE_CHUNK_PROMPT = """Analyze these document pages and identify the major sections, subsections.

Pages provided: {start_page} to {end_page}

Document content:
{text}

Build a JSON structure representing the hierarchical index of these pages.
Each node MUST have these exact fields:
- "title": descriptive section title
- "node_id": unique string like "0001", "0002", etc (sequential)
- "start_index": starting page number (integer)
- "end_index": ending page number (integer)  
- "summary": 1-2 sentence summary of what this section contains
- "nodes": array of child nodes (can be empty [])

Start node_ids from: {start_id}

Return ONLY the JSON array of top-level nodes for pages {start_page}-{end_page}. Example:
[
  {{
    "title": "Introduction",
    "node_id": "0001",
    "start_index": 1,
    "end_index": 3,
    "summary": "Overview of the document and key objectives.",
    "nodes": [
      {{
        "title": "Background",
        "node_id": "0002", 
        "start_index": 1,
        "end_index": 2,
        "summary": "Historical context and motivation.",
        "nodes": []
      }}
    ]
  }}
]"""

MERGE_PROMPT = """You are merging multiple document section trees into one coherent hierarchical index.

Document: {doc_title}
Total pages: {total_pages}

Individual section trees (JSON):
{section_trees}

Merge these into a SINGLE root tree node representing the entire document.
- Create a sensible top-level grouping
- Preserve all existing nodes as children
- Ensure node_ids are unique (renumber if needed, keeping format "0001")
- The root node should span all pages (start_index=1, end_index={total_pages})

Return ONLY a single JSON object (the root node):
{{
  "title": "<document title>",
  "node_id": "0000",
  "start_index": 1,
  "end_index": {total_pages},
  "summary": "...",
  "nodes": [...]
}}"""

RETRIEVAL_PROMPT = """You are performing tree-search retrieval over a document index.

Question: {question}

Document tree structure (JSON):
{tree}

Find all nodes that are likely to contain the answer to the question.
Think step by step about which sections/subsections are most relevant.

Reply in this exact JSON format:
{{
  "thinking": "<your reasoning about where to look>",
  "node_list": ["node_id_1", "node_id_2", ...]
}}"""


class PageIndexBuilder:
    """Builds hierarchical tree indexes from PDF documents."""

    def __init__(self, model: str = "claude-3-5-haiku-20241022"):
        self.llm = ChatAnthropic(model=model, max_tokens=4096)
        self._node_counter = 1

    def _next_node_ids(self, count: int) -> List[str]:
        ids = [f"{self._node_counter + i:04d}" for i in range(count)]
        self._node_counter += count
        return ids

    def _parse_json(self, text: str) -> Any:
        """Robustly parse JSON from LLM output."""
        # Try direct parse
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            pass
        # Extract from code blocks
        match = re.search(r"```(?:json)?\s*([\s\S]+?)\s*```", text)
        if match:
            try:
                return json.loads(match.group(1))
            except json.JSONDecodeError:
                pass
        # Find JSON array or object
        for pattern in [r"(\[[\s\S]+\])", r"(\{[\s\S]+\})"]:
            match = re.search(pattern, text)
            if match:
                try:
                    return json.loads(match.group(1))
                except json.JSONDecodeError:
                    pass
        return None

    async def build_tree(
        self,
        file_path: str,
        doc_title: str = "Document",
        progress_callback=None,
    ) -> Tuple[Dict, int]:
        """
        Build a PageIndex tree from a PDF file.
        Returns (tree_dict, page_count).
        """
        # Step 1: Extract pages
        if progress_callback:
            await progress_callback("Extracting PDF pages...")
        pages = extract_pdf_pages(file_path)
        page_count = len(pages)

        if page_count == 0:
            raise ValueError("PDF has no extractable text pages")

        # Step 2: For small docs, build tree in one shot
        if page_count <= 15:
            if progress_callback:
                await progress_callback(f"Building index for {page_count} pages...")
            combined = "\n\n---\n\n".join(
                f"[Page {p['page_num']}]\n{p['text']}" for p in pages
            )
            root = await self._build_chunk_tree(
                combined, 1, page_count, start_id=1
            )
        else:
            # Step 3: For larger docs, chunk and merge
            chunks = extract_text_chunks(pages, chunk_size=10)
            section_trees = []
            id_counter = 1

            for i, chunk in enumerate(chunks):
                if progress_callback:
                    await progress_callback(
                        f"Indexing pages {chunk['start_page']}-{chunk['end_page']} "
                        f"({i+1}/{len(chunks)})..."
                    )
                nodes = await self._build_chunk_tree(
                    chunk["text"],
                    chunk["start_page"],
                    chunk["end_page"],
                    start_id=id_counter,
                )
                if nodes:
                    # Count nodes for next id
                    id_counter += self._count_nodes(nodes) + 1
                    section_trees.append(nodes)

            if progress_callback:
                await progress_callback("Merging section trees...")
            root = await self._merge_trees(section_trees, doc_title, page_count)

        # Ensure root is a dict (not a list)
        if isinstance(root, list):
            root = {
                "title": doc_title,
                "node_id": "0000",
                "start_index": 1,
                "end_index": page_count,
                "summary": f"Complete document index for '{doc_title}' ({page_count} pages)",
                "nodes": root,
            }
        elif not isinstance(root, dict):
            root = {
                "title": doc_title,
                "node_id": "0000",
                "start_index": 1,
                "end_index": page_count,
                "summary": f"Document: {doc_title}",
                "nodes": [],
            }

        return root, page_count

    async def _build_chunk_tree(
        self, text: str, start_page: int, end_page: int, start_id: int = 1
    ) -> Any:
        """Build tree nodes for a chunk of pages."""
        prompt = TREE_CHUNK_PROMPT.format(
            start_page=start_page,
            end_page=end_page,
            text=text[:8000],  # Safety truncation
            start_id=f"{start_id:04d}",
        )
        messages = [
            SystemMessage(content=TREE_BUILDER_SYSTEM),
            HumanMessage(content=prompt),
        ]
        response = await self.llm.ainvoke(messages)
        return self._parse_json(response.content) or []

    async def _merge_trees(
        self, section_trees: List[Any], doc_title: str, total_pages: int
    ) -> Dict:
        """Merge multiple section trees into one root."""
        trees_json = json.dumps(section_trees, indent=2)[:6000]
        prompt = MERGE_PROMPT.format(
            doc_title=doc_title,
            total_pages=total_pages,
            section_trees=trees_json,
        )
        messages = [
            SystemMessage(content=TREE_BUILDER_SYSTEM),
            HumanMessage(content=prompt),
        ]
        response = await self.llm.ainvoke(messages)
        result = self._parse_json(response.content)
        if isinstance(result, dict):
            return result
        # Fallback: wrap in root
        return {
            "title": doc_title,
            "node_id": "0000",
            "start_index": 1,
            "end_index": total_pages,
            "summary": f"Complete index of {doc_title}",
            "nodes": section_trees if isinstance(section_trees, list) else [],
        }

    def _count_nodes(self, tree: Any) -> int:
        if isinstance(tree, dict):
            return 1 + sum(self._count_nodes(c) for c in tree.get("nodes", []))
        if isinstance(tree, list):
            return sum(self._count_nodes(n) for n in tree)
        return 0


# ── Reasoning-based retrieval ─────────────────────────────────────────────────

class PageIndexRetriever:
    """Performs tree-search retrieval over a PageIndex tree."""

    def __init__(self, model: str = "claude-3-5-haiku-20241022"):
        self.llm = ChatAnthropic(model=model, max_tokens=2048)

    async def retrieve_nodes(
        self, question: str, tree: Dict
    ) -> Tuple[List[str], str]:
        """
        Returns (node_ids, thinking) - node IDs most relevant to the question.
        """
        tree_json = json.dumps(tree, indent=2)
        # Truncate for context safety
        if len(tree_json) > 8000:
            tree_json = tree_json[:8000] + "...[truncated]"

        prompt = RETRIEVAL_PROMPT.format(
            question=question,
            tree=tree_json,
        )
        response = await self.llm.ainvoke([HumanMessage(content=prompt)])

        # Parse response
        text = response.content
        try:
            # Try to parse JSON
            match = re.search(r"\{[\s\S]+\}", text)
            if match:
                data = json.loads(match.group(0))
                return data.get("node_list", []), data.get("thinking", "")
        except Exception:
            pass
        return [], text

    def extract_page_content(
        self, pages: List[Dict], node: Dict
    ) -> str:
        """Get page text for the given node's page range."""
        start = node.get("start_index", 1)
        end = node.get("end_index", start)
        relevant = [
            p for p in pages
            if start <= p["page_num"] <= end
        ]
        return "\n\n".join(
            f"[Page {p['page_num']}]\n{p['text']}" for p in relevant
        )
