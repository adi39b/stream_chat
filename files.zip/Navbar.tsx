'use client';

import { 
  Menu, Activity, FolderOpen, Network, 
  Sun, Moon, Settings, Sparkles
} from 'lucide-react';
import { useAppStore } from '@/lib/store';
import { motion } from 'framer-motion';

export default function Navbar() {
  const {
    sidebarOpen, setSidebarOpen,
    agentPanelOpen, setAgentPanelOpen,
    docPanelOpen, setDocPanelOpen,
    isStreaming,
    currentSessionId,
    sessions,
  } = useAppStore();

  const currentSession = sessions.find(s => s.id === currentSessionId);

  return (
    <div className="h-12 flex items-center justify-between px-3 border-b border-border/50 bg-ink/80 backdrop-blur-md flex-shrink-0">
      {/* Left */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className={`p-1.5 rounded-lg transition-colors ${
            sidebarOpen ? 'bg-surface text-snow' : 'text-subtle hover:text-snow hover:bg-surface/60'
          }`}
          title="Toggle sidebar"
        >
          <Menu className="w-4 h-4" />
        </button>

        {/* Breadcrumb */}
        <div className="flex items-center gap-1.5 text-xs text-muted">
          <Sparkles className="w-3 h-3 text-indigo-light" />
          <span className="text-indigo-light font-medium">DocMind</span>
          {currentSession && (
            <>
              <span>/</span>
              <span className="text-ghost truncate max-w-[200px]">{currentSession.title}</span>
            </>
          )}
        </div>
      </div>

      {/* Center - streaming indicator */}
      {isStreaming && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-glow border border-indigo-DEFAULT/20 text-xs text-indigo-light"
        >
          <div className="flex gap-0.5">
            {[0, 1, 2].map((i) => (
              <motion.div
                key={i}
                className="w-1 h-1 rounded-full bg-indigo-light"
                animate={{ scale: [1, 1.4, 1] }}
                transition={{ duration: 0.5, delay: i * 0.15, repeat: Infinity }}
              />
            ))}
          </div>
          Agents running
        </motion.div>
      )}

      {/* Right - panel toggles */}
      <div className="flex items-center gap-1">
        <button
          onClick={() => setDocPanelOpen(!docPanelOpen)}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
            docPanelOpen
              ? 'bg-surface text-snow border border-border/60'
              : 'text-subtle hover:text-snow hover:bg-surface/60'
          }`}
          title="Documents & PageIndex"
        >
          <FolderOpen className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Docs</span>
        </button>

        <button
          onClick={() => setAgentPanelOpen(!agentPanelOpen)}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
            agentPanelOpen
              ? 'bg-surface text-snow border border-border/60'
              : 'text-subtle hover:text-snow hover:bg-surface/60'
          }`}
          title="Agent Activity"
        >
          <Activity className={`w-3.5 h-3.5 ${isStreaming ? 'text-emerald animate-pulse' : ''}`} />
          <span className="hidden sm:inline">Agents</span>
        </button>
      </div>
    </div>
  );
}
