'use client';

import { useEffect } from 'react';
import { motion } from 'framer-motion';
import { useAppStore } from '@/lib/store';
import { sessionsApi, documentsApi } from '@/lib/api';
import Sidebar from '@/components/chat/Sidebar';
import ChatInterface from '@/components/chat/ChatInterface';
import AgentPanel from '@/components/agents/AgentPanel';
import DocumentPanel from '@/components/documents/DocumentPanel';
import Navbar from '@/components/ui/Navbar';

export default function Home() {
  const {
    setSessions,
    setDocuments,
    setCurrentSession,
    currentSessionId,
    sidebarOpen,
    agentPanelOpen,
    docPanelOpen,
  } = useAppStore();

  // Load initial data
  useEffect(() => {
    async function init() {
      try {
        const [sessionsData, docsData] = await Promise.all([
          sessionsApi.list().catch(() => ({ sessions: [] })),
          documentsApi.list().catch(() => ({ documents: [] })),
        ]);
        setSessions(sessionsData.sessions);
        setDocuments(docsData.documents);
        
        // Auto-select most recent session
        if (sessionsData.sessions.length > 0 && !currentSessionId) {
          setCurrentSession(sessionsData.sessions[0].id);
        }
      } catch (e) {
        console.error('Init failed:', e);
      }
    }
    init();
  }, []);

  return (
    <div className="flex flex-col h-screen overflow-hidden bg-void relative">
      {/* Background mesh gradient */}
      <div className="absolute inset-0 bg-gradient-mesh pointer-events-none" />
      
      {/* Subtle noise texture */}
      <div
        className="absolute inset-0 pointer-events-none opacity-30"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.75' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.05'/%3E%3C/svg%3E")`,
        }}
      />

      {/* Navbar */}
      <Navbar />

      {/* Main layout */}
      <div className="flex flex-1 overflow-hidden relative">
        {/* Sidebar */}
        <motion.div
          initial={false}
          animate={{
            width: sidebarOpen ? 224 : 0,
            opacity: sidebarOpen ? 1 : 0,
          }}
          transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
          className="overflow-hidden flex-shrink-0"
        >
          {sidebarOpen && <Sidebar />}
        </motion.div>

        {/* Document panel */}
        <motion.div
          initial={false}
          animate={{
            width: docPanelOpen ? 'auto' : 0,
            opacity: docPanelOpen ? 1 : 0,
          }}
          transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
          className="overflow-hidden flex-shrink-0"
        >
          {docPanelOpen && (
            <div className="h-full flex">
              <DocumentPanel />
            </div>
          )}
        </motion.div>

        {/* Chat area */}
        <div className="flex-1 flex flex-col min-w-0 relative">
          <ChatInterface />
        </div>

        {/* Agent panel */}
        <motion.div
          initial={false}
          animate={{
            width: agentPanelOpen ? 288 : 0,
            opacity: agentPanelOpen ? 1 : 0,
          }}
          transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
          className="overflow-hidden flex-shrink-0"
        >
          {agentPanelOpen && <AgentPanel />}
        </motion.div>
      </div>
    </div>
  );
}
