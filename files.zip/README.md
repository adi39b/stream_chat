# DocMind — AI Document Intelligence Platform

> Multi-agent AI system for intelligent document analysis, OCR, and reasoning-based retrieval using PageIndex.

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                          FRONTEND (Next.js)                         │
│                                                                     │
│  ┌──────────┐  ┌───────────────┐  ┌──────────────┐  ┌──────────┐  │
│  │ Sidebar  │  │ Chat (useChat)│  │  Doc Panel   │  │  Agent   │  │
│  │ Sessions │  │ Vercel AI SDK │  │ PageIndex UI │  │  Panel   │  │
│  └──────────┘  └──────┬────────┘  └──────────────┘  └──────────┘  │
└──────────────────────┬┴───────────────────────────────────────────┘
                       │ SSE (Vercel AI Data Stream Protocol)
                       ▼
┌─────────────────────────────────────────────────────────────────────┐
│                    BACKEND (FastAPI + LangGraph)                     │
│                                                                     │
│  ┌───────────────────────────────────────────────────────────────┐  │
│  │                  LangGraph State Machine                      │  │
│  │                                                               │  │
│  │   ┌──────────────┐    delegates to    ┌──────────────────┐   │  │
│  │   │ Orchestrator │ ──────────────────▶│  Specialized     │   │  │
│  │   │  (Claude)    │ ◀────────────────── │  Agents          │   │  │
│  │   └──────────────┘    results          └────────┬─────────┘   │  │
│  │                                                  │             │  │
│  │          ┌─────────────────────────────┬─────────┘             │  │
│  │          │                             │                       │  │
│  │   ┌──────┴───────┐  ┌──────────────┐  ┌───────────────────┐   │  │
│  │   │  OCR Agent   │  │  Doc Analyst │  │   Image Agent     │   │  │
│  │   │  (Vision)    │  │  (PageIndex) │  │   (Vision LLM)    │   │  │
│  │   └──────┬───────┘  └──────┬───────┘  └──────────┬────────┘   │  │
│  │          │                 │                      │            │  │
│  │   ┌──────┴───────┐  ┌──────┴───────┐  ┌──────────┴────────┐   │  │
│  │   │  ocr_tools   │  │  doc_tools   │  │   image_tools     │   │  │
│  │   └──────────────┘  └──────────────┘  └───────────────────┘   │  │
│  └───────────────────────────────────────────────────────────────┘  │
│                                                                     │
│  ┌────────────────────────┐  ┌──────────────────────────────────┐   │
│  │  TinyDB Storage        │  │  PageIndex Tree Builder          │   │
│  │  - Sessions            │  │  - PDF → Hierarchical Tree       │   │
│  │  - Messages            │  │  - LLM reasoning retrieval       │   │
│  │  - Documents           │  │  - Node-based page lookup        │   │
│  │  - PageIndex Trees     │  └──────────────────────────────────┘   │
│  └────────────────────────┘                                         │
└─────────────────────────────────────────────────────────────────────┘
```

## 🤖 Agents

### Orchestrator Agent
- **Model**: Claude 3.5 Sonnet
- **Role**: Main coordinator — understands user intent, delegates to specialists
- **Has access to**: All tools across all agents
- **Streams**: Tokens + tool call metadata in real-time

### OCR Agent  
- **Model**: Claude 3.5 Haiku (fast)
- **Role**: Extract text from PDFs and images
- **Tools**: `ocr_extract_text`, `ocr_extract_with_bounding_boxes`
- **Output**: Structured text with spatial/layout info, bounding boxes

### Document Analyst Agent
- **Model**: Claude 3.5 Sonnet
- **Role**: Deep document analysis using PageIndex reasoning
- **Tools**: `build_document_index`, `query_document`, `generate_document_report`, `compare_documents`, `list_available_documents`
- **Key feature**: PageIndex tree-search retrieval (no vectors needed!)

### Image Analysis Agent
- **Model**: Claude 3.5 Sonnet (vision)
- **Role**: Comprehensive image understanding
- **Tools**: `analyze_image`, `extract_charts_data`
- **Output**: Detailed descriptions, chart data, object detection

## 📑 PageIndex Storage

DocMind implements the **PageIndex** framework — a vectorless, reasoning-based RAG system:

```
Document
├── Tree (JSON, stored in TinyDB)
│   ├── Node: "Introduction" (pages 1-5)
│   │   ├── Node: "Background" (pages 1-2)
│   │   └── Node: "Objectives" (pages 3-5)
│   ├── Node: "Methodology" (pages 6-20)
│   │   ├── Node: "Data Collection" (pages 6-12)
│   │   └── Node: "Analysis Framework" (pages 13-20)
│   └── Node: "Results" (pages 21-45)
│       └── ...
```

**How retrieval works:**
1. Build tree index (LLM analyzes document structure)
2. On query: LLM reasons over tree to find relevant nodes
3. Extract page content from relevant nodes only
4. Generate answer with precise page citations

**Why it's better than vector RAG:**
- No embedding model needed
- Respects document structure
- Can follow cross-references ("see Appendix G")
- Precise page-level citations
- Works perfectly for: financial reports, legal docs, academic papers

## 🚀 Setup

### Prerequisites
- Python 3.11+
- Node.js 20+
- Anthropic API key (required)
- OpenAI API key (optional)

### Backend

```bash
cd backend
cp .env.example .env
# Edit .env with your API keys

pip install -r requirements.txt
python main.py
# Server running at http://localhost:8000
```

### Frontend

```bash
cd frontend
cp .env.example .env.local
# Edit .env.local if needed

npm install
npm run dev
# App running at http://localhost:3000
```

### Docker Compose (recommended)

```bash
# Set env vars
export ANTHROPIC_API_KEY=your_key_here

docker-compose up --build
# App at http://localhost:3000
# API at http://localhost:8000
```

## 🎯 Key Features

### Real-time Streaming
- Token-by-token streaming from LLM to chat UI
- Live agent activity feed (who's thinking, what tools are running)
- Tool call state shown as expandable cards
- Stream in **Vercel AI SDK data stream protocol** format

### Tool Call Visualization
- Every tool call shown in Agent Panel with:
  - Tool name and agent
  - Input parameters (expandable)
  - Result (expandable, JSON-formatted)
  - Status: pending → executing → complete

### Document Intelligence
- Upload PDF, image, or text files
- Build PageIndex tree (visual tree viewer in UI)
- Query documents with reasoning-based retrieval
- Generate executive summaries, risk analyses, key findings reports
- Compare multiple documents side-by-side

### Chat Session Management
- Persistent sessions stored in TinyDB
- Message history across sessions
- Auto-title sessions
- Easy session switching

## 📡 API Reference

### POST `/api/chat`
Stream LangGraph agent response.
```json
{
  "messages": [{"role": "user", "content": "Analyze document X"}],
  "session_id": "optional-session-id"
}
```
Returns: SSE stream (Vercel AI data stream protocol)

### POST `/api/documents/upload`
Upload document for analysis.
- Form data: `file` + optional `session_id`

### POST `/api/documents/{doc_id}/index`
Build PageIndex tree (SSE progress stream).

### GET `/api/documents/{doc_id}/index`
Get stored PageIndex tree.

## 🔮 Advanced Usage

### Ask for specific reports
- "Generate an executive summary of [document]"
- "Find all risk factors in [document]"
- "Extract all financial data from [document]"
- "Compare [doc1] and [doc2] focusing on methodology"

### OCR workflows
- "Extract text from page 3 of [document] with bounding boxes"
- "What text is in this uploaded image?"

### Multi-document analysis
- "Index all my documents and tell me which ones mention X"
- "Compare the financial outlook across all uploaded reports"
