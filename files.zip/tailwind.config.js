/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './lib/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        // DocMind dark theme palette
        void: '#050507',
        ink: '#0b0b10',
        deep: '#111118',
        surface: '#17171f',
        card: '#1e1e28',
        border: '#2a2a38',
        muted: '#3d3d52',
        subtle: '#6b6b85',
        ghost: '#9494ab',
        silver: '#c4c4d4',
        snow: '#e8e8f0',
        white: '#f5f5ff',

        // Accent palette
        indigo: {
          DEFAULT: '#6366f1',
          light: '#818cf8',
          glow: 'rgba(99,102,241,0.15)',
          dim: '#4338ca',
        },
        violet: {
          DEFAULT: '#7c3aed',
          light: '#a78bfa',
          glow: 'rgba(124,58,237,0.15)',
        },
        cyan: {
          DEFAULT: '#06b6d4',
          light: '#67e8f9',
          glow: 'rgba(6,182,212,0.12)',
        },
        emerald: {
          DEFAULT: '#10b981',
          light: '#6ee7b7',
          glow: 'rgba(16,185,129,0.12)',
        },
        amber: {
          DEFAULT: '#f59e0b',
          light: '#fcd34d',
          glow: 'rgba(245,158,11,0.12)',
        },
        rose: {
          DEFAULT: '#f43f5e',
          light: '#fda4af',
          glow: 'rgba(244,63,94,0.12)',
        },
      },
      fontFamily: {
        sans: ['var(--font-geist-sans)', 'system-ui', 'sans-serif'],
        mono: ['var(--font-geist-mono)', 'monospace'],
        display: ['var(--font-cal-sans)', 'var(--font-geist-sans)', 'sans-serif'],
      },
      animation: {
        'fade-in': 'fadeIn 0.3s ease forwards',
        'slide-up': 'slideUp 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards',
        'slide-in-right': 'slideInRight 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards',
        'pulse-glow': 'pulseGlow 2s ease-in-out infinite',
        'shimmer': 'shimmer 1.5s infinite',
        'spin-slow': 'spin 3s linear infinite',
        'bounce-subtle': 'bounceSubtle 1s ease-in-out infinite',
        'typing': 'typing 0.8s steps(3, end) infinite',
        'float': 'float 3s ease-in-out infinite',
      },
      keyframes: {
        fadeIn: {
          from: { opacity: '0' },
          to: { opacity: '1' },
        },
        slideUp: {
          from: { opacity: '0', transform: 'translateY(16px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        slideInRight: {
          from: { opacity: '0', transform: 'translateX(16px)' },
          to: { opacity: '1', transform: 'translateX(0)' },
        },
        pulseGlow: {
          '0%, 100%': { boxShadow: '0 0 0 0 rgba(99,102,241,0)' },
          '50%': { boxShadow: '0 0 20px 4px rgba(99,102,241,0.3)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
        bounceSubtle: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-3px)' },
        },
        typing: {
          '0%, 100%': { content: '"."' },
          '33%': { content: '".."' },
          '66%': { content: '"..."' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-8px)' },
        },
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'gradient-mesh': 'radial-gradient(at 40% 20%, rgba(99,102,241,0.08) 0px, transparent 50%), radial-gradient(at 80% 0%, rgba(124,58,237,0.06) 0px, transparent 50%), radial-gradient(at 0% 50%, rgba(6,182,212,0.04) 0px, transparent 50%)',
        'shimmer': 'linear-gradient(90deg, transparent, rgba(255,255,255,0.04), transparent)',
      },
    },
  },
  plugins: [],
};
