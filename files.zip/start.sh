#!/bin/bash
set -e

echo "🚀 Starting DocMind..."

# Check for API key
if [ -z "$ANTHROPIC_API_KEY" ]; then
    if [ -f backend/.env ]; then
        export $(cat backend/.env | grep -v '#' | xargs)
    else
        echo "❌ Please set ANTHROPIC_API_KEY or create backend/.env"
        exit 1
    fi
fi

# Start backend in background
echo "🐍 Starting FastAPI backend on :8000..."
cd backend
pip install -r requirements.txt -q 2>&1 | tail -5
python main.py &
BACKEND_PID=$!
cd ..

# Wait for backend
sleep 3
echo "✅ Backend started (PID: $BACKEND_PID)"

# Start frontend
echo "⚛️  Starting Next.js frontend on :3000..."
cd frontend
if [ ! -d "node_modules" ]; then
    npm install
fi
npm run dev &
FRONTEND_PID=$!
cd ..

echo ""
echo "╔════════════════════════════════════════╗"
echo "║           DocMind Running!             ║"
echo "╠════════════════════════════════════════╣"
echo "║  Frontend: http://localhost:3000       ║"
echo "║  Backend:  http://localhost:8000       ║"
echo "║  API Docs: http://localhost:8000/docs  ║"
echo "╚════════════════════════════════════════╝"

# Wait and cleanup
trap "kill $BACKEND_PID $FRONTEND_PID 2>/dev/null" EXIT
wait
