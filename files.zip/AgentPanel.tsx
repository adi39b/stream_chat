'use client';

import { useAppStore } from '@/lib/store';
import { AgentEvent, ToolCallEvent } from '@/lib/types';
import { 
  Brain, Cpu, FileSearch, Eye, Wrench, ChevronRight, 
  CheckCircle, AlertCircle, Clock, Zap, Activity
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useState } from 'react';

const AGENT_ICONS: Record<string, React.ReactNode> = {
  orchestrator: <Brain className="w-3.5 h-3.5" />,
  ocr_agent: <Eye className="w-3.5 h-3.5" />,
  doc_agent: <FileSearch className="w-3.5 h-3.5" />,
  image_agent: <Cpu className="w-3.5 h-3.5" />,
  tools: <Wrench className="w-3.5 h-3.5" />,
};

const AGENT_COLORS: Record<string, string> = {
  orchestrator: 'text-indigo-light border-indigo-DEFAULT/30 bg-indigo-glow',
  ocr_agent: 'text-cyan-light border-cyan-DEFAULT/30 bg-cyan-glow',
  doc_agent: 'text-emerald-light border-emerald-DEFAULT/30 bg-emerald-glow',
  image_agent: 'text-violet-light border-violet-DEFAULT/30 bg-violet-glow',
  tools: 'text-amber-light border-amber-DEFAULT/30 bg-amber-glow',
};

const EVENT_ICONS: Record<string, React.ReactNode> = {
  start: <Zap className="w-3 h-3" />,
  thinking: <Activity className="w-3 h-3 animate-pulse" />,
  tool_call: <Wrench className="w-3 h-3" />,
  result: <CheckCircle className="w-3 h-3" />,
  executing: <Clock className="w-3 h-3 animate-spin" />,
  error: <AlertCircle className="w-3 h-3" />,
  complete: <CheckCircle className="w-3 h-3" />,
};

function AgentBadge({ agent }: { agent: string }) {
  const color = AGENT_COLORS[agent] || 'text-ghost border-border/50 bg-surface/50';
  const icon = AGENT_ICONS[agent] || <Cpu className="w-3.5 h-3.5" />;
  const label = agent.replace('_agent', '').replace('_', ' ');
  
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full border text-xs font-medium ${color}`}>
      {icon}
      {label}
    </span>
  );
}

function ToolCallCard({ call }: { call: ToolCallEvent }) {
  const [expanded, setExpanded] = useState(false);
  
  const statusColors = {
    pending: 'border-muted/50 bg-surface/30',
    executing: 'border-amber/40 bg-amber-glow',
    complete: 'border-emerald/40 bg-emerald-glow',
    error: 'border-rose/40 bg-rose-glow',
  };

  const statusIcons = {
    pending: <Clock className="w-3.5 h-3.5 text-subtle" />,
    executing: <Clock className="w-3.5 h-3.5 text-amber animate-spin" />,
    complete: <CheckCircle className="w-3.5 h-3.5 text-emerald" />,
    error: <AlertCircle className="w-3.5 h-3.5 text-rose" />,
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 8 }}
      animate={{ opacity: 1, x: 0 }}
      className={`rounded-lg border ${statusColors[call.status]} p-2.5 cursor-pointer`}
      onClick={() => setExpanded(!expanded)}
    >
      <div className="flex items-center gap-2">
        {statusIcons[call.status]}
        <span className="text-xs font-mono font-medium text-snow flex-1 truncate">
          {call.toolName}
        </span>
        <ChevronRight
          className={`w-3 h-3 text-subtle transition-transform ${expanded ? 'rotate-90' : ''}`}
        />
      </div>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            {call.input && (
              <div className="mt-2 pt-2 border-t border-border/30">
                <p className="text-xs text-subtle mb-1 font-medium">INPUT</p>
                <pre className="text-xs text-ghost font-mono bg-ink/60 rounded p-1.5 overflow-x-auto max-h-24 whitespace-pre-wrap break-all">
                  {JSON.stringify(call.input, null, 2)}
                </pre>
              </div>
            )}
            {call.result && (
              <div className="mt-2 pt-2 border-t border-border/30">
                <p className="text-xs text-subtle mb-1 font-medium">RESULT</p>
                <pre className="text-xs text-ghost font-mono bg-ink/60 rounded p-1.5 overflow-x-auto max-h-32 whitespace-pre-wrap break-all">
                  {typeof call.result === 'string'
                    ? call.result.slice(0, 300)
                    : JSON.stringify(call.result, null, 2).slice(0, 400)}
                </pre>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function AgentEventItem({ event }: { event: AgentEvent & { timestamp?: number } }) {
  const icon = EVENT_ICONS[event.event] || <Zap className="w-3 h-3" />;
  const timeStr = event.timestamp
    ? new Date(event.timestamp).toLocaleTimeString('en-US', {
        hour12: false,
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      })
    : '';

  return (
    <div className="flex items-start gap-2 py-1.5 group">
      <div className="mt-0.5 text-subtle">{icon}</div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5 mb-0.5">
          <AgentBadge agent={event.agent} />
          <span className="text-xs text-muted">{timeStr}</span>
        </div>
        <p className="text-xs text-ghost capitalize">
          {event.event.replace(/_/g, ' ')}
          {event.data?.tool && (
            <span className="ml-1 font-mono text-amber-light">
              → {event.data.tool}
            </span>
          )}
          {event.data?.message && (
            <span className="ml-1 text-rose-light">: {event.data.message}</span>
          )}
        </p>
      </div>
    </div>
  );
}

export default function AgentPanel() {
  const { agentEvents, toolCalls, isStreaming, activeAgents, agentPanelOpen } = useAppStore();
  const [activeTab, setActiveTab] = useState<'events' | 'tools'>('tools');

  if (!agentPanelOpen) return null;

  const recentEvents = [...agentEvents].reverse().slice(0, 20);
  const recentTools = [...toolCalls].reverse().slice(0, 10);

  return (
    <div className="flex flex-col h-full bg-ink border-l border-border/50 w-72 flex-shrink-0">
      {/* Header */}
      <div className="px-3 py-2.5 border-b border-border/50">
        <div className="flex items-center gap-2">
          <div className={`w-1.5 h-1.5 rounded-full ${isStreaming ? 'bg-emerald animate-pulse' : 'bg-muted'}`} />
          <h3 className="text-xs font-semibold text-snow tracking-wider uppercase">
            Agent Activity
          </h3>
          {isStreaming && (
            <span className="ml-auto text-xs text-emerald font-medium">
              LIVE
            </span>
          )}
        </div>

        {/* Active agents */}
        {activeAgents.size > 0 && (
          <div className="flex flex-wrap gap-1 mt-2">
            {Array.from(activeAgents).map((agent) => (
              <AgentBadge key={agent} agent={agent} />
            ))}
          </div>
        )}
      </div>

      {/* Tabs */}
      <div className="flex border-b border-border/50">
        {(['tools', 'events'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex-1 py-2 text-xs font-medium capitalize transition-colors ${
              activeTab === tab
                ? 'text-indigo-light border-b-2 border-indigo-DEFAULT'
                : 'text-subtle hover:text-ghost'
            }`}
          >
            {tab}
            {tab === 'tools' && toolCalls.length > 0 && (
              <span className="ml-1 bg-indigo-glow text-indigo-light px-1 rounded-full text-xs">
                {toolCalls.length}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-2 space-y-1.5">
        {activeTab === 'tools' ? (
          <>
            {recentTools.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-8 text-center">
                <Wrench className="w-8 h-8 text-muted mb-2" />
                <p className="text-xs text-muted">No tool calls yet</p>
                <p className="text-xs text-muted/60 mt-1">
                  Ask DocMind to analyze a document
                </p>
              </div>
            ) : (
              <AnimatePresence mode="popLayout">
                {recentTools.map((call) => (
                  <ToolCallCard key={call.toolCallId} call={call} />
                ))}
              </AnimatePresence>
            )}
          </>
        ) : (
          <>
            {recentEvents.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-8 text-center">
                <Activity className="w-8 h-8 text-muted mb-2" />
                <p className="text-xs text-muted">No events yet</p>
              </div>
            ) : (
              <div className="divide-y divide-border/20">
                <AnimatePresence mode="popLayout">
                  {recentEvents.map((event, i) => (
                    <AgentEventItem key={`${event.agent}-${event.event}-${i}`} event={event} />
                  ))}
                </AnimatePresence>
              </div>
            )}
          </>
        )}
      </div>

      {/* Footer stats */}
      <div className="px-3 py-2 border-t border-border/50 flex items-center gap-3 text-xs text-muted">
        <span>{agentEvents.length} events</span>
        <span>·</span>
        <span>{toolCalls.length} tool calls</span>
      </div>
    </div>
  );
}
