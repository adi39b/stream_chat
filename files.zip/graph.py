"""
DocMind Multi-Agent LangGraph Workflow
=======================================

Architecture:
  Orchestrator (supervisor) → delegates to specialized agents:
    - OCR Agent      : Extract text/bounding boxes from images & PDFs
    - Doc Analyst    : PageIndex-based document analysis & reporting
    - Image Agent    : Comprehensive image understanding

Streaming: astream_events("v2") → FastAPI SSE → Vercel AI SDK data stream
"""

import json
import re
import uuid
from typing import Any, Annotated, Dict, List, Optional, Sequence, TypedDict

from langchain_anthropic import ChatAnthropic
from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.tools import BaseTool
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode

from tools.agent_tools import (
    OCR_TOOLS,
    DOC_TOOLS,
    IMAGE_TOOLS,
    ALL_TOOLS,
)


# ── State ─────────────────────────────────────────────────────────────────────

class AgentState(TypedDict):
    messages: Annotated[List[BaseMessage], add_messages]
    session_id: str
    active_agent: str
    tool_calls_made: List[Dict]
    current_task: str
    iteration: int


# ── Agent system prompts ───────────────────────────────────────────────────────

ORCHESTRATOR_SYSTEM = """You are DocMind's intelligent orchestrator agent. You coordinate a team of specialized AI agents to help users analyze documents, images, and extract information.

Your team:
🔍 **OCR Agent** — Extracts text from images and PDFs with bounding boxes. Use for: scanned documents, handwritten text, image text extraction.
📄 **Document Analyst** — Expert in document analysis using PageIndex tree-based RAG. Use for: document questions, reports, comparisons, indexing.
🖼️ **Image Agent** — Analyzes images, charts, and visual content. Use for: image descriptions, chart data extraction, visual content.

Your role:
1. Understand what the user needs
2. Delegate to the appropriate specialist agent
3. Synthesize results into a coherent response
4. Be transparent about which agents you're using and why

When responding:
- Be concise about your orchestration plan
- Explain which agent you're delegating to and why
- Summarize the results clearly for the user
- Always provide actionable, helpful responses

You have access to all agent tools directly. Use them to help the user.
"""

OCR_AGENT_SYSTEM = """You are DocMind's OCR (Optical Character Recognition) specialist agent.

Your expertise:
- Extracting text from PDFs page by page
- Identifying text regions with bounding box coordinates
- Handling complex layouts (multi-column, tables, forms)
- Processing scanned documents and images with text

When extracting text:
1. First use ocr_extract_text for PDF pages
2. Use ocr_extract_with_bounding_boxes for images needing spatial layout info
3. Always report confidence levels and any limitations
4. Structure the output clearly

Be precise and thorough. Report exactly what you find.
"""

DOC_ANALYST_SYSTEM = """You are DocMind's Document Analysis specialist. You use PageIndex — a hierarchical, 
reasoning-based RAG system — to analyze documents with precision that exceeds traditional vector search.

PageIndex works by:
1. Building a semantic tree structure (like a smart table of contents)
2. Using LLM reasoning to navigate the tree and find relevant sections
3. Extracting precise content from the right pages

Your workflow for document questions:
1. Ensure the document is indexed (build_document_index)
2. Query using PageIndex reasoning (query_document)
3. Generate reports when needed (generate_document_report)

For new documents always index first. For comparisons use compare_documents.
Always cite specific pages/sections in your responses.
"""

IMAGE_AGENT_SYSTEM = """You are DocMind's Image Analysis specialist.

Your capabilities:
- Comprehensive image understanding and description
- Object detection and spatial relationship analysis
- Text extraction from images (when needed)
- Chart/graph data extraction and interpretation
- Visual content classification

Analyze images thoroughly and provide:
1. What is shown in the image
2. Key objects, people, text, or data visible
3. Color scheme, composition, and style
4. Any insights or notable observations
5. For charts: actual data values and trends
"""


# ── LLM factory ───────────────────────────────────────────────────────────────

def make_llm(model: str = "claude-3-5-sonnet-20241022") -> ChatAnthropic:
    return ChatAnthropic(model=model, max_tokens=4096, streaming=True)


# ── Agent node builders ────────────────────────────────────────────────────────

def build_agent_node(system_prompt: str, tools: List[BaseTool], model: str = "claude-3-5-sonnet-20241022"):
    """Build a LangGraph agent node with tools."""
    llm = make_llm(model).bind_tools(tools)
    
    async def agent_node(state: AgentState) -> AgentState:
        messages = state["messages"]
        
        # Prepend system message
        full_messages = [SystemMessage(content=system_prompt)] + messages
        
        response = await llm.ainvoke(full_messages)
        
        # Track tool calls
        tool_calls_made = list(state.get("tool_calls_made", []))
        if hasattr(response, "tool_calls") and response.tool_calls:
            for tc in response.tool_calls:
                tool_calls_made.append({
                    "id": tc.get("id", str(uuid.uuid4())),
                    "name": tc.get("name"),
                    "args": tc.get("args", {}),
                    "agent": state.get("active_agent", "unknown"),
                })
        
        return {
            "messages": [response],
            "tool_calls_made": tool_calls_made,
        }
    
    return agent_node


def should_continue(state: AgentState) -> str:
    """Check if agent made tool calls that need execution."""
    messages = state["messages"]
    last = messages[-1] if messages else None
    if isinstance(last, AIMessage) and last.tool_calls:
        return "tools"
    return "orchestrator"


def should_orchestrator_continue(state: AgentState) -> str:
    """Check if orchestrator is done."""
    messages = state["messages"]
    last = messages[-1] if messages else None
    if isinstance(last, AIMessage) and last.tool_calls:
        return "tools"
    return END


# ── Build LangGraph workflow ──────────────────────────────────────────────────

def build_graph() -> StateGraph:
    """
    Build the multi-agent LangGraph workflow.
    
    Graph structure:
    START → orchestrator → tools? → orchestrator (loop until done)
    
    The orchestrator has access to ALL tools and can delegate
    by deciding which tools to use for each task.
    """
    
    # All tools combined for the orchestrator
    all_tools = ALL_TOOLS
    tool_node = ToolNode(all_tools)
    
    # Build orchestrator with all tools
    orchestrator_llm = make_llm("claude-3-5-sonnet-20241022").bind_tools(all_tools)
    
    async def orchestrator(state: AgentState) -> AgentState:
        messages = state["messages"]
        iteration = state.get("iteration", 0)
        
        full_messages = [SystemMessage(content=ORCHESTRATOR_SYSTEM)] + messages
        response = await orchestrator_llm.ainvoke(full_messages)
        
        tool_calls_made = list(state.get("tool_calls_made", []))
        if hasattr(response, "tool_calls") and response.tool_calls:
            for tc in response.tool_calls:
                tool_calls_made.append({
                    "id": tc.get("id", str(uuid.uuid4())),
                    "name": tc.get("name"),
                    "args": tc.get("args", {}),
                    "agent": "orchestrator",
                })
        
        return {
            "messages": [response],
            "active_agent": "orchestrator",
            "tool_calls_made": tool_calls_made,
            "iteration": iteration + 1,
        }

    # Build specialized agent nodes (used for sub-agent mode)
    ocr_agent = build_agent_node(OCR_AGENT_SYSTEM, OCR_TOOLS, "claude-3-5-haiku-20241022")
    doc_agent = build_agent_node(DOC_ANALYST_SYSTEM, DOC_TOOLS, "claude-3-5-sonnet-20241022")
    image_agent = build_agent_node(IMAGE_AGENT_SYSTEM, IMAGE_TOOLS, "claude-3-5-sonnet-20241022")
    
    # Tool nodes per agent
    ocr_tools = ToolNode(OCR_TOOLS)
    doc_tools = ToolNode(DOC_TOOLS)
    image_tools = ToolNode(IMAGE_TOOLS)
    
    # ── Build graph ──
    builder = StateGraph(AgentState)
    
    # Main orchestrator loop
    builder.add_node("orchestrator", orchestrator)
    builder.add_node("tools", tool_node)
    
    # Specialized agents
    builder.add_node("ocr_agent", ocr_agent)
    builder.add_node("ocr_tools", ocr_tools)
    builder.add_node("doc_agent", doc_agent)
    builder.add_node("doc_tools", doc_tools)
    builder.add_node("image_agent", image_agent)
    builder.add_node("image_tools", image_tools)
    
    # Main flow: orchestrator ↔ tools
    builder.add_edge(START, "orchestrator")
    builder.add_conditional_edges(
        "orchestrator",
        should_orchestrator_continue,
        {"tools": "tools", END: END},
    )
    builder.add_edge("tools", "orchestrator")
    
    # OCR agent loop
    builder.add_conditional_edges(
        "ocr_agent",
        should_continue,
        {"tools": "ocr_tools", "orchestrator": "orchestrator"},
    )
    builder.add_edge("ocr_tools", "ocr_agent")
    
    # Doc agent loop
    builder.add_conditional_edges(
        "doc_agent",
        should_continue,
        {"tools": "doc_tools", "orchestrator": "orchestrator"},
    )
    builder.add_edge("doc_tools", "doc_agent")
    
    # Image agent loop
    builder.add_conditional_edges(
        "image_agent",
        should_continue,
        {"tools": "image_tools", "orchestrator": "orchestrator"},
    )
    builder.add_edge("image_tools", "image_agent")
    
    return builder.compile()


# ── Module-level compiled graph ───────────────────────────────────────────────
_graph = None

def get_graph():
    global _graph
    if _graph is None:
        _graph = build_graph()
    return _graph
