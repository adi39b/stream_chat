"""
Agent tools for DocMind multi-agent system.
"""

import base64
import io
import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

import pypdf
from langchain_core.tools import tool
from langchain_anthropic import ChatAnthropic
from langchain_core.messages import HumanMessage, SystemMessage
from PIL import Image

from storage.db import DocumentStore, PageIndexStore, DOCS_DIR
from storage.page_index import (
    PageIndexBuilder,
    PageIndexRetriever,
    extract_pdf_pages,
)


# ── Shared LLM ────────────────────────────────────────────────────────────────

def get_vision_llm():
    return ChatAnthropic(model="claude-3-5-sonnet-20241022", max_tokens=4096)

def get_fast_llm():
    return ChatAnthropic(model="claude-3-5-haiku-20241022", max_tokens=2048)


# ── OCR Tools ─────────────────────────────────────────────────────────────────

@tool
async def ocr_extract_text(doc_id: str, page_number: int = 1) -> Dict:
    """
    Extract text from a specific page of a document using vision-based OCR.
    Returns extracted text and structural information.
    
    Args:
        doc_id: Document ID from the document store
        page_number: Page number to extract (1-indexed)
    """
    doc = DocumentStore.get(doc_id)
    if not doc:
        return {"error": f"Document {doc_id} not found"}

    file_path = doc["file_path"]
    if not Path(file_path).exists():
        return {"error": "Document file not found on disk"}

    try:
        # Extract page as image for vision OCR
        reader = pypdf.PdfReader(file_path)
        if page_number < 1 or page_number > len(reader.pages):
            return {"error": f"Page {page_number} out of range (1-{len(reader.pages)})"}

        page = reader.pages[page_number - 1]
        text = page.extract_text() or ""

        # Use vision model for better OCR if text is sparse
        llm = get_vision_llm()
        
        # Enhance with LLM understanding
        if len(text.strip()) < 50:
            result = {
                "page": page_number,
                "text": text,
                "method": "pypdf",
                "confidence": "low",
                "note": "Limited text extracted; page may contain images or complex layouts",
            }
        else:
            # Ask LLM to structure the extracted text
            prompt = f"""Analyze and structure this text extracted from page {page_number} of a document.
            
Extracted text:
{text[:3000]}

Return a JSON with:
{{
  "structured_content": "cleaned and organized version of the text",
  "key_elements": ["list of key information found"],
  "document_type_hint": "what type of content this appears to be",
  "has_tables": true/false,
  "has_lists": true/false
}}"""
            response = await llm.ainvoke([HumanMessage(content=prompt)])
            
            try:
                match = re.search(r"\{[\s\S]+\}", response.content)
                structured = json.loads(match.group(0)) if match else {}
            except Exception:
                structured = {}

            result = {
                "page": page_number,
                "raw_text": text,
                "method": "pypdf+claude-vision",
                "confidence": "high",
                **structured,
            }

        return result

    except Exception as e:
        return {"error": str(e)}


@tool
async def ocr_extract_with_bounding_boxes(image_path: str) -> Dict:
    """
    Extract text from an image with bounding box information using Deepseek-style OCR.
    Returns text regions with approximate positions.
    
    Args:
        image_path: Path to the image file to analyze
    """
    if not Path(image_path).exists():
        return {"error": f"Image not found: {image_path}"}

    try:
        # Load and encode image
        with Image.open(image_path) as img:
            width, height = img.size
            # Convert to RGB if needed
            if img.mode not in ("RGB", "RGBA"):
                img = img.convert("RGB")
            
            # Resize if too large
            max_dim = 1568
            if max(width, height) > max_dim:
                ratio = max_dim / max(width, height)
                img = img.resize((int(width * ratio), int(height * ratio)))
                width, height = img.size

            buffer = io.BytesIO()
            img.save(buffer, format="JPEG", quality=85)
            img_b64 = base64.b64encode(buffer.getvalue()).decode()

        llm = get_vision_llm()
        
        message = HumanMessage(content=[
            {
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": "image/jpeg",
                    "data": img_b64,
                },
            },
            {
                "type": "text",
                "text": f"""Perform detailed OCR on this image ({width}x{height} pixels).
                
For each text region you identify, provide:
1. The extracted text
2. Approximate bounding box as percentages of image dimensions: {{x, y, width, height}} where (0,0) is top-left
3. Text type (heading, body, label, table, caption, etc.)
4. Confidence (high/medium/low)

Return JSON:
{{
  "image_dimensions": {{"width": {width}, "height": {height}}},
  "text_regions": [
    {{
      "text": "extracted text here",
      "bbox": {{"x": 5.0, "y": 10.0, "width": 90.0, "height": 5.0}},
      "type": "heading",
      "confidence": "high"
    }}
  ],
  "full_text": "complete extracted text in reading order",
  "layout_type": "single_column|multi_column|table|mixed",
  "language": "detected language"
}}""",
            },
        ])

        response = await llm.ainvoke([message])
        
        try:
            match = re.search(r"\{[\s\S]+\}", response.content)
            result = json.loads(match.group(0)) if match else {}
            result["source_image"] = str(image_path)
            return result
        except Exception:
            return {
                "source_image": str(image_path),
                "full_text": response.content,
                "text_regions": [],
                "parse_error": "Could not parse structured response",
            }

    except Exception as e:
        return {"error": str(e)}


# ── Document Analysis Tools ────────────────────────────────────────────────────

@tool
async def build_document_index(doc_id: str) -> Dict:
    """
    Build a PageIndex hierarchical tree for a document.
    This creates a semantic table-of-contents optimized for LLM retrieval.
    
    Args:
        doc_id: Document ID to index
    """
    doc = DocumentStore.get(doc_id)
    if not doc:
        return {"error": f"Document {doc_id} not found"}

    # Check if already indexed
    if doc.get("has_page_index") and doc.get("page_index_id"):
        existing = PageIndexStore.get(doc["page_index_id"])
        if existing:
            return {
                "status": "already_indexed",
                "index_id": existing["id"],
                "node_count": existing["node_count"],
                "page_count": existing["page_count"],
                "tree_preview": _tree_preview(existing["tree"]),
            }

    file_path = doc["file_path"]
    if not Path(file_path).exists():
        return {"error": "Document file not found"}

    try:
        builder = PageIndexBuilder()
        tree, page_count = await builder.build_tree(
            file_path=file_path,
            doc_title=doc["filename"],
        )
        record = PageIndexStore.save(
            doc_id=doc_id,
            doc_filename=doc["filename"],
            tree=tree,
            page_count=page_count,
        )
        return {
            "status": "indexed",
            "index_id": record["id"],
            "node_count": record["node_count"],
            "page_count": page_count,
            "tree_preview": _tree_preview(tree),
        }

    except Exception as e:
        return {"error": f"Indexing failed: {str(e)}"}


@tool
async def query_document(doc_id: str, question: str) -> Dict:
    """
    Query a document using PageIndex reasoning-based retrieval.
    Finds the most relevant sections and answers the question.
    
    Args:
        doc_id: Document ID to query
        question: Question to answer from the document
    """
    doc = DocumentStore.get(doc_id)
    if not doc:
        return {"error": f"Document {doc_id} not found"}

    if not doc.get("has_page_index"):
        return {"error": "Document not yet indexed. Use build_document_index first."}

    index_record = PageIndexStore.get(doc["page_index_id"])
    if not index_record:
        return {"error": "Index not found"}

    tree = index_record["tree"]
    file_path = doc["file_path"]

    try:
        # Step 1: Tree-search retrieval
        retriever = PageIndexRetriever()
        node_ids, thinking = await retriever.retrieve_nodes(question, tree)

        if not node_ids:
            return {
                "question": question,
                "answer": "Could not identify relevant sections",
                "thinking": thinking,
                "retrieved_nodes": [],
            }

        # Step 2: Fetch page content for retrieved nodes
        pages = extract_pdf_pages(file_path)
        relevant_nodes = PageIndexStore.get_relevant_nodes(tree, node_ids)
        
        context_parts = []
        for node in relevant_nodes:
            content = retriever.extract_page_content(pages, node)
            context_parts.append(
                f"## {node['title']} (Pages {node['start_index']}-{node['end_index']})\n{content}"
            )

        context = "\n\n".join(context_parts)

        # Step 3: Generate answer
        llm = get_vision_llm()
        answer_prompt = f"""Based on the following document sections, answer the question precisely.

Question: {question}

Relevant document sections:
{context[:6000]}

Provide a comprehensive, accurate answer. Cite specific sections/pages where relevant."""

        response = await llm.ainvoke([HumanMessage(content=answer_prompt)])

        return {
            "question": question,
            "answer": response.content,
            "retrieval_thinking": thinking,
            "retrieved_nodes": [
                {
                    "title": n.get("title"),
                    "pages": f"{n.get('start_index')}-{n.get('end_index')}",
                    "summary": n.get("summary", ""),
                }
                for n in relevant_nodes
            ],
            "document": doc["filename"],
        }

    except Exception as e:
        return {"error": f"Query failed: {str(e)}"}


@tool
async def generate_document_report(doc_id: str, report_type: str = "executive_summary") -> Dict:
    """
    Generate a comprehensive report about a document.
    
    Args:
        doc_id: Document ID
        report_type: Type of report - one of: executive_summary, key_findings, 
                     risk_analysis, data_extraction, comparison_ready
    """
    doc = DocumentStore.get(doc_id)
    if not doc:
        return {"error": f"Document {doc_id} not found"}

    file_path = doc["file_path"]
    if not Path(file_path).exists():
        return {"error": "Document file not found"}

    report_prompts = {
        "executive_summary": "Provide a concise executive summary covering: purpose, key points, conclusions, and recommended actions.",
        "key_findings": "Extract and list all key findings, facts, data points, and important conclusions from this document.",
        "risk_analysis": "Identify and analyze any risks, issues, concerns, or red flags mentioned in this document.",
        "data_extraction": "Extract all structured data: tables, numbers, dates, names, statistics, and metrics found in this document.",
        "comparison_ready": "Summarize this document in a format that allows easy comparison with other documents on the same topic.",
    }

    prompt_instruction = report_prompts.get(report_type, report_prompts["executive_summary"])

    try:
        pages = extract_pdf_pages(file_path)
        page_count = len(pages)
        
        # Gather text (intelligently sample if large document)
        if page_count <= 20:
            all_text = "\n\n".join(f"[Page {p['page_num']}]\n{p['text']}" for p in pages)
        else:
            # Sample: first 5, middle 5, last 5 pages
            sampled = pages[:5] + pages[page_count//2-2:page_count//2+3] + pages[-5:]
            all_text = "\n\n".join(f"[Page {p['page_num']}]\n{p['text']}" for p in sampled)
            all_text = f"[Note: Showing sampled pages from {page_count}-page document]\n\n" + all_text

        llm = get_vision_llm()
        response = await llm.ainvoke([
            SystemMessage(content="You are an expert document analyst. Provide thorough, professional analysis."),
            HumanMessage(content=f"""Document: {doc['filename']}
Pages: {page_count}

{prompt_instruction}

Document content:
{all_text[:7000]}

Format your response with clear sections and structure."""),
        ])

        return {
            "report_type": report_type,
            "document": doc["filename"],
            "page_count": page_count,
            "report": response.content,
        }

    except Exception as e:
        return {"error": f"Report generation failed: {str(e)}"}


@tool
async def list_available_documents(session_id: Optional[str] = None) -> Dict:
    """
    List all documents available for analysis.
    
    Args:
        session_id: Optional session ID to filter documents
    """
    docs = DocumentStore.list_all(session_id)
    return {
        "total": len(docs),
        "documents": [
            {
                "id": d["id"],
                "filename": d["filename"],
                "file_type": d["file_type"],
                "size_bytes": d["size_bytes"],
                "has_page_index": d.get("has_page_index", False),
                "created_at": d["created_at"],
            }
            for d in docs
        ],
    }


@tool
async def compare_documents(doc_id_1: str, doc_id_2: str, comparison_focus: str = "general") -> Dict:
    """
    Compare two documents side-by-side and generate a comparison report.
    
    Args:
        doc_id_1: First document ID
        doc_id_2: Second document ID
        comparison_focus: What to focus on - general, financial, technical, legal
    """
    doc1 = DocumentStore.get(doc_id_1)
    doc2 = DocumentStore.get(doc_id_2)
    
    if not doc1:
        return {"error": f"Document {doc_id_1} not found"}
    if not doc2:
        return {"error": f"Document {doc_id_2} not found"}

    try:
        pages1 = extract_pdf_pages(doc1["file_path"])
        pages2 = extract_pdf_pages(doc2["file_path"])
        
        text1 = "\n".join(p["text"] for p in pages1[:10])[:3000]
        text2 = "\n".join(p["text"] for p in pages2[:10])[:3000]

        llm = get_vision_llm()
        response = await llm.ainvoke([
            SystemMessage(content="You are an expert document analyst specializing in comparative analysis."),
            HumanMessage(content=f"""Compare these two documents with focus on: {comparison_focus}

=== DOCUMENT 1: {doc1['filename']} ({len(pages1)} pages) ===
{text1}

=== DOCUMENT 2: {doc2['filename']} ({len(pages2)} pages) ===
{text2}

Provide a structured comparison covering:
1. Key similarities
2. Key differences  
3. Unique aspects of each document
4. Overall assessment"""),
        ])

        return {
            "doc1": doc1["filename"],
            "doc2": doc2["filename"],
            "focus": comparison_focus,
            "comparison": response.content,
        }
    except Exception as e:
        return {"error": str(e)}


# ── Image Analysis Tools ───────────────────────────────────────────────────────

@tool
async def analyze_image(image_path: str, analysis_type: str = "comprehensive") -> Dict:
    """
    Analyze an image and provide detailed description.
    
    Args:
        image_path: Path to the image file
        analysis_type: Type of analysis - comprehensive, objects, text, charts, faces
    """
    if not Path(image_path).exists():
        return {"error": f"Image not found: {image_path}"}

    try:
        with Image.open(image_path) as img:
            width, height = img.size
            format_name = img.format or "unknown"
            if img.mode not in ("RGB", "RGBA"):
                img = img.convert("RGB")
            
            max_dim = 1568
            if max(width, height) > max_dim:
                ratio = max_dim / max(width, height)
                img = img.resize((int(width * ratio), int(height * ratio)))
            
            buffer = io.BytesIO()
            img.save(buffer, format="JPEG", quality=85)
            img_b64 = base64.b64encode(buffer.getvalue()).decode()

        analysis_prompts = {
            "comprehensive": "Provide a comprehensive analysis of this image including: what you see, key objects, any text, colors, composition, and notable details.",
            "objects": "List and describe all objects, people, and entities visible in this image with their positions and relationships.",
            "text": "Extract and transcribe all text visible in this image, preserving formatting and hierarchy.",
            "charts": "Analyze any charts, graphs, or data visualizations. Extract data points, trends, and insights.",
            "faces": "Describe any people visible: approximate age, expressions, and relevant contextual details (no identification).",
        }

        prompt = analysis_prompts.get(analysis_type, analysis_prompts["comprehensive"])

        llm = get_vision_llm()
        response = await llm.ainvoke([
            HumanMessage(content=[
                {
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": "image/jpeg",
                        "data": img_b64,
                    },
                },
                {"type": "text", "text": prompt},
            ])
        ])

        return {
            "image_path": image_path,
            "dimensions": {"width": width, "height": height},
            "format": format_name,
            "analysis_type": analysis_type,
            "analysis": response.content,
        }

    except Exception as e:
        return {"error": str(e)}


@tool
async def extract_charts_data(image_path: str) -> Dict:
    """
    Extract data from charts and graphs in an image.
    
    Args:
        image_path: Path to an image containing charts or graphs
    """
    return await analyze_image.ainvoke({"image_path": image_path, "analysis_type": "charts"})


# ── Helper ────────────────────────────────────────────────────────────────────

def _tree_preview(tree: Dict, max_nodes: int = 5) -> List[Dict]:
    """Return a flat preview of top-level tree nodes."""
    if not isinstance(tree, dict):
        return []
    preview = []
    for node in tree.get("nodes", [])[:max_nodes]:
        preview.append({
            "title": node.get("title", ""),
            "pages": f"{node.get('start_index')}-{node.get('end_index')}",
            "children": len(node.get("nodes", [])),
        })
    return preview


# ── All tools for agents ──────────────────────────────────────────────────────

OCR_TOOLS = [ocr_extract_text, ocr_extract_with_bounding_boxes]
DOC_TOOLS = [build_document_index, query_document, generate_document_report, 
             list_available_documents, compare_documents]
IMAGE_TOOLS = [analyze_image, extract_charts_data]
ALL_TOOLS = OCR_TOOLS + DOC_TOOLS + IMAGE_TOOLS
