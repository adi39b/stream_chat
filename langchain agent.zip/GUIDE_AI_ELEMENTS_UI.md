# AI Elements — Complete UI Building Guide

Everything you need to build production-grade AI interfaces with Vercel's AI Elements component library.

> **Official site & live demos:** https://elements.ai-sdk.dev  
> **Component registry / source:** https://github.com/vercel/ai-elements  
> **Vercel Academy lesson:** https://vercel.com/academy/ai-sdk/ai-elements  
> **AI SDK docs:** https://ai-sdk.dev/docs/introduction  
> **AI SDK React hooks:** https://ai-sdk.dev/docs/ai-sdk-ui

---

## Table of Contents

1. [What Is AI Elements?](#1-what-is-ai-elements)
2. [Installation & Setup](#2-installation--setup)
3. [The Full Component Catalogue](#3-the-full-component-catalogue)
4. [Building a Complete Chat UI (Step-by-Step)](#4-building-a-complete-chat-ui-step-by-step)
5. [Tool Calls & Tool Display](#5-tool-calls--tool-display)
6. [Reasoning / Chain-of-Thought Blocks](#6-reasoning--chain-of-thought-blocks)
7. [Source Citations](#7-source-citations)
8. [Suggestion Chips](#8-suggestion-chips)
9. [File Attachments](#9-file-attachments)
10. [Message Branching](#10-message-branching)
11. [Code & Artifact Display](#11-code--artifact-display)
12. [Voice Interface](#12-voice-interface)
13. [Workflow / Graph Visualisation](#13-workflow--graph-visualisation)
14. [Human-in-the-Loop UI Patterns](#14-human-in-the-loop-ui-patterns)
15. [Model Selector](#15-model-selector)
16. [Theming & Customisation](#16-theming--customisation)
17. [useChat Deep-Dive (AI SDK v6)](#17-usechat-deep-dive-ai-sdk-v6)
18. [Complete Production Example](#18-complete-production-example)
19. [Key Gotchas](#19-key-gotchas)

---

## 1. What Is AI Elements?

AI Elements is a **shadcn/ui-style component registry** for AI interfaces. The key philosophy:

- **You own the code.** Components are copied into your project — no external dependency to update.
- **Composable.** Use `Message` without `Conversation`. Use `Tool` without the full chat interface.
- **AI SDK-native.** Components understand `message.parts`, streaming states, tool invocations, and reasoning blocks from the Vercel AI SDK data model.
- **Fully customisable.** Components use Tailwind classes and Radix primitives — open the file and change whatever you want.

AI Elements **replaces** the older Vercel Chat SDK. It supports a far wider range of UI patterns beyond chat.

> Introduced: https://vercel.com/changelog/introducing-ai-elements

---

## 2. Installation & Setup

### Prerequisites

Your Next.js project must have:
- **shadcn/ui** configured (`components.json` at the root)
- **Tailwind CSS** with CSS variables for shadcn theming
- **`@ai-sdk/react`** and **`ai`** installed
- Node.js ≥ 18

### Step 1 — shadcn/ui init (if not already done)

```bash
npx shadcn@latest init
# Select: TypeScript, Default style, CSS variables
```

### Step 2 — Install all AI Elements components

```bash
npx ai-elements@latest
# OR target specific components:
npx ai-elements@latest add message
npx ai-elements@latest add conversation
npx ai-elements@latest add tool
npx ai-elements@latest add reasoning
```

Alternative using the shadcn CLI directly:

```bash
# Install ALL components at once
npx shadcn@latest add https://elements.ai-sdk.dev/api/registry/all.json

# Install a single component
npx shadcn@latest add https://elements.ai-sdk.dev/api/registry/message.json
```

### Step 3 — Install npm packages

```bash
pnpm add ai @ai-sdk/react @ai-sdk/langchain @langchain/core
# plus your LLM provider, e.g.:
pnpm add @ai-sdk/openai
```

### Step 4 — Verify globals.css has CSS variables

AI Elements reads shadcn CSS variables. Your `app/globals.css` must have the `@layer base { :root { --background: ...; ... } }` block. See the starter file in this project.

---

## 3. The Full Component Catalogue

After `npx ai-elements@latest`, all components land in `components/ai-elements/`.
They are grouped into 4 categories on https://elements.ai-sdk.dev/components:

### Chatbot Components

| Component | Import path | What it does |
|---|---|---|
| `Conversation` `ConversationContent` `ConversationEmptyState` `ConversationScrollButton` | `./conversation` | Scrollable message container with auto-scroll and empty state |
| `Message` `MessageContent` `MessageResponse` `MessageBranch` `MessageBranchSelector` … | `./message` | Message bubble with role-based alignment, markdown, branch navigation |
| `PromptInput` `PromptInputTextarea` `PromptInputSubmit` `PromptInputButton` `PromptInputFooter` `PromptInputTools` | `./prompt-input` | Smart input with auto-resize, attachment buttons, send button |
| `Reasoning` `ReasoningContent` `ReasoningTrigger` | `./reasoning` | Collapsible "thinking" block for reasoning models (o1, o3, DeepSeek-R1) |
| `Tool` | `./tool` | Expandable tool call card showing name, inputs, and output |
| `Source` `Sources` `SourcesContent` `SourcesTrigger` | `./sources` | Collapsible cited-sources panel |
| `Suggestion` `Suggestions` | `./suggestion` | Quick-reply suggestion chips below input |
| `Attachments` | `./attachments` | File/image attachment previews |
| `Confirmation` | `./confirmation` | Human-in-the-loop approval dialog |
| `Context` | `./context` | Display of retrieved context / RAG documents |
| `Shimmer` | `./shimmer` | Loading skeleton for streaming placeholder |
| `Task` | `./task` | Checklist-style task progress display |
| `Plan` | `./plan` | Multi-step plan display |
| `Queue` | `./queue` | Background task queue status |
| `Chain of Thought` | `./chain-of-thought` | Step-by-step reasoning trace |
| `Checkpoint` | `./checkpoint` | Checkpoint save/restore indicator |
| `Model Selector` | `./model-selector` | Dropdown to switch between models |
| `Inline Citation` | `./inline-citation` | Footnote-style citation markers in text |

### Code Components

| Component | What it does |
|---|---|
| `CodeBlock` | Syntax-highlighted code with copy button and language detection |
| `Artifact` | Rich content artifact (HTML preview, code, etc.) |
| `Snippet` | Inline code/command snippet |
| `Terminal` | Terminal-style output display |
| `FileTree` | Visual file system tree |
| `Sandbox` | Embedded iframe/code sandbox |
| `Agent` | Agent action display (used in coding agents) |
| `Commit` | Git commit card |
| `EnvironmentVariables` | Env var key/value display |
| `PackageInfo` | npm/pip package information card |
| `SchemaDisplay` | JSON schema visualiser |
| `StackTrace` | Error stack trace display |
| `TestResults` | Test pass/fail results display |
| `WebPreview` | Embedded web page preview |
| `JSXPreview` | Live JSX component preview |

### Voice Components

| Component | What it does |
|---|---|
| `SpeechInput` | Microphone input with waveform visualisation |
| `Transcription` | Real-time speech-to-text display |
| `AudioPlayer` | AI-generated audio playback |
| `Persona` | AI voice persona avatar |
| `MicSelector` | Microphone device selector |
| `VoiceSelector` | Voice/speech output selector |

### Workflow Components

| Component | What it does |
|---|---|
| `Canvas` | Graph/workflow canvas wrapper |
| `Node` | Workflow graph node |
| `Edge` | Workflow graph edge/connection |
| `Controls` | Zoom/pan controls for canvas |
| `Panel` | Floating panel on workflow canvas |
| `Connection` | Connection status indicator |
| `Toolbar` | Workflow toolbar |

### Utility Components

| Component | What it does |
|---|---|
| `Image` | AI-generated image display |
| `OpenInChat` | "Open in chat" action button |

---

## 4. Building a Complete Chat UI (Step-by-Step)

### Minimum viable chat

```tsx
'use client';
import { useState } from 'react';
import { useChat } from '@ai-sdk/react';
import { Conversation, ConversationContent, ConversationEmptyState } from '@/components/ai-elements/conversation';
import { Message, MessageContent, MessageResponse } from '@/components/ai-elements/message';
import { PromptInput, PromptInputTextarea, PromptInputSubmit } from '@/components/ai-elements/prompt-input';

export default function Chat() {
  const [input, setInput] = useState('');
  const { messages, sendMessage, status } = useChat();
  const isLoading = status === 'streaming' || status === 'submitted';

  return (
    <div className="flex flex-col h-screen">
      <Conversation>
        <ConversationContent>
          {messages.length === 0 ? (
            <ConversationEmptyState title="Hello!" description="Ask me anything." />
          ) : (
            messages.map(m => (
              <Message key={m.id} from={m.role}>
                <MessageContent>
                  {m.role === 'assistant'
                    ? <MessageResponse>{m.parts?.filter(p => p.type === 'text').map(p => p.text).join('')}</MessageResponse>
                    : m.parts?.map((p, i) => p.type === 'text' ? <span key={i}>{p.text}</span> : null)
                  }
                </MessageContent>
              </Message>
            ))
          )}
        </ConversationContent>
      </Conversation>

      <div className="border-t p-4">
        <PromptInput
          onSubmit={(msg, e) => { e?.preventDefault(); if (msg.text?.trim()) { sendMessage({ text: msg.text }); setInput(''); } }}
          className="max-w-2xl mx-auto flex gap-2 items-end"
        >
          <PromptInputTextarea value={input} onChange={e => setInput(e.target.value)} disabled={isLoading} rows={1} className="flex-1" />
          <PromptInputSubmit disabled={isLoading} />
        </PromptInput>
      </div>
    </div>
  );
}
```

### Auto-scroll behaviour

`ConversationScrollButton` appears when the user scrolls up and the AI is still streaming.
It lets them jump back to the bottom:

```tsx
import { Conversation, ConversationContent, ConversationScrollButton } from '@/components/ai-elements/conversation';

<Conversation>
  <ConversationContent>
    {/* messages */}
  </ConversationContent>
  <ConversationScrollButton />
</Conversation>
```

---

## 5. Tool Calls & Tool Display

When your agent calls a tool, the AI SDK adds `tool-invocation` parts to the assistant message.
The `Tool` component renders them with a collapsible card.

```tsx
import { Tool } from '@/components/ai-elements/tool';

{message.parts?.map((part, i) => {
  if (part.type === 'text') {
    return <MessageResponse key={i}>{part.text}</MessageResponse>;
  }
  if (part.type === 'tool-invocation') {
    return (
      <Tool
        key={i}
        toolName={part.toolInvocation.toolName}
        state={part.toolInvocation.state}       // 'call' | 'result' | 'partial-call'
        args={part.toolInvocation.args}
        result={part.toolInvocation.result}     // undefined while streaming
      />
    );
  }
  return null;
})}
```

The `Tool` component renders:
- **Tool name** with an icon
- **Arguments** in a collapsible code block
- **State indicator** — spinning during execution, check on success, X on error
- **Result** in a collapsible output block

---

## 6. Reasoning / Chain-of-Thought Blocks

For models that expose reasoning (OpenAI o1/o3, Anthropic extended thinking, DeepSeek-R1):

```tsx
import { Reasoning, ReasoningContent, ReasoningTrigger } from '@/components/ai-elements/reasoning';

{message.parts?.map((part, i) => {
  if (part.type === 'reasoning') {
    return (
      <Reasoning key={i}>
        <ReasoningTrigger>View reasoning</ReasoningTrigger>
        <ReasoningContent>{part.reasoning}</ReasoningContent>
      </Reasoning>
    );
  }
  if (part.type === 'text') {
    return <MessageResponse key={i}>{part.text}</MessageResponse>;
  }
})}
```

The `Reasoning` component auto-collapses once the assistant response is complete, showing just a "View reasoning (Xms)" trigger. While streaming, it shows the thinking text incrementally.

---

## 7. Source Citations

For RAG agents that return cited sources:

```tsx
import { Source, Sources, SourcesContent, SourcesTrigger } from '@/components/ai-elements/sources';
import { InlineCitation } from '@/components/ai-elements/inline-citation';

// Stream sources as custom data from your API route:
// sendDataEvent({ type: 'sources', sources: [{title, url, snippet}] })

{message.parts?.map((part, i) => {
  if (part.type === 'text') {
    return (
      <MessageResponse key={i}>
        {part.text}
        {/* Inline superscript citation markers */}
        <InlineCitation index={1} />
      </MessageResponse>
    );
  }
  // Custom data part with sources
  if (part.type === 'data-sources') {
    return (
      <Sources key={i}>
        <SourcesTrigger>{part.sources.length} sources</SourcesTrigger>
        <SourcesContent>
          {part.sources.map((s, j) => (
            <Source key={j} title={s.title} url={s.url} snippet={s.snippet} />
          ))}
        </SourcesContent>
      </Sources>
    );
  }
})}
```

---

## 8. Suggestion Chips

Clickable suggestion prompts below the input or in the empty state:

```tsx
import { Suggestion, Suggestions } from '@/components/ai-elements/suggestion';

function SuggestionsBar({ onSelect }: { onSelect: (text: string) => void }) {
  return (
    <Suggestions>
      {['Check weather in London', 'Summarise this document', 'Write a haiku'].map(s => (
        <Suggestion
          key={s}
          suggestion={s}
          onClick={() => onSelect(s)}
          className="text-xs"
        >
          {s}
        </Suggestion>
      ))}
    </Suggestions>
  );
}

// In your empty state:
<ConversationEmptyState title="How can I help?">
  <SuggestionsBar onSelect={text => { sendMessage({ text }); }} />
</ConversationEmptyState>
```

---

## 9. File Attachments

The `PromptInput` supports file/image attachments out of the box via `PromptInputTools`:

```tsx
import {
  PromptInput, PromptInputTextarea, PromptInputSubmit,
  PromptInputButton, PromptInputFooter, PromptInputTools,
} from '@/components/ai-elements/prompt-input';
import { Attachments } from '@/components/ai-elements/attachments';
import { Paperclip } from 'lucide-react';
import { useChat } from '@ai-sdk/react';

export function ChatInput() {
  const { sendMessage, status } = useChat();

  return (
    <PromptInput
      onSubmit={(msg, e) => { e?.preventDefault(); sendMessage({ text: msg.text ?? '', experimental_attachments: msg.attachments }); }}
    >
      {/* Attachment previews above the textarea */}
      <Attachments />

      <PromptInputTextarea placeholder="Message..." />

      <PromptInputFooter>
        <PromptInputTools>
          <PromptInputButton tooltip="Attach file">
            <Paperclip size={16} />
          </PromptInputButton>
        </PromptInputTools>
        <PromptInputSubmit disabled={status === 'streaming'} />
      </PromptInputFooter>
    </PromptInput>
  );
}
```

On the backend, multimodal parts arrive in `message.parts` as `image` parts with base64 data.

---

## 10. Message Branching

Lets users navigate between alternative responses (like ChatGPT's "try again" flow):

```tsx
import {
  Message, MessageContent, MessageResponse,
  MessageBranch, MessageBranchSelector,
  MessageBranchContent, MessageBranchPrevious, MessageBranchNext, MessageBranchPage,
} from '@/components/ai-elements/message';

// When you have multiple response variants for a message:
<Message from="assistant">
  <MessageBranch>
    <MessageBranchSelector>
      <MessageBranchPrevious />
      <MessageBranchPage />   {/* Shows "1 / 3" */}
      <MessageBranchNext />
    </MessageBranchSelector>
    <MessageBranchContent>
      <MessageContent>
        <MessageResponse>{currentVariant}</MessageResponse>
      </MessageContent>
    </MessageBranchContent>
  </MessageBranch>
</Message>
```

---

## 11. Code & Artifact Display

### CodeBlock

```tsx
import { CodeBlock } from '@/components/ai-elements/code-block';

// Inside MessageResponse, code fences render automatically.
// To render one explicitly:
<CodeBlock language="python" code={`def hello(): return "world"`} />
```

Features: syntax highlighting, copy button, language badge, line numbers.

### Artifact (for generated HTML/React/code)

```tsx
import { Artifact } from '@/components/ai-elements/artifact';

<Artifact
  type="html"           // 'html' | 'react' | 'code' | 'markdown'
  title="My Component"
  content={generatedCode}
/>
```

### Terminal

```tsx
import { Terminal } from '@/components/ai-elements/terminal';

<Terminal output={["$ npm install", "added 42 packages", "✓ Done"]} />
```

### FileTree

```tsx
import { FileTree } from '@/components/ai-elements/file-tree';

<FileTree files={[
  { name: "src", type: "directory", children: [
    { name: "app.py", type: "file" },
    { name: "agent.py", type: "file" },
  ]},
  { name: "requirements.txt", type: "file" },
]} />
```

---

## 12. Voice Interface

```tsx
import { SpeechInput } from '@/components/ai-elements/speech-input';
import { AudioPlayer } from '@/components/ai-elements/audio-player';
import { Transcription } from '@/components/ai-elements/transcription';

// Speech-to-text input (mic button in PromptInput):
<SpeechInput onTranscript={text => setInput(text)} />

// Live transcription display during recording:
<Transcription text={partialTranscript} isFinal={false} />

// Audio playback for TTS responses:
<AudioPlayer src={audioUrl} autoPlay />
```

---

## 13. Workflow / Graph Visualisation

Useful for building visual agent pipeline UIs (like a simplified LangGraph Studio):

```tsx
import { Canvas } from '@/components/ai-elements/canvas';
import { Node } from '@/components/ai-elements/node';
import { Edge } from '@/components/ai-elements/edge';
import { Controls } from '@/components/ai-elements/controls';
import { Panel } from '@/components/ai-elements/panel';

<Canvas>
  <Node id="start" label="Start" position={{ x: 100, y: 100 }} status="complete" />
  <Node id="agent" label="Agent" position={{ x: 100, y: 250 }} status="active" />
  <Node id="tools" label="Tools" position={{ x: 300, y: 250 }} status="pending" />
  <Edge from="start" to="agent" />
  <Edge from="agent" to="tools" />
  <Controls />
  <Panel position="top-right">
    <p>Current node: agent</p>
  </Panel>
</Canvas>
```

---

## 14. Human-in-the-Loop UI Patterns

### Confirmation dialog

When your LangGraph agent `interrupt()`s execution for human approval, surface a `Confirmation`:

```tsx
import { Confirmation } from '@/components/ai-elements/confirmation';

// Check for interrupt data in message parts
{message.parts?.map((part, i) => {
  if (part.type === 'data-interrupt') {
    return (
      <Confirmation
        key={i}
        title="Approve action?"
        description={part.data.question}
        onConfirm={() => resumeGraph({ approved: true })}
        onCancel={() => resumeGraph({ approved: false, reason: 'User cancelled' })}
      />
    );
  }
})}
```

Wire `resumeGraph` to a POST to your backend with a LangGraph `Command(resume=...)`.

### Context display (RAG / retrieved docs)

```tsx
import { Context } from '@/components/ai-elements/context';

<Context documents={[
  { title: "Policy Doc v3", excerpt: "Section 4.2 states...", score: 0.94 },
  { title: "FAQ", excerpt: "The answer is...", score: 0.87 },
]} />
```

### Task / Plan progress

```tsx
import { Task } from '@/components/ai-elements/task';
import { Plan } from '@/components/ai-elements/plan';

// Show step-by-step agent plan
<Plan steps={[
  { label: "Research the topic", status: "complete" },
  { label: "Draft outline", status: "active" },
  { label: "Write full response", status: "pending" },
]} />

// Show a single task status
<Task name="Search web" status="complete" result="Found 8 results" />
```

---

## 15. Model Selector

```tsx
import { ModelSelector } from '@/components/ai-elements/model-selector';

const MODELS = [
  { id: 'gpt-4o', label: 'GPT-4o', provider: 'openai' },
  { id: 'claude-3-5-sonnet-20241022', label: 'Claude 3.5 Sonnet', provider: 'anthropic' },
  { id: 'gpt-4o-mini', label: 'GPT-4o mini', provider: 'openai' },
];

export function Header() {
  const [model, setModel] = useState('gpt-4o');
  return (
    <header className="flex items-center gap-4 p-4 border-b">
      <h1>My Agent</h1>
      <ModelSelector
        models={MODELS}
        value={model}
        onValueChange={setModel}
      />
    </header>
  );
}
```

Pass the selected `model` to `useChat({ body: { model } })`, then read `body.model` in your API route.

---

## 16. Theming & Customisation

### CSS variables (shadcn/ui)

AI Elements inherits all shadcn/ui CSS variables. Change your theme by modifying `globals.css`:

```css
:root {
  --background: 0 0% 100%;
  --foreground: 222.2 84% 4.9%;
  --primary: 222.2 47.4% 11.2%;
  /* ... */
}
```

Generate a custom theme: https://ui.shadcn.com/themes

### Dark mode

Add the `dark` class to `<html>` (or use `next-themes`):

```tsx
// app/layout.tsx
import { ThemeProvider } from 'next-themes';

<ThemeProvider attribute="class" defaultTheme="system">
  {children}
</ThemeProvider>
```

### Customising individual components

Because components are copied into your codebase, open any file and edit it directly:

```
components/ai-elements/message.tsx       ← change bubble colours
components/ai-elements/reasoning.tsx     ← change reasoning block appearance
components/ai-elements/tool.tsx          ← change tool card layout
```

### Tailwind class overrides

All components accept a `className` prop for ad-hoc overrides:

```tsx
<Message from="assistant" className="bg-blue-50 dark:bg-blue-950">
<PromptInputTextarea className="font-mono text-sm" />
```

---

## 17. useChat Deep-Dive (AI SDK v6)

> Full reference: https://ai-sdk.dev/docs/reference/ai-sdk-ui/use-chat

### Key API (v6 — breaking changes from v4/v5)

```tsx
const {
  messages,          // UIMessage[] — use message.parts[], not message.content
  sendMessage,       // replaces handleSubmit + append in v6
  status,            // 'idle' | 'submitted' | 'streaming' | 'error'
  stop,              // cancel streaming
  reload,            // retry last message
  error,             // Error | undefined
  addToolResult,     // submit tool result for client-side tools
  experimental_resume, // resume after network interruption
} = useChat({
  api: '/api/chat',                  // default
  initialMessages: [],
  body: { model: 'gpt-4o-mini' },   // extra fields sent with every request
  headers: { Authorization: '...' },
  onFinish: (message) => { /* called when streaming ends */ },
  onError: (error) => { /* called on error */ },
});
```

### Sending messages

```tsx
// Text only
sendMessage({ text: 'Hello!' });

// With attachments
sendMessage({
  text: 'Here is a file',
  experimental_attachments: [{ name: 'doc.pdf', url: dataUrl, contentType: 'application/pdf' }],
});
```

### Reading message parts

```tsx
// messages[].parts replaces messages[].content in v6
message.parts?.forEach(part => {
  switch (part.type) {
    case 'text':            // { type: 'text', text: string }
    case 'reasoning':       // { type: 'reasoning', reasoning: string }
    case 'tool-invocation': // { type: 'tool-invocation', toolInvocation: {...} }
    case 'source':          // { type: 'source', source: {...} }
    case 'file':            // { type: 'file', ... }
    case 'step-start':      // marks beginning of a new agent step
  }
});
```

### Client-side tool execution

```tsx
const { messages, addToolResult } = useChat({
  async onToolCall({ toolCall }) {
    if (toolCall.toolName === 'getLocation') {
      const coords = await navigator.geolocation.getCurrentPosition(...);
      return { lat: coords.latitude, lng: coords.longitude };
    }
  },
});
```

---

## 18. Complete Production Example

A feature-complete chat page with: tool display, reasoning, suggestions, sources, model selector, and dark mode toggle.

```tsx
'use client';

import { useState } from 'react';
import { useChat } from '@ai-sdk/react';

import { Conversation, ConversationContent, ConversationEmptyState, ConversationScrollButton } from '@/components/ai-elements/conversation';
import { Message, MessageContent, MessageResponse, MessageBranch, MessageBranchContent, MessageBranchPrevious, MessageBranchNext, MessageBranchPage, MessageBranchSelector } from '@/components/ai-elements/message';
import { PromptInput, PromptInputTextarea, PromptInputSubmit, PromptInputFooter, PromptInputTools, PromptInputButton } from '@/components/ai-elements/prompt-input';
import { Tool } from '@/components/ai-elements/tool';
import { Reasoning, ReasoningContent, ReasoningTrigger } from '@/components/ai-elements/reasoning';
import { Sources, SourcesContent, SourcesTrigger, Source } from '@/components/ai-elements/sources';
import { Suggestions, Suggestion } from '@/components/ai-elements/suggestion';
import { Plan } from '@/components/ai-elements/plan';
import { ModelSelector } from '@/components/ai-elements/model-selector';
import { Paperclip, Moon, Sun } from 'lucide-react';

const MODELS = [
  { id: 'gpt-4o', label: 'GPT-4o' },
  { id: 'gpt-4o-mini', label: 'GPT-4o Mini' },
];

const SUGGESTIONS = [
  "What's the weather in Tokyo?",
  'Write me a Python script',
  'Explain quantum entanglement',
];

export default function ProductionChat() {
  const [input, setInput] = useState('');
  const [model, setModel] = useState('gpt-4o-mini');
  const [dark, setDark] = useState(false);

  const { messages, sendMessage, status, stop } = useChat({
    api: '/api/chat',
    body: { model },
  });

  const isLoading = status === 'streaming' || status === 'submitted';

  function handleSend(text: string) {
    const t = text.trim();
    if (!t || isLoading) return;
    sendMessage({ text: t });
    setInput('');
  }

  return (
    <div className={dark ? 'dark' : ''}>
      <div className="flex flex-col h-screen bg-background text-foreground">

        {/* Header */}
        <header className="shrink-0 border-b px-4 py-3 flex items-center gap-3">
          <span className="font-semibold">LangGraph Agent</span>
          <ModelSelector models={MODELS} value={model} onValueChange={setModel} />
          <div className="ml-auto flex items-center gap-2">
            <span className={`text-xs px-2 py-0.5 rounded-full ${isLoading ? 'bg-amber-100 text-amber-700' : 'bg-green-100 text-green-700'}`}>
              {isLoading ? 'Streaming…' : 'Ready'}
            </span>
            {isLoading && <button onClick={stop} className="text-xs underline">Stop</button>}
            <button onClick={() => setDark(d => !d)}>
              {dark ? <Sun size={16} /> : <Moon size={16} />}
            </button>
          </div>
        </header>

        {/* Messages */}
        <Conversation className="flex-1 min-h-0">
          <ConversationContent>
            {messages.length === 0 ? (
              <div className="flex flex-col items-center gap-4 pt-12">
                <ConversationEmptyState title="How can I help?" description="Try one of these:" />
                <Suggestions>
                  {SUGGESTIONS.map(s => (
                    <Suggestion key={s} suggestion={s} onClick={() => handleSend(s)}>{s}</Suggestion>
                  ))}
                </Suggestions>
              </div>
            ) : (
              messages.map(m => (
                <Message key={m.id} from={m.role}>
                  <MessageContent>
                    {m.parts?.map((part, i) => {
                      if (part.type === 'reasoning') return (
                        <Reasoning key={i}>
                          <ReasoningTrigger>View reasoning</ReasoningTrigger>
                          <ReasoningContent>{part.reasoning}</ReasoningContent>
                        </Reasoning>
                      );
                      if (part.type === 'tool-invocation') return (
                        <Tool key={i}
                          toolName={part.toolInvocation.toolName}
                          state={part.toolInvocation.state}
                          args={part.toolInvocation.args}
                          result={part.toolInvocation.result}
                        />
                      );
                      if (part.type === 'text') {
                        return m.role === 'assistant'
                          ? <MessageResponse key={i}>{part.text}</MessageResponse>
                          : <span key={i} className="whitespace-pre-wrap">{part.text}</span>;
                      }
                      return null;
                    })}
                  </MessageContent>
                </Message>
              ))
            )}
          </ConversationContent>
          <ConversationScrollButton />
        </Conversation>

        {/* Input */}
        <div className="shrink-0 border-t p-4">
          <PromptInput
            onSubmit={(msg, e) => { e?.preventDefault(); handleSend(msg.text ?? ''); }}
            className="max-w-3xl mx-auto"
          >
            <PromptInputTextarea
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(input); } }}
              placeholder="Message the agent… (Shift+Enter for new line)"
              disabled={isLoading}
              rows={1}
            />
            <PromptInputFooter>
              <PromptInputTools>
                <PromptInputButton tooltip="Attach file"><Paperclip size={14} /></PromptInputButton>
              </PromptInputTools>
              <PromptInputSubmit disabled={isLoading} />
            </PromptInputFooter>
          </PromptInput>
        </div>
      </div>
    </div>
  );
}
```

---

## 19. Key Gotchas

### `messages[].content` is gone in AI SDK v6
Use `messages[].parts` (an array of typed part objects). The old `message.content: string` is gone.

### `handleSubmit` / `handleInputChange` are gone in v6
Use `sendMessage({ text: '...' })` instead.

### `MessageResponse` is not just a `<div>`
It's an optimised streaming markdown renderer. Only pass **a single string** (or concatenated string) to it — don't render JSX children inside it.

### Composition order matters in `Message`
Always: `Message > MessageContent > [Reasoning | Tool | MessageResponse]`. Don't skip levels.

### AI Elements components are installed locally
After `npx ai-elements@latest`, the components live in your repo at `components/ai-elements/`. They are not an npm package. Update them by running the install command again.

### CSS variables must exist before rendering
If you see unstyled or invisible components, your `globals.css` is missing the `:root { --background: ... }` block. Verify with the file in this project.

### `ConversationScrollButton` requires the parent to be a flex column
`Conversation` must be in a flex-col container with a fixed height (like `h-screen`) to enable overflow scrolling. Without this, auto-scroll won't work.

### Tool results only available on `state === 'result'`
`part.toolInvocation.result` is `undefined` while the tool is running (`state === 'call'`). Guard against this:
```tsx
{part.toolInvocation.state === 'result' && <pre>{JSON.stringify(part.toolInvocation.result)}</pre>}
```
