"""
FastAPI microservice for the LangGraph agent.

Key design decisions (based on verified API behavior):

1.  Messages from the Next.js frontend arrive as JSON-serialized LangChain
    objects (toBaseMessages() on the JS side calls .toJSON() on each
    BaseMessage, producing the dumpd-format: {"lc":1,"type":"constructor",...}).
    We use langchain_core.load.load() to reconstruct Python objects from this.

2.  We do NOT use dumpd() on the event output because that format wraps
    Python objects in {"lc":1,...} which the JS toUIMessageStream() cannot
    read as plain properties.  Instead we hand-serialize each event into a
    clean dict with primitives only, matching the shape that @ai-sdk/langchain
    expects for LangChainStreamEvent.

3.  We stream as application/x-ndjson (one JSON line per event) with the
    X-Accel-Buffering: no header so Nginx proxies don't buffer the stream.
"""

from __future__ import annotations

import json
import logging
from typing import Any, AsyncGenerator

from dotenv import load_dotenv
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from langchain_core.load import load
from langchain_core.messages import AIMessage, HumanMessage

from agent import get_graph

load_dotenv()

logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(name)s — %(message)s")
logger = logging.getLogger("langgraph_api")

app = FastAPI(title="LangGraph Agent API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["POST", "GET", "OPTIONS"],
    allow_headers=["*"],
)


# ---------------------------------------------------------------------------
# Event serialisation
# ---------------------------------------------------------------------------

def _extract_content(obj: Any) -> str:
    """Pull a plain-text string out of an AIMessageChunk / AIMessage / str."""
    if obj is None:
        return ""
    if isinstance(obj, str):
        return obj
    c = getattr(obj, "content", None)
    if c is None:
        return ""
    if isinstance(c, str):
        return c
    if isinstance(c, list):
        # Multi-modal content list — extract text blocks only
        return "".join(
            block.get("text", "")
            for block in c
            if isinstance(block, dict) and block.get("type") == "text"
        )
    return str(c)


def _extract_tool_calls(obj: Any) -> list[dict]:
    """Extract tool_calls from an AIMessageChunk for streaming tool-call events."""
    tool_calls = getattr(obj, "tool_call_chunks", None) or getattr(obj, "tool_calls", None)
    if not tool_calls:
        return []
    result = []
    for tc in tool_calls:
        if isinstance(tc, dict):
            result.append({
                "id": tc.get("id", ""),
                "name": tc.get("name", ""),
                "args": tc.get("args", tc.get("arguments", "")),
                "index": tc.get("index", 0),
            })
    return result


def serialize_event(event: dict) -> dict:
    """
    Translate a Python astream_events v2 event dict into a clean JSON-safe
    dict whose shape matches what @ai-sdk/langchain's toUIMessageStream()
    expects for LangChainStreamEvent objects.

    Supported event types:
        on_chain_start / on_chain_end
        on_chat_model_start / on_chat_model_stream / on_chat_model_end
        on_tool_start / on_tool_end
    """
    event_type: str = event.get("event", "")
    name: str = event.get("name", "")
    run_id: str = str(event.get("run_id", ""))
    data: dict = event.get("data", {})

    # Only propagate scalar metadata to keep payloads small
    metadata: dict = {
        k: v
        for k, v in event.get("metadata", {}).items()
        if isinstance(v, (str, int, float, bool))
    }

    result: dict = {
        "event": event_type,
        "name": name,
        "run_id": run_id,
        "tags": event.get("tags", []),
        "metadata": metadata,
        "data": {},
    }

    if event_type == "on_chat_model_stream":
        chunk = data.get("chunk")
        result["data"] = {
            "chunk": {
                "content": _extract_content(chunk),
                "tool_call_chunks": _extract_tool_calls(chunk),
                "id": str(getattr(chunk, "id", "") or ""),
            }
        }

    elif event_type == "on_chat_model_end":
        output = data.get("output")
        result["data"] = {"output": {"content": _extract_content(output)}}

    elif event_type == "on_tool_start":
        result["data"] = {
            "input": data.get("input", {}),
            "name": name,
        }

    elif event_type == "on_tool_end":
        output = data.get("output")
        output_str = _extract_content(output) if output is not None else str(output)
        result["data"] = {"output": output_str, "name": name}

    elif event_type in ("on_chain_start", "on_chain_end"):
        # Pass chain events through (used by the adapter for graph-level signals)
        result["data"] = {}

    return result


# ---------------------------------------------------------------------------
# Message deserialisation
# ---------------------------------------------------------------------------

def deserialize_messages(raw: list[Any]) -> list:
    """
    Convert the JSON payload from toBaseMessages() back to Python LangChain
    message objects.  Falls back to building HumanMessage / AIMessage from
    plain role+content dicts if load() fails (e.g. custom serialisation).
    """
    messages = []
    for m in raw:
        try:
            messages.append(load(m))
        except Exception:
            # Fallback path for plain {role, content} dicts
            if isinstance(m, dict):
                role = m.get("role") or m.get("type", "human")
                content = m.get("content", "")
                if role in ("user", "human"):
                    messages.append(HumanMessage(content=content))
                else:
                    messages.append(AIMessage(content=content))
    return messages


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.get("/health")
async def health():
    return {"status": "ok"}


@app.post("/api/chat")
async def chat_endpoint(request: Request):
    """
    Accept a JSON body:
        { "messages": [ <LangChain-serialised BaseMessage>, ... ] }

    Stream back NDJSON events compatible with @ai-sdk/langchain's
    toUIMessageStream().
    """
    body = await request.json()
    lc_messages = deserialize_messages(body.get("messages", []))

    if not lc_messages:
        return {"error": "No messages provided"}, 400

    graph = get_graph()

    async def event_stream() -> AsyncGenerator[str, None]:
        try:
            async for event in graph.astream_events(
                {"messages": lc_messages},
                version="v2",
            ):
                try:
                    serialized = serialize_event(event)
                    yield json.dumps(serialized) + "\n"
                except Exception as inner_exc:
                    logger.warning("Failed to serialise event %s: %s", event.get("event"), inner_exc)
        except Exception as exc:
            logger.exception("Streaming error")
            yield json.dumps({
                "event": "on_error",
                "name": "error",
                "run_id": "",
                "tags": [],
                "metadata": {},
                "data": {"error": str(exc)},
            }) + "\n"

    return StreamingResponse(
        event_stream(),
        media_type="application/x-ndjson",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",  # Prevent Nginx from buffering the stream
        },
    )
