'use client';

/**
 * app/page.tsx
 *
 * Chat UI built with Vercel AI Elements (verified component API).
 *
 * AI Elements install command (run once inside the frontend/ directory):
 *   npx ai-elements@latest
 *
 * Components used (from @/components/ai-elements/):
 *   Conversation / ConversationContent / ConversationEmptyState
 *   Message / MessageContent / MessageResponse
 *   PromptInput / PromptInputTextarea / PromptInputSubmit
 *
 * useChat() from @ai-sdk/react (AI SDK v6):
 *   - sendMessage({ text }) instead of the v4 handleSubmit / append
 *   - messages[].parts  instead of messages[].content
 *   - status: 'idle' | 'submitted' | 'streaming' | 'error'
 */

import { useState } from 'react';
import { useChat } from '@ai-sdk/react';

// ── AI Elements ─────────────────────────────────────────────────────────────
// These are installed locally by `npx ai-elements@latest`.
// They live in components/ai-elements/ as part of YOUR codebase (shadcn style).
import {
  Conversation,
  ConversationContent,
  ConversationEmptyState,
} from '@/components/ai-elements/conversation';
import {
  Message,
  MessageContent,
  MessageResponse,
} from '@/components/ai-elements/message';
import {
  PromptInput,
  PromptInputTextarea,
  PromptInputSubmit,
} from '@/components/ai-elements/prompt-input';

// ── Suggestion chips ─────────────────────────────────────────────────────────
const SUGGESTIONS = [
  "What's the weather in Tokyo?",
  'Calculate 15% tip on $84.50',
  'Explain LangGraph in one paragraph',
  "What's 2^10 + 3^5?",
];

export default function ChatPage() {
  const [input, setInput] = useState('');
  const { messages, sendMessage, status } = useChat();

  const isLoading = status === 'streaming' || status === 'submitted';

  function handleSend(text: string) {
    const trimmed = text.trim();
    if (!trimmed || isLoading) return;
    sendMessage({ text: trimmed });
    setInput('');
  }

  return (
    <div className="flex flex-col h-screen bg-background text-foreground">
      {/* ── Header ─────────────────────────────────────────────────────────── */}
      <header className="shrink-0 border-b px-4 py-3 flex items-center gap-3">
        <div className="size-8 rounded-lg bg-primary flex items-center justify-center shadow-sm">
          <span className="text-primary-foreground text-xs font-bold select-none">LG</span>
        </div>
        <div>
          <h1 className="font-semibold text-sm leading-none">LangGraph Agent</h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            Python backend · Vercel AI SDK · AI Elements
          </p>
        </div>

        {/* Status pill */}
        <span
          className={`ml-auto text-xs px-2 py-0.5 rounded-full font-medium transition-colors ${
            isLoading
              ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400'
              : 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400'
          }`}
        >
          {isLoading ? 'Thinking…' : 'Ready'}
        </span>
      </header>

      {/* ── Messages ───────────────────────────────────────────────────────── */}
      <Conversation className="flex-1 min-h-0">
        <ConversationContent>
          {messages.length === 0 ? (
            <div className="flex flex-col items-center gap-6 pt-12">
              <ConversationEmptyState
                title="LangGraph Agent"
                description="Ask me anything. I can check weather, do math, and more."
              />

              {/* Suggestion chips */}
              <div className="flex flex-wrap justify-center gap-2 max-w-xl px-4">
                {SUGGESTIONS.map((s) => (
                  <button
                    key={s}
                    onClick={() => handleSend(s)}
                    className="text-xs px-3 py-1.5 rounded-full border border-border bg-muted hover:bg-accent transition-colors"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            messages.map((message) => (
              <Message key={message.id} from={message.role}>
                <MessageContent>
                  {message.role === 'assistant' ? (
                    // MessageResponse renders markdown with syntax highlighting
                    <MessageResponse>
                      {message.parts
                        ?.filter((p) => p.type === 'text')
                        .map((p) => p.text)
                        .join('')}
                    </MessageResponse>
                  ) : (
                    // User messages: plain text
                    message.parts?.map((part, i) =>
                      part.type === 'text' ? (
                        <span key={i} className="whitespace-pre-wrap">
                          {part.text}
                        </span>
                      ) : null,
                    )
                  )}
                </MessageContent>
              </Message>
            ))
          )}
        </ConversationContent>
      </Conversation>

      {/* ── Input ──────────────────────────────────────────────────────────── */}
      <div className="shrink-0 border-t bg-background/80 backdrop-blur px-4 py-4">
        <PromptInput
          onSubmit={(msg, event) => {
            event?.preventDefault();
            handleSend(msg.text ?? '');
          }}
          className="max-w-3xl mx-auto flex gap-2 items-end"
        >
          <PromptInputTextarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend(input);
              }
            }}
            placeholder="Ask the LangGraph agent… (Shift+Enter for new line)"
            disabled={isLoading}
            rows={1}
            className="flex-1 resize-none"
          />
          <PromptInputSubmit disabled={isLoading} />
        </PromptInput>
        <p className="text-center text-xs text-muted-foreground mt-2">
          LangGraph · FastAPI · @ai-sdk/langchain · Vercel AI Elements
        </p>
      </div>
    </div>
  );
}
