# LangGraph + Vercel AI SDK + AI Elements

A full-stack agentic application that combines:

- **Python/FastAPI backend** — LangGraph agent (ReAct or custom StateGraph)
- **Next.js API route** — bridges the Python backend to the Vercel AI SDK stream protocol
- **AI Elements frontend** — production-grade chat UI built on shadcn/ui

```
Browser (useChat)
    ↕  UIMessage stream
Next.js /api/chat  (toBaseMessages / toUIMessageStream)
    ↕  NDJSON (LangGraph astream_events)
FastAPI /api/chat  (LangGraph graph.astream_events)
    ↕
LangGraph agent (create_react_agent or custom StateGraph)
```

---

## What was verified & corrected from the original concept

| Claim in original | Reality (verified against docs) |
|---|---|
| `dumpd(event)` for streaming | **Broken.** `dumpd` wraps objects as `{"lc":1,...}` which `toUIMessageStream` can't read as plain properties. Use custom serialisation instead. |
| Pass async generator directly to `toUIMessageStream` | **Broken.** It expects `ReadableStream`, not `AsyncIterable`. Wrap with `ReadableStream.from(gen)`. |
| `<Message message={m} />` single prop | **Wrong API.** Real AI Elements API is `<Message from={role}><MessageContent>...</MessageContent></Message>` |
| `messages[].content` in useChat | **AI SDK v6 uses** `messages[].parts` (array of typed parts) |
| `handleSubmit` / `handleInputChange` | **AI SDK v6 uses** `sendMessage({ text })` |
| `<Conversation className>` wrapping input | `Conversation` wraps messages only; input stays outside |

---

## Project structure

```
langgraph-vercel-ai/
├── backend/
│   ├── main.py           # FastAPI app — NDJSON streaming, event serialisation
│   ├── agent.py          # LangGraph graph definitions (2 swappable patterns)
│   ├── requirements.txt
│   └── .env.example
└── frontend/
    ├── app/
    │   ├── api/chat/route.ts   # Next.js bridge: toBaseMessages → FastAPI → toUIMessageStream
    │   ├── page.tsx            # Chat UI using AI Elements
    │   ├── layout.tsx
    │   └── globals.css         # shadcn/ui CSS variables (required by AI Elements)
    ├── components/
    │   └── ai-elements/        # Installed by `npx ai-elements@latest` (not in repo)
    ├── lib/utils.ts            # cn() helper for shadcn
    ├── components.json         # shadcn config (required by ai-elements installer)
    ├── tailwind.config.ts
    ├── tsconfig.json
    └── package.json
```

---

## Setup

### Prerequisites

- Python ≥ 3.11
- Node.js ≥ 18 (for `ReadableStream.from()`)
- An OpenAI API key

---

### 1 — Backend

```bash
cd backend

# Create a virtual environment
python -m venv .venv
source .venv/bin/activate       # Windows: .venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env and add your OPENAI_API_KEY

# Start the server
uvicorn main:app --reload --port 8000
```

Visit `http://localhost:8000/health` — you should see `{"status":"ok"}`.

---

### 2 — Frontend

```bash
cd frontend

# Install npm dependencies
npm install          # or pnpm install / yarn

# Install AI Elements (installs components into components/ai-elements/)
npx ai-elements@latest

# When prompted:
#   - Confirm installation path (press Enter)
#   - Select Yes to overwrite if prompted

# Configure environment
cp .env.local.example .env.local
# Edit .env.local if your backend runs on a different port

# Start Next.js dev server
npm run dev
```

Open `http://localhost:3000`.

---

## Swapping between agent patterns

`backend/agent.py` exports two graph factories:

```python
def get_react_agent():
    """Prebuilt ReAct agent — create_react_agent() from langgraph.prebuilt."""

def get_custom_graph():
    """Custom StateGraph with explicit agent ↔ tools loop."""
```

At the bottom of `agent.py`, change `get_graph()` to return whichever you want:

```python
def get_graph():
    return get_react_agent()       # ← swap to get_custom_graph() here
```

### Plugging in any compiled LangGraph graph

`main.py` calls `get_graph()` and calls `.astream_events({"messages": ...}, version="v2")` on the result. Any compiled `StateGraph` / `CompiledGraph` object that accepts a `messages` key in its input dict will work. For graphs with a different state shape, update the invocation in `main.py`:

```python
# main.py — chat_endpoint
async for event in graph.astream_events(
    {"messages": lc_messages, "your_extra_key": "value"},
    version="v2",
):
```

---

## Adding MCP tools

Add this to `agent.py`:

```python
# pip install langchain-mcp-adapters mcp
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from langchain_mcp_adapters.tools import load_mcp_tools

async def load_mcp_server_tools(command: str, args: list[str]) -> list:
    server_params = StdioServerParameters(command=command, args=args)
    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            return await load_mcp_tools(session)
```

For persistent MCP connections (tools loaded at startup), use FastAPI's `lifespan` context manager to keep stdio sessions alive — see the backend section of the original concept for the pattern (the lifespan/session code there is correct; only the serialisation needed fixing).

---

## Architecture deep-dive

### Why not `dumpd()` for the event stream?

`dumpd()` serialises Python LangChain objects into a portable cross-language format:
```json
{"lc": 1, "type": "constructor", "id": ["langchain_core", "messages", "AIMessageChunk"],
 "kwargs": {"content": "Hello"}}
```

The problem: `@ai-sdk/langchain`'s `toUIMessageStream` accesses `event.data.chunk.content` as a direct property. After `dumpd`, there is no `content` at the top level — it's buried under `kwargs.content`. The stream would silently produce empty output.

**Solution:** Extract content as plain primitives in Python before serialising.

### Why `ReadableStream.from(gen)` instead of passing the generator directly?

`toUIMessageStream` is typed as:
```ts
function toUIMessageStream(
  stream: ReadableStream<LangChainStreamEvent>
         | ReadableStream<LangChainAIMessageChunk>
         | ReadableStream<string>
): UIMessageStream
```

It expects a `ReadableStream`. An async generator is `AsyncIterable`, not a `ReadableStream`. In Node 18+ and all Next.js 14+ environments, `ReadableStream.from(asyncIterable)` converts between them.

### Message serialisation round-trip

```
JS:     UIMessage[]
          ↓ toBaseMessages()
        BaseMessage[]  (LangChain JS instances)
          ↓ JSON.stringify()  (calls .toJSON() → dumpd format on each message)
        [{"lc":1,"type":"constructor","id":["...","HumanMessage"],"kwargs":{...}}]
          ↓ HTTP POST body

Python: raw list of dicts
          ↓ langchain_core.load.load(m) for each
        [HumanMessage(content="..."), ...]  (Python LangChain objects)
```

This round-trip works because both ecosystems implement the same `dumpd`/`load` specification. Only the *event* output needs custom serialisation — the *message input* serialisation works fine with `dumpd`/`load`.

---

## Extending the UI

AI Elements includes 20+ components. After `npx ai-elements@latest` you'll have them all in `components/ai-elements/`. Useful additions for an agent UI:

```tsx
// Show AI reasoning (for o1/o3 models)
import { Reasoning } from '@/components/ai-elements/reasoning';

// Show tool calls inline
import { Tool } from '@/components/ai-elements/tool';

// Quick reply buttons
import { Suggestion } from '@/components/ai-elements/suggestion';

// File upload support
import { Attachment } from '@/components/ai-elements/attachment';
```

To render tool call parts in messages, filter `message.parts` by type:

```tsx
{message.parts?.map((part, i) => {
  if (part.type === 'text') return <MessageResponse key={i}>{part.text}</MessageResponse>;
  if (part.type === 'tool-invocation') return <Tool key={i} toolInvocation={part.toolInvocation} />;
  return null;
})}
```
