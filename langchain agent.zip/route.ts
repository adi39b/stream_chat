/**
 * app/api/chat/route.ts
 *
 * Next.js App Router route that bridges the Vercel AI SDK (frontend)
 * with the Python/LangGraph FastAPI backend.
 *
 * Flow:
 *   1. Receive UIMessage[] from the useChat hook
 *   2. Convert to LangChain BaseMessage format via toBaseMessages()
 *      — these serialize as dumpd-compatible JSON that Python's load() understands
 *   3. POST to the FastAPI backend and receive an NDJSON stream of LangGraph events
 *   4. Parse each JSON line and pipe into toUIMessageStream()
 *      — this converts LangChain stream events → Vercel AI SDK UIMessageStream
 *   5. Return as a createUIMessageStreamResponse
 *
 * Why ReadableStream.from(asyncGenerator) instead of the generator directly:
 *   toUIMessageStream() is typed to accept ReadableStream, not AsyncIterable,
 *   so we wrap the generator explicitly (works in Node 18+ / Next.js 14+).
 */

import { toBaseMessages, toUIMessageStream } from '@ai-sdk/langchain';
import { createUIMessageStreamResponse, UIMessage } from 'ai';

export const maxDuration = 60; // seconds — increase for long agent runs

const BACKEND_URL =
  process.env.LANGGRAPH_BACKEND_URL ?? 'http://127.0.0.1:8000';

export async function POST(req: Request) {
  const { messages }: { messages: UIMessage[] } = await req.json();

  // ─── 1. Convert Vercel UIMessages → LangChain BaseMessages ─────────────────
  // toBaseMessages() returns LangChain JS BaseMessage instances.
  // JSON.stringify() calls .toJSON() on each, producing dumpd-format objects
  // that Python's langchain_core.load.load() can deserialise correctly.
  const langchainMessages = await toBaseMessages(messages);

  // ─── 2. Hit the Python FastAPI backend ─────────────────────────────────────
  const response = await fetch(`${BACKEND_URL}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ messages: langchainMessages }),
  });

  if (!response.ok || !response.body) {
    const text = await response.text().catch(() => 'unknown error');
    throw new Error(`Backend responded with ${response.status}: ${text}`);
  }

  // ─── 3. Parse the NDJSON stream into an async generator of event objects ───
  async function* yieldEvents() {
    const reader = response.body!.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });

      // Split on newlines; keep the last (potentially incomplete) chunk buffered
      const lines = buffer.split('\n');
      buffer = lines.pop() ?? '';

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed) continue;
        try {
          yield JSON.parse(trimmed) as Record<string, unknown>;
        } catch {
          console.warn('[chat/route] Failed to parse NDJSON line:', trimmed);
        }
      }
    }

    // Flush any remaining buffered content
    if (buffer.trim()) {
      try {
        yield JSON.parse(buffer.trim()) as Record<string, unknown>;
      } catch {
        // Ignore trailing incomplete line
      }
    }
  }

  // ─── 4. Convert to ReadableStream (required by toUIMessageStream) ──────────
  // Node 18+ / Next.js 14+ support ReadableStream.from(asyncIterable).
  const eventStream = ReadableStream.from(yieldEvents());

  // ─── 5. Return the Vercel AI SDK-compatible streaming response ─────────────
  return createUIMessageStreamResponse({
    stream: toUIMessageStream(eventStream),
  });
}
