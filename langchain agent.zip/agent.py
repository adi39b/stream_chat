"""
LangGraph agent definitions.

This module provides two swappable patterns:
  1. get_react_agent()   — prebuilt ReAct agent via create_react_agent()
  2. get_custom_graph()  — fully explicit StateGraph with ToolNode

Call get_graph() to get whichever is active.
Swap the return at the bottom of this file to switch patterns.
"""

from __future__ import annotations

from typing import Annotated, TypedDict

from langchain_core.messages import BaseMessage
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langgraph.graph import END, START, MessagesState, StateGraph
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode, create_react_agent


# ---------------------------------------------------------------------------
# Tools — add your own tools here
# ---------------------------------------------------------------------------

@tool
def get_weather(location: str) -> str:
    """Get the current weather for a location."""
    # Replace with a real weather API call in production
    return f"The weather in {location} is currently sunny and 72°F."


@tool
def calculate(expression: str) -> str:
    """Evaluate a basic math expression (e.g. '2 + 2 * 10')."""
    allowed = set("0123456789+-*/()%. ")
    if not all(c in allowed for c in expression):
        return "Error: expression contains unsafe characters."
    try:
        result = eval(expression, {"__builtins__": {}})  # noqa: S307
        return f"Result: {result}"
    except Exception as exc:
        return f"Error: {exc}"


TOOLS = [get_weather, calculate]


# ---------------------------------------------------------------------------
# Pattern 1 — create_react_agent (simplest, recommended for tool-using agents)
# ---------------------------------------------------------------------------

def get_react_agent():
    """Return a prebuilt ReAct agent using langgraph.prebuilt.create_react_agent."""
    model = ChatOpenAI(model="gpt-4o-mini", streaming=True)
    return create_react_agent(
        model,
        TOOLS,
        prompt="You are a helpful assistant. Use tools when appropriate.",
    )


# ---------------------------------------------------------------------------
# Pattern 2 — Custom StateGraph (full control over topology / state)
# ---------------------------------------------------------------------------

class AgentState(TypedDict):
    messages: Annotated[list[BaseMessage], add_messages]


def get_custom_graph():
    """
    Return a custom StateGraph that replicates the ReAct loop explicitly.

    Graph topology:
        START → agent → (tools → agent)* → END
    """
    model = ChatOpenAI(model="gpt-4o-mini", streaming=True).bind_tools(TOOLS)

    def call_model(state: AgentState) -> dict:
        response = model.invoke(state["messages"])
        return {"messages": [response]}

    def route(state: AgentState) -> str:
        last = state["messages"][-1]
        if getattr(last, "tool_calls", None):
            return "tools"
        return END

    graph = (
        StateGraph(AgentState)
        .add_node("agent", call_model)
        .add_node("tools", ToolNode(TOOLS))
        .add_edge(START, "agent")
        .add_conditional_edges("agent", route, ["tools", END])
        .add_edge("tools", "agent")
        .compile()
    )
    return graph


# ---------------------------------------------------------------------------
# Active graph — swap to get_custom_graph() to use the explicit StateGraph
# ---------------------------------------------------------------------------

def get_graph():
    """Return the active compiled graph / agent."""
    return get_react_agent()
    # return get_custom_graph()
