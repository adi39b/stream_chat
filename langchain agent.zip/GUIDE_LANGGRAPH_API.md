# LangGraph / LangChain — API Server Implementation Guide

A detailed reference for every way to serve a LangGraph agent over HTTP,
from a quick `uvicorn` one-liner through the official `langgraph dev` SDK server,
all the way to LangSmith Deployment (formerly LangGraph Platform/Cloud).

> **Official docs home:** https://docs.langchain.com/docs/langgraph  
> **LangGraph GitHub:** https://github.com/langchain-ai/langgraph  
> **LangGraph Python API reference:** https://langchain-ai.github.io/langgraph/reference/  
> **Streaming reference:** https://docs.langchain.com/oss/python/langgraph/streaming  
> **LangGraph Academy (free course):** https://academy.langchain.com/courses/intro-to-langgraph

---

## Table of Contents

1. [Core Concepts](#1-core-concepts)
2. [Approach A — Custom FastAPI / Plain HTTP](#2-approach-a--custom-fastapi--plain-http)
3. [Approach B — LangGraph CLI Dev Server (`langgraph dev`)](#3-approach-b--langgraph-cli-dev-server-langgraph-dev)
4. [Approach C — LangGraph CLI Production Server (`langgraph up`)](#4-approach-c--langgraph-cli-production-server-langgraph-up)
5. [Approach D — LangSmith Deployment (Cloud / Hybrid / Self-Hosted)](#5-approach-d--langsmith-deployment)
6. [Streaming Modes Deep-Dive](#6-streaming-modes-deep-dive)
7. [Persistence, Checkpointers & Threads](#7-persistence-checkpointers--threads)
8. [Human-in-the-Loop Interrupts](#8-human-in-the-loop-interrupts)
9. [Multi-Agent Patterns](#9-multi-agent-patterns)
10. [MCP Tool Integration](#10-mcp-tool-integration)
11. [Connecting This Stack to a Next.js Frontend](#11-connecting-this-stack-to-a-nextjs-frontend)
12. [Gotchas & Common Bugs](#12-gotchas--common-bugs)
13. [Quick Reference: All Official Doc Links](#13-quick-reference-all-official-doc-links)

---

## 1. Core Concepts

### Graph anatomy

A LangGraph application is a **compiled `StateGraph`**. You define:

| Piece | What it is |
|---|---|
| `State` | A `TypedDict` with your graph's shared memory |
| Nodes | Python functions `(state) -> dict` — each returns a state update |
| Edges | Wiring between nodes; can be conditional |
| Checkpointer | Optional persistence layer (SQLite, Postgres, Redis…) |

```python
from typing import Annotated, TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langchain_core.messages import BaseMessage

class State(TypedDict):
    messages: Annotated[list[BaseMessage], add_messages]

def my_node(state: State) -> dict:
    # ... call a model, do logic ...
    return {"messages": [response]}

graph = (
    StateGraph(State)
    .add_node("my_node", my_node)
    .add_edge(START, "my_node")
    .add_edge("my_node", END)
    .compile()
)
```

### create_react_agent (quickest path)

`langgraph.prebuilt.create_react_agent` builds the full agent↔tool loop for you:

```python
from langgraph.prebuilt import create_react_agent
from langchain_openai import ChatOpenAI
from langchain_core.tools import tool

@tool
def my_tool(x: str) -> str:
    """Does something useful."""
    return f"Result: {x}"

agent = create_react_agent(
    ChatOpenAI(model="gpt-4o-mini", streaming=True),
    [my_tool],
    prompt="You are a helpful assistant.",   # optional system message
)
# agent is a compiled graph — use it like any StateGraph
```

> Docs: https://langchain-ai.github.io/langgraph/reference/prebuilt/#langgraph.prebuilt.chat_agent_executor.create_react_agent

---

## 2. Approach A — Custom FastAPI / Plain HTTP

**When to use:** You need full control over the HTTP layer, auth, middleware, or custom serialisation.  
This is the approach used in `backend/main.py` in this project.

### Install

```bash
pip install fastapi uvicorn langchain langchain-openai langgraph python-dotenv
```

### Key patterns

#### astream_events (used in this project)

The most granular streaming API — emits one event dict per token/tool-call/chain step:

```python
async for event in graph.astream_events({"messages": lc_messages}, version="v2"):
    # event["event"] is one of:
    #   on_chain_start / on_chain_end
    #   on_chat_model_start / on_chat_model_stream / on_chat_model_end
    #   on_tool_start / on_tool_end
    kind = event["event"]
    if kind == "on_chat_model_stream":
        token = event["data"]["chunk"].content   # plain string
        yield token
```

> Docs: https://python.langchain.com/docs/how_to/streaming/#using-stream-events

#### astream (simpler, coarser)

Yields whole-state snapshots or diffs per super-step:

```python
async for chunk in graph.astream({"messages": lc_messages}, stream_mode="updates"):
    # chunk is a dict of {node_name: state_update}
    for node, update in chunk.items():
        print(node, update)
```

#### Serving as NDJSON over FastAPI

```python
from fastapi.responses import StreamingResponse
import json

@app.post("/api/chat")
async def chat(request: Request):
    body = await request.json()
    messages = deserialize(body["messages"])

    async def stream():
        async for event in graph.astream_events({"messages": messages}, version="v2"):
            yield json.dumps(serialize_event(event)) + "\n"

    return StreamingResponse(stream(), media_type="application/x-ndjson",
                             headers={"X-Accel-Buffering": "no"})
```

#### Critical: do NOT use dumpd() on events

`langchain_core.load.dumpd()` wraps Python objects as `{"lc":1,"type":"constructor","kwargs":{...}}`.
This is correct for **serialising messages going INTO the graph**, but breaks the JS `toUIMessageStream()`
adapter when used on **events coming OUT**. Always extract content as plain primitives:

```python
# WRONG — breaks JS consumer:
yield json.dumps(dumpd(event)) + "\n"

# CORRECT — extract as plain primitives before serialising:
yield json.dumps({
    "event": event["event"],
    "data": {"chunk": {"content": event["data"]["chunk"].content}}
}) + "\n"
```

#### Message deserialisation (input)

```python
from langchain_core.load import load

# Messages from toBaseMessages() on the JS side arrive as dumpd-format JSON.
# Python's load() reconstructs them as proper HumanMessage / AIMessage objects.
lc_messages = [load(m) for m in body["messages"]]
```

### Running

```bash
uvicorn main:app --reload --port 8000
```

---

## 3. Approach B — LangGraph CLI Dev Server (`langgraph dev`)

**When to use:** Local development, LangGraph Studio integration, hot-reload, zero boilerplate.

This starts the **official LangGraph API server** (same protocol as production) locally.
It exposes the full REST API — threads, runs, assistants, checkpointing, streaming —
with no Docker required.

> Docs: https://docs.langchain.com/langsmith/cli  
> PyPI: https://pypi.org/project/langgraph-cli/

### Install

```bash
pip install "langgraph-cli[inmem]"
# The [inmem] extra is REQUIRED for `langgraph dev` — installs langgraph-api and langgraph-runtime-inmem
```

### Configuration: `langgraph.json`

Create this file in your project root:

```json
{
  "$schema": "https://langgra.ph/schema.json",
  "dependencies": ["."],
  "graphs": {
    "agent": "./agent.py:graph"
  },
  "env": ".env"
}
```

- `graphs.agent` — key is the **assistant name** used in API calls, value is `file:variable`
- Multiple graphs are supported: `"graphs": {"chat": "...", "research": "..."}`
- `"env": ".env"` — path to your environment variables file

### Start the server

```bash
langgraph dev
# Defaults:
#   API:          http://127.0.0.1:2024
#   Docs (Swagger): http://127.0.0.1:2024/docs
#   Studio:       https://smith.langchain.com/studio/?baseUrl=http://127.0.0.1:2024
```

CLI flags:

| Flag | Default | Purpose |
|---|---|---|
| `--host` | `127.0.0.1` | Bind address (use `0.0.0.0` for network access) |
| `--port` | `2024` | Port |
| `--no-reload` | off | Disable hot-reload |
| `--debug-port` | off | Attach IDE debugger (e.g. VS Code "Attach to Process") |
| `--tunnel` | off | Cloudflare tunnel for HTTPS (Safari / Brave fix) |
| `--no-browser` | off | Skip auto-opening LangGraph Studio |

### Calling the dev server from Python (langgraph_sdk)

```python
from langgraph_sdk import get_client

client = get_client(url="http://127.0.0.1:2024")

# Stream a run
async for chunk in client.runs.stream(
    None,           # thread_id=None → threadless (stateless) run
    "agent",        # assistant name from langgraph.json
    input={"messages": [{"role": "human", "content": "Hello!"}]},
    stream_mode="messages",
):
    print(chunk.event, chunk.data)
```

### Calling via raw HTTP (curl)

```bash
curl -s http://127.0.0.1:2024/runs/stream \
  -H "Content-Type: application/json" \
  -d '{
    "assistant_id": "agent",
    "input": {"messages": [{"role": "human", "content": "What is 2+2?"}]},
    "stream_mode": "messages"
  }'
```

### LangGraph Studio

With `langgraph dev` running, open:
```
https://smith.langchain.com/studio/?baseUrl=http://127.0.0.1:2024
```

Studio gives you a visual graph explorer, step-by-step state inspection, time-travel (rewind to any checkpoint), and breakpoint debugging. If your browser blocks HTTP on localhost (Safari, Brave), use `--tunnel`.

---

## 4. Approach C — LangGraph CLI Production Server (`langgraph up`)

**When to use:** Production-like local testing, Docker-based deployment with Postgres + Redis.

`langgraph up` starts the same API server as `langgraph dev` but inside **Docker Compose**
with a real Postgres database and Redis cache for durable production-grade state.

> Requires Docker Desktop installed.

```bash
# Build and start with Docker Compose
langgraph up --port 8123 --wait

# Watch for file changes and restart
langgraph up --watch

# Build the Docker image only (for CI/CD)
langgraph build -t my-agent:latest --platform linux/amd64
```

Docker Compose services started by `langgraph up`:
- `langgraph-api` — the API server container (your graph code)
- `postgres` — durable checkpointer storage
- `redis` — cache / task queue

**Important:** Inside Docker containers, `localhost` refers to the container, not your machine.
Use `host.docker.internal` to reach services on your host (Ollama, local DBs, etc.).

```python
# In your graph code when running inside Docker:
CHROMA_URL = "http://host.docker.internal:8001"  # not localhost
```

---

## 5. Approach D — LangSmith Deployment

> As of October 2025, LangGraph Platform was renamed to **LangSmith Deployment**.  
> Docs: https://docs.langchain.com/oss/python/langgraph/deploy

Four hosting tiers:

| Tier | Who manages infra | Cost | Docs |
|---|---|---|---|
| **Self-Hosted Lite** | You | Free (≤1M nodes/month) | https://docs.langchain.com/docs/langgraph/tutorials/deployment/local-server |
| **Cloud SaaS** | Langchain (fully managed) | LangSmith Plus/Enterprise | Deploy from LangSmith UI → Deployments |
| **BYOC** (Bring Your Own Cloud) | LangChain (in your VPC) | Enterprise | Contact sales |
| **Self-Hosted Enterprise** | You | Enterprise | Contact sales |

### Cloud SaaS quickstart

1. Push your graph code to GitHub
2. Your repo must have `langgraph.json` at the root
3. In LangSmith UI → **Deployments** → **New Deployment** → select repo
4. LangSmith builds, deploys, and gives you a URL

### Calling a deployed graph

```python
from langgraph_sdk import get_sync_client

client = get_sync_client(
    url="https://your-deployment.langsmith.com",
    api_key="ls__..."  # LangSmith API key
)

for chunk in client.runs.stream(
    None, "agent",
    input={"messages": [{"role": "human", "content": "Hello"}]},
    stream_mode="updates",
):
    print(chunk.data)
```

### LangSmithDeploymentTransport (connects Next.js directly to deployed graph)

Skip the FastAPI microservice entirely and connect your Next.js app **directly** to LangSmith Deployment:

```typescript
// app/api/chat/route.ts
import { LangSmithDeploymentTransport, toUIMessageStream } from '@ai-sdk/langchain';
import { createUIMessageStreamResponse, UIMessage } from 'ai';

const transport = new LangSmithDeploymentTransport({
  apiUrl: process.env.LANGSMITH_DEPLOYMENT_URL!,
  apiKey: process.env.LANGSMITH_API_KEY!,
  assistantId: 'agent',
});

export async function POST(req: Request) {
  const { messages }: { messages: UIMessage[] } = await req.json();
  const stream = await transport.stream({ messages });
  return createUIMessageStreamResponse({ stream: toUIMessageStream(stream) });
}
```

> Docs: https://ai-sdk.dev/providers/adapters/langchain#langsmithdeploymenttransport

---

## 6. Streaming Modes Deep-Dive

LangGraph ≥ 1.1 supports **version="v2"** streaming with a unified `StreamPart` dict:

```python
{
  "type": "values" | "updates" | "messages" | "custom" | "checkpoints" | "tasks" | "debug",
  "ns": (),       # namespace tuple — populated for subgraph events
  "data": ...     # payload (varies by type)
}
```

> Reference: https://docs.langchain.com/oss/python/langgraph/streaming

### Stream mode comparison

| Mode | What you get | Best for |
|---|---|---|
| `messages` | LLM tokens + tool call chunks, one per token | Chat UIs, token-by-token display |
| `updates` | State diffs after each node completes | Monitoring graph progress |
| `values` | Full state snapshot after each super-step | Debugging, state inspection |
| `custom` | User-defined data via `get_stream_writer()` | Progress bars, custom events |
| `checkpoints` | Checkpoint metadata at each save | Audit trails, time-travel |
| `debug` | Detailed execution trace | Deep debugging |

### Multi-mode streaming

```python
# Combine modes — events are interleaved
async for chunk in graph.astream(
    {"messages": messages},
    stream_mode=["messages", "updates"],
    version="v2",
):
    if chunk["type"] == "messages":
        msg, meta = chunk["data"]
        print(msg.content, end="", flush=True)
    elif chunk["type"] == "updates":
        print(f"\n[node done: {list(chunk['data'].keys())}]")
```

### astream_events — all event types

| Event string | Fired when |
|---|---|
| `on_chain_start` | Graph or node begins |
| `on_chain_end` | Graph or node finishes |
| `on_chat_model_start` | LLM invocation begins |
| `on_chat_model_stream` | Single token arrives (`event["data"]["chunk"].content`) |
| `on_chat_model_end` | LLM invocation finishes |
| `on_tool_start` | Tool call begins (`event["data"]["input"]`) |
| `on_tool_end` | Tool call returns (`event["data"]["output"]`) |
| `on_retriever_start/end` | RAG retriever invocation |

### Filtering by node

```python
async for event in graph.astream_events({"messages": messages}, version="v2"):
    if (
        event["event"] == "on_chat_model_stream"
        and event["metadata"].get("langgraph_node") == "agent"
    ):
        print(event["data"]["chunk"].content, end="", flush=True)
```

### Custom data streaming

```python
from langgraph.config import get_stream_writer

def my_node(state: State) -> dict:
    writer = get_stream_writer()
    writer({"progress": "Starting search..."})
    # ... do work ...
    writer({"progress": "Done!"})
    return {"messages": [response]}

# Receive on caller side:
async for chunk in graph.astream(inputs, stream_mode=["updates", "custom"], version="v2"):
    if chunk["type"] == "custom":
        print(chunk["data"]["progress"])
```

---

## 7. Persistence, Checkpointers & Threads

Persistence lets your graph remember state across turns, resume from failures, and support human-in-the-loop.

> Reference: https://pypi.org/project/langgraph-checkpoint/

### Checkpointer options

| Checkpointer | Install | Best for |
|---|---|---|
| `MemorySaver` | built-in | Dev / testing (in-process) |
| `InMemorySaver` | built-in (LG ≥ 0.2.74) | Same as MemorySaver, newer API |
| `AsyncSqliteSaver` | `langgraph-checkpoint-sqlite` | Local / single-server |
| `AsyncPostgresSaver` | `langgraph-checkpoint-postgres` | Production multi-server |
| LangSmith managed | `langgraph-sdk` | LangGraph Platform / Cloud |

### Enabling persistence

```python
from langgraph.checkpoint.memory import InMemorySaver
# or: from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver

checkpointer = InMemorySaver()
graph = my_graph_builder.compile(checkpointer=checkpointer)
```

### Threads

A **thread** is a unique ID that groups a sequence of checkpoints — it IS a conversation session.

```python
import uuid

# Generate per user session
thread_id = str(uuid.uuid4())
config = {"configurable": {"thread_id": thread_id}}

# Invoke with thread — state persists between calls with the same thread_id
result = await graph.ainvoke({"messages": [HumanMessage("Hello!")]}, config)
result2 = await graph.ainvoke({"messages": [HumanMessage("Remember me?")]}, config)
# The second call has full history from the first
```

### Resuming from checkpoint

```python
# Get current state
state = await graph.aget_state(config)
print(state.values["messages"])

# Rewind to a specific checkpoint (time travel)
history = [s async for s in graph.aget_state_history(config)]
old_config = history[2].config   # e.g. 2 steps back
state_at_step_2 = await graph.aget_state(old_config)

# Fork from old state (time travel + branch)
new_state = await graph.aupdate_state(old_config, {"messages": [new_message]})
```

### Postgres checkpointer (production)

```python
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
import psycopg

async with await psycopg.AsyncConnection.connect(
    "postgresql://user:pass@localhost/mydb"
) as conn:
    checkpointer = AsyncPostgresSaver(conn)
    await checkpointer.setup()   # creates tables if needed
    graph = my_builder.compile(checkpointer=checkpointer)
```

---

## 8. Human-in-the-Loop Interrupts

LangGraph supports pausing graph execution mid-run to wait for human input/approval.

> Docs: https://langchain-ai.github.io/langgraph/concepts/human_in_the_loop/

### Using `interrupt()`

```python
from langgraph.types import interrupt

def review_node(state: State) -> dict:
    # Pause execution and surface data to the human
    human_response = interrupt({
        "question": "Do you approve this action?",
        "pending_action": state["pending_action"],
    })
    # human_response is whatever the human submitted to resume the graph
    if human_response["approved"]:
        return {"approved": True}
    return {"approved": False, "reason": human_response["reason"]}
```

### Resuming after interrupt

```python
# First run — pauses at interrupt
result = await graph.ainvoke(inputs, config)
# result will contain __interrupt__ key

# Human makes a decision, then resume:
from langgraph.types import Command

result = await graph.ainvoke(
    Command(resume={"approved": True}),  # value passed back to interrupt()
    config,
)
```

### Using `interrupt_before` / `interrupt_after` on compile

```python
graph = builder.compile(
    checkpointer=checkpointer,
    interrupt_before=["dangerous_action"],   # pause BEFORE this node
    interrupt_after=["research_step"],       # pause AFTER this node
)
```

---

## 9. Multi-Agent Patterns

> Docs: https://langchain-ai.github.io/langgraph/concepts/multi_agent/

### Supervisor pattern

```python
from langgraph_supervisor import create_supervisor

supervisor = create_supervisor(
    [research_agent, writing_agent],
    model=ChatOpenAI(model="gpt-4o"),
    prompt="Route tasks to the best agent.",
)
```

### Swarm pattern

```python
from langgraph_swarm import create_swarm

swarm = create_swarm([agent_a, agent_b], default_active_agent="agent_a")
```

### RemoteGraph — calling deployed graphs as subgraphs

```python
from langgraph.pregel.remote import RemoteGraph

# Treat a deployed agent as a node in your local graph
remote_agent = RemoteGraph(
    "my_agent",
    url="https://deployment.langsmith.com",
    api_key="ls__...",
)
```

---

## 10. MCP Tool Integration

`langchain-mcp-adapters` loads tools from any MCP server into LangChain format.

> Repo: https://github.com/langchain-ai/langchain-mcp-adapters

```bash
pip install langchain-mcp-adapters mcp
```

### stdio transport (subprocess per tool server)

```python
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from langchain_mcp_adapters.tools import load_mcp_tools

# Use as an async context manager to keep the subprocess alive
async with stdio_client(StdioServerParameters(
    command="uvx", args=["mcp-server-sqlite", "--db-path", "data.db"]
)) as (read, write):
    async with ClientSession(read, write) as session:
        await session.initialize()
        tools = await load_mcp_tools(session)
        agent = create_react_agent(model, tools)
```

### SSE transport (persistent HTTP server)

```python
from langchain_mcp_adapters.client import MultiServerMCPClient

async with MultiServerMCPClient({
    "filesystem": {
        "url": "http://localhost:3000/sse",
        "transport": "sse",
    }
}) as client:
    tools = client.get_tools()
    agent = create_react_agent(model, tools)
```

### Keeping MCP sessions alive across requests (FastAPI lifespan)

```python
from contextlib import asynccontextmanager
from fastapi import FastAPI

mcp_tools = []

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Start MCP servers at API startup
    client = MultiServerMCPClient({...})
    await client.__aenter__()
    mcp_tools.extend(client.get_tools())
    yield
    await client.__aexit__(None, None, None)

app = FastAPI(lifespan=lifespan)
```

---

## 11. Connecting This Stack to a Next.js Frontend

### Option 1: Custom FastAPI (this project's approach)

```
useChat → /api/chat (Next.js) → FastAPI :8000/api/chat → LangGraph graph
```

The Next.js route:
1. Calls `toBaseMessages(messages)` to convert `UIMessage[]` → LangChain JSON
2. POSTs to FastAPI
3. Wraps the NDJSON response generator in `ReadableStream.from(gen)`
4. Pipes into `toUIMessageStream()` → `createUIMessageStreamResponse()`

```typescript
// The critical wrapper — toUIMessageStream expects ReadableStream, not AsyncIterable
const eventStream = ReadableStream.from(yieldEvents());
return createUIMessageStreamResponse({ stream: toUIMessageStream(eventStream) });
```

### Option 2: LangGraph dev/up server (langgraph_sdk or direct HTTP)

The `langgraph dev` server exposes the LangGraph API protocol.
Connect via the JS SDK `@langchain/langgraph-sdk` or via raw SSE fetch.

### Option 3: LangSmithDeploymentTransport (zero middleware)

```typescript
import { LangSmithDeploymentTransport, toUIMessageStream } from '@ai-sdk/langchain';

const transport = new LangSmithDeploymentTransport({
  apiUrl: process.env.LANGSMITH_DEPLOYMENT_URL!,
  apiKey: process.env.LANGSMITH_API_KEY!,
  assistantId: 'agent',
});

export async function POST(req: Request) {
  const { messages } = await req.json();
  const stream = await transport.stream({ messages });
  return createUIMessageStreamResponse({ stream: toUIMessageStream(stream) });
}
```

---

## 12. Gotchas & Common Bugs

### `dumpd()` on events breaks JS adapter
`dumpd()` is for serialising *messages going in*, not events coming out. The JS `toUIMessageStream()` reads properties like `event.data.chunk.content` directly — after `dumpd()` wrapping, these are buried under `kwargs.content`. Always serialize events as plain dicts with primitive values.

### `ReadableStream.from()` is required
`toUIMessageStream()` is typed as `(stream: ReadableStream<...>)`, not `AsyncIterable`. In Node 18+ use `ReadableStream.from(asyncIterable)` to convert.

### `astream_events` requires `version="v2"`
Always pass `version="v2"`. The v1 format is deprecated and will be removed.

### MemorySaver is not thread-safe across processes
`MemorySaver` lives in-process. For multi-worker FastAPI deployments (e.g., `uvicorn --workers 4`), use `AsyncPostgresSaver` or `AsyncSqliteSaver`.

### Nginx / proxy buffering kills NDJSON streaming
Add `X-Accel-Buffering: no` and `Cache-Control: no-cache` headers to your streaming response:
```python
return StreamingResponse(stream(), headers={"X-Accel-Buffering": "no", "Cache-Control": "no-cache"})
```

### Synchronous blocking in async nodes
LangGraph runs on an ASGI event loop. Any `time.sleep()`, synchronous DB calls, etc. will block all concurrent requests. Use `asyncio.sleep()` and async DB clients, or wrap blocking code with `asyncio.run_in_executor()`.

### Safari + `langgraph dev` on localhost
Safari blocks HTTP resources loaded from HTTPS pages. Use `langgraph dev --tunnel` to get a Cloudflare HTTPS URL.

### MCP stdio sessions die with the request lifecycle
Stdio spawns a subprocess. If you create a new session per request, the subprocess dies when the context manager exits. Use FastAPI `lifespan` to keep sessions open for the server's lifetime.

---

## 13. Quick Reference: All Official Doc Links

| Topic | URL |
|---|---|
| LangGraph main docs | https://langchain-ai.github.io/langgraph/ |
| LangGraph Python API | https://langchain-ai.github.io/langgraph/reference/ |
| create_react_agent | https://langchain-ai.github.io/langgraph/reference/prebuilt/ |
| Streaming guide | https://docs.langchain.com/oss/python/langgraph/streaming |
| Checkpointing | https://pypi.org/project/langgraph-checkpoint/ |
| Human-in-the-loop | https://langchain-ai.github.io/langgraph/concepts/human_in_the_loop/ |
| Multi-agent | https://langchain-ai.github.io/langgraph/concepts/multi_agent/ |
| LangGraph CLI (PyPI) | https://pypi.org/project/langgraph-cli/ |
| LangGraph CLI docs | https://docs.langchain.com/langsmith/cli |
| LangSmith Deployment | https://docs.langchain.com/oss/python/langgraph/deploy |
| LangGraph SDK (Python) | https://pypi.org/project/langgraph-sdk/ |
| MCP adapters | https://github.com/langchain-ai/langchain-mcp-adapters |
| @ai-sdk/langchain adapter | https://ai-sdk.dev/providers/adapters/langchain |
| AI SDK v6 changelog | https://vercel.com/blog/ai-sdk-6 |
| LangChain Academy (free) | https://academy.langchain.com/courses/intro-to-langgraph |
| Awesome-LangGraph | https://github.com/von-development/awesome-LangGraph |
